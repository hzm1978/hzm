# Reproducibility files for the integrated topical review

All scientific derivations are in Appendices A-G of the manuscript. This archive provides their code, inputs and output records. No experiment is claimed.

Install Python dependencies with python -m pip install -r requirements.txt, then run:

python calculations/verify_fop_v9.py
python calculations/verify_benchmarks.py
python calculations/reproduce_compact_detector.py
python calculations/verify_new_diagnostics.py

Optional figures: python calculations/make_figures.py (requires a Chinese font), or add --english-only. See calculations/README.md for normalization conventions and scope.
