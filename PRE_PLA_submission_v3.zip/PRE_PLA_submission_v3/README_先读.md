# PRE：PLA 转投修改版

这是用户上传 `PRE.zip` 的修改版，目标为 Physics Letters A，已按作者说明记录 JHEP 为编辑直接拒稿。原上传文件及原提取稿未改动。本包未向期刊提交。GitHub 的 docs/pre-pla-v3 分支用于下载及作者审阅。

建议先读 `author_documents/PLA审阅结论与修改清单.pdf`，再看英文正文和中文对照。结论是有转投价值，但贡献属于特定模型的增量理论结果；资助及利益冲突已按作者确认写为无；正式提交前仍需作者审阅和期刊最新形式项核对。

| 文件 | 用途 |
|---|---|
| `manuscript/main.pdf` / `main.tex` | Elsevier 模板英文主稿 |
| `chinese/main_zh.pdf` / `main_zh.tex` | 同步的中文全文对照，供作者审阅 |
| `supplement/supplement.pdf` / `.tex` | 英文证明、谱计算、近似范围与数值细节 |
| `author_documents/PLA审阅结论与修改清单.pdf` / `.md` | 必须项、建议项、创新边界与投稿状态 |
| `author_documents/cover_letter_PLA.pdf` / `.md` | 投稿信草稿 |
| `author_documents/highlights.txt` | 四条短 highlights |
| `author_documents/作者声明与提交前核对.md` | 已确认声明与提交前事实核对 |
| `reproducibility/src/` | 原模型、原验证及本次增加的边界／收敛检查 |
| `reproducibility/results/` | 实际复算结果、曲线样本、收敛表 |
| `audit/` | 来源、散列、文献核对、运行与编译记录 |
| `vendor/elsarticle/`、`texsupport/` | 保留许可证的模板及中文排版支持 |

中文的28个显示数学块来自英文原文，保存在 `chinese/formulas.tex`；文字、定理和图注已单独对照。编辑英文公式后也应同步中文，并重新审阅其文字含义。

## 数值重现

建议使用独立虚拟环境，Python依赖见 `reproducibility/requirements.txt`：

```sh
python -m venv .venv
. .venv/bin/activate
python -m pip install -r reproducibility/requirements.txt
MPLCONFIGDIR=/tmp/pre-pla-mpl XDG_CACHE_HOME=/tmp/pre-pla-cache OPENBLAS_NUM_THREADS=1 python reproducibility/src/validate.py
MPLCONFIGDIR=/tmp/pre-pla-mpl XDG_CACHE_HOME=/tmp/pre-pla-cache OPENBLAS_NUM_THREADS=1 python reproducibility/src/validate_submission.py
```

第一步重新生成图像、原始数据和原核验，第二步检查紧凑公式、长时间边界、慢速率／资源及对比收敛。重算后更新正文图像时，将 `reproducibility/figures/` 中四个 PDF 复制至 `manuscript/figures/`。

检查仅针对有限维信道和指定有效生成元，不证明首创，不构成固定耦合的微观长时验证。

## 从源文件编译

运行 `bash build_all.sh`。需要 pdfLaTeX、XeLaTeX、latexmk、常用 TeX 宏包、Pandoc 和 Noto Serif CJK SC 字体。英文使用 pdfLaTeX，中文使用 XeLaTeX；中文支持随包提供，不依赖本环境缺失的 `ctexart` 类。

完整作者审阅包包含中文说明、日志和来源资料。正式上传期刊时，选择英文主稿及其可编辑源文件、图像、英文补充材料和必要的代码／数据类别；不要将中文审阅报告或待确认表误传为正式主稿。

ScienceDirect/Elsevier 页面本次读取被代理连接403阻止，期刊最新细则及实时收录需从官方页面最终确认，详见报告和 `audit/journal_access_status.json`。这项限制未被伪装成已完成的核查。
