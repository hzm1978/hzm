# Scientific review checklist

The checks below are mathematical/editorial review findings, distinct from the numerical and document-integrity scripts.

- The initial state has unit norm, a maximally mixed qubit reference and the same detector marginal for all phases.
- Single-detector protection follows from a flagged erasure-correction structure. No relativistic mechanism is required for that result.
- Sector protection assumes Kraus-level block preservation. Exchange covariance alone is insufficient.
- The decoder acts jointly inside BCD and commutes with the stated sector-preserving Kraus operators. Predecoding is possible and is disclosed.
- Negativity is normalized to maximum one on A|BCD. It is not a genuine multipartite measure.
- The collective jump normalization and compensating factors in the independent Liouvillian code agree. The four-state population matrix has nonnegative off-diagonal rates and zero column sums.
- Partial transpose isolates a cross block with singular-value pairs. The trace-norm expression retains the determinant modulus and assumes no undocumented sign branch.
- The coefficient controlling phase monotonicity is nonnegative by the two-case argument. A maximizing phase need not be unique.
- The Dicke measurement retains all outcomes; its coherence coefficients and normalized recovered state give the stated negativity. Recovery is a specified procedure, not a claim of general optimal recovery.
- Teleportation is the standard dephasing-channel protocol; averaging over a qubit 2-design and the known Bell-overlap formula agree.
- The slow projection uses biorthogonal left/right sector vectors and a gapped fast block at fixed positive q. Initial-layer and zero-temperature boundaries are treated separately.
- The accelerated and thermal spectra and population dynamics are known inputs. The lifetime comparison matches both the rate ratio and local relaxation rate.
- Small-separation expansions require both omega L and a L to be small. The rate ratio and contrast optimum are leading asymptotic results, not finite-separation identities.
- The optimum observation time follows from differentiating a difference of two limiting exponentials. It does not optimize environmental hypothesis-testing error.
- Common-coupling protection is a microscopic symmetry statement at finite profile size. A finite-separation lifetime requires the stated weak-coupling assumption and ordered limits; no simultaneous-limit or fixed-coupling uniform memory-error theorem is claimed.
- Generator perturbations accumulate on the slow lifetime scale. The diamond-norm bound is sufficient and can be conservative.
- All principal formulas have dimensions consistent with natural units and the stated scaled times.

No core formula error was identified in this review. The prior art limits the novelty to a concrete encoded-resource calculation and its consequences. Correctness checks do not establish priority or guarantee journal acceptance.
