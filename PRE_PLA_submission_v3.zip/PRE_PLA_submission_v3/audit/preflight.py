"""Check manuscript packaging, citations, bilingual equations and PDF output.

Run after build_all.sh. PDF inspection requires PyMuPDF. These are document
integrity checks, not a substitute for reviewing the mathematical arguments.
"""
from pathlib import Path
import hashlib
import json
import re
import fitz

ROOT = Path(__file__).resolve().parents[1]
MATH = r"\\begin\{(equation\*?|align\*?)\}(.*?)\\end\{\1\}"


def citations(text):
    order = []
    for group in re.findall(r"\\cite\{([^}]+)\}", text):
        for key in group.split(","):
            if key not in order:
                order.append(key)
    return order


def check_document(source, bibliography):
    labels = re.findall(r"\\label\{([^}]+)\}", source)
    refs = re.findall(r"\\(?:eqref|ref)\{([^}]+)\}", source)
    assert len(labels) == len(set(labels)), "Duplicate labels"
    assert set(refs) <= set(labels), set(refs)-set(labels)
    bibkeys = re.findall(r"\\bibitem\{([^}]+)\}", bibliography)
    assert len(bibkeys) == len(set(bibkeys)), "Duplicate bibliography keys"
    assert citations(source) == bibkeys, "Bibliography is not in first-citation order"
    return {"labels": len(labels), "referenced_labels": len(set(refs)),
            "references": len(bibkeys), "first_citation_order": bibkeys}


def main():
    en = (ROOT/"manuscript/main.tex").read_text()
    zh = (ROOT/"chinese/main_zh.tex").read_text()
    blocks = json.loads((ROOT/"audit/formula_blocks.json").read_text())
    actual = [m.group() for m in re.finditer(MATH, en, re.S)]
    assert actual == [b["latex"] for b in blocks]
    calls = re.findall(r"\\UseFormula\{([^}]+)\}", zh)
    assert calls == [b["key"] for b in blocks]
    formulas = {b["key"]: b["latex"] for b in blocks}
    expanded = re.sub(r"\\UseFormula\{([^}]+)\}",
                      lambda m: formulas[m.group(1)], zh)
    assert citations(en) == citations(expanded)
    report = {"english": check_document(en, (ROOT/"manuscript/references.tex").read_text()),
              "chinese": check_document(expanded, (ROOT/"manuscript/references.tex").read_text()),
              "supplement": check_document((ROOT/"supplement/supplement.tex").read_text(),
                                            (ROOT/"supplement/references.tex").read_text())}
    for name, text in [("english", en), ("chinese", expanded)]:
        propositions = len(re.findall(r"\\begin\{proposition\}", text))
        proofs = len(re.findall(r"\\end\{proposition\}\s*\\begin\{proof\}", text))
        assert propositions == proofs == 3
        report[name]["propositions_with_immediate_proof"] = proofs

    def equation_numbers(stem):
        s=(ROOT/"build"/(stem+".aux")).read_text()
        return {k:v for k,v in re.findall(r"\\newlabel\{([^}]+)\}\{\{([^}]+)\}",s)
                if k.startswith("eq:")}
    assert equation_numbers("main") == equation_numbers("main_zh")
    report["bilingual_display_blocks"] = len(actual)
    report["bilingual_equation_numbers_identical"] = True

    for stem in ("main", "main_zh", "supplement"):
        log = (ROOT/"build"/(stem+".log")).read_text(errors="replace")
        for pattern in [r"Overfull", r"Float too large", r"LaTeX Error",
                        r"There were undefined references", r"multiply defined",
                        r"Missing character:"]:
            assert not re.search(pattern, log), (stem, pattern)
    pdfs = ["manuscript/main.pdf", "chinese/main_zh.pdf", "supplement/supplement.pdf",
            "author_documents/PLA审阅结论与修改清单.pdf", "author_documents/cover_letter_PLA.pdf"]
    report["pdfs"] = {}
    for name in pdfs:
        d = fitz.open(ROOT/name)
        assert all(p.get_text().strip() for p in d), name
        assert all("\ufffd" not in p.get_text() for p in d), name
        report["pdfs"][name] = {"pages": len(d), "bytes": (ROOT/name).stat().st_size}
    highlights = (ROOT/"author_documents/highlights.txt").read_text().splitlines()
    assert len(highlights) == 4 and max(map(len, highlights)) <= 85
    report["highlight_lengths"] = list(map(len, highlights))
    for fn in ["validation.json", "submission_validation.json"]:
        numerical = json.loads((ROOT/"reproducibility/results"/fn).read_text())
        assert numerical["status"] == "passed"
    for figure in (ROOT/"manuscript/figures").glob("*.pdf"):
        peer = ROOT/"reproducibility/figures"/figure.name
        assert figure.read_bytes() == peer.read_bytes()
    report["all_four_figure_assets_match_reproduction"] = True
    report["metadata_records"] = len(json.loads((ROOT/"audit/reference_metadata_verified.json").read_text()))
    report["status"] = "technical_document_checks_passed"
    report["full_submission_ready"] = False
    report["author_funding_and_competing_interests"] = "Confirmed by author: no funding and no competing interests; written in both manuscripts."
    report["remaining"] = ["Author final scientific approval and submission facts",
                           "Current PLA-specific requirements and indexing check through official sites"]
    (ROOT/"audit/preflight_results.json").write_text(json.dumps(report, indent=2, ensure_ascii=False))
    print(json.dumps(report, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
