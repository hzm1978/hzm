#!/usr/bin/env bash
set -euo pipefail
pre_bundle_root="$(cd -- "$(dirname -- "$0")" && pwd)"
cd "$pre_bundle_root"
export TEXINPUTS="$pre_bundle_root/texsupport//:"
export XDG_CACHE_HOME=/tmp/pre-pla-build-cache
mkdir -p build
(
  cd manuscript
  latexmk -pdf -interaction=nonstopmode -halt-on-error -outdir=../build main.tex > ../build/main_build.txt 2>&1
)
(
  cd supplement
  latexmk -pdf -interaction=nonstopmode -halt-on-error -outdir=../build supplement.tex > ../build/supplement_build.txt 2>&1
)
(
  cd chinese
  latexmk -xelatex -interaction=nonstopmode -halt-on-error -outdir=../build main_zh.tex > ../build/chinese_build.txt 2>&1
)
cp build/main.pdf manuscript/main.pdf
cp build/supplement.pdf supplement/supplement.pdf
cp build/main_zh.pdf chinese/main_zh.pdf
pandoc author_documents/PLA审阅结论与修改清单.md --standalone --pdf-engine=xelatex \
  --variable documentclass=article --variable CJKmainfont='Noto Serif CJK SC' \
  --variable mainfont='Latin Modern Roman' --variable fontsize=10pt \
  --variable geometry:margin=22mm --variable colorlinks=true \
  --include-in-header=audit/report_preamble.tex \
  --output author_documents/PLA审阅结论与修改清单.pdf > build/report_build.txt 2>&1
pandoc author_documents/cover_letter_PLA.md --standalone --pdf-engine=xelatex \
  --variable mainfont='Latin Modern Roman' --variable fontsize=11pt \
  --variable geometry:margin=25mm --variable colorlinks=true \
  --output author_documents/cover_letter_PLA.pdf > build/cover_letter_build.txt 2>&1
printf '%s\n' 'Built English manuscript, Chinese counterpart, supplement, assessment and cover letter.'
