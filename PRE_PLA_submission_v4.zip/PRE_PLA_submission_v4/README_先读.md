# PRE / PLA v4 详细修订版

以本次重新上传的 `PRE_PLA_submission_v3.zip` 为底稿，继续扩充推导、操作过程和解释。原上传文件保留不动。本包用于论文阅读、作者复核和转投准备，尚未向期刊提交。

## 建议阅读

| 文件 | 内容 |
|---|---|
| `manuscript/main.pdf` | 英文详细主稿，Elsevier模板 |
| `chinese/main_zh.pdf` | 同步中文全文对照 |
| `supplement/supplement.pdf` | 英文补充证明、反例、新增快慢对照图 |
| `author_documents/PLA审阅结论与修改清单.pdf` | 详细修改说明及阅读指引 |
| `author_documents/cover_letter_PLA.pdf` | 投稿信草稿 |
| `author_documents/highlights.txt` | Highlights |
| `reproducibility/` | 计算代码、曲线、完整态标记及核验结果 |
| `audit/` | 输入散列、文献来源、公式一致性及编译核验记录 |

主线为相位制备、扇区保护、指定测量恢复和慢资源寿命。新增说明不扩大创新或微观有效性声明。资助和利益冲突沿用作者已确认的无资助、无利益冲突。

## 数值重现

依赖版本见 `reproducibility/requirements.txt`。在独立Python环境安装后，依次运行：

```sh
MPLCONFIGDIR=/tmp/pre-pla-v4-mpl XDG_CACHE_HOME=/tmp/pre-pla-v4-cache OPENBLAS_NUM_THREADS=1 python reproducibility/src/validate.py
MPLCONFIGDIR=/tmp/pre-pla-v4-mpl XDG_CACHE_HOME=/tmp/pre-pla-v4-cache OPENBLAS_NUM_THREADS=1 python reproducibility/src/validate_submission.py
MPLCONFIGDIR=/tmp/pre-pla-v4-mpl XDG_CACHE_HOME=/tmp/pre-pla-v4-cache OPENBLAS_NUM_THREADS=1 python reproducibility/src/validate_clarity.py
```

第三个脚本是本次新增，检查明确写出的条件态和交换协变反例，并生成补充图S1。CSV、JSON及本次实际运行日志随包保留。所有数值检查限定于所述有限维模型。

## 编译与编辑

运行 `bash build_all.sh`。需要pdfLaTeX、XeLaTeX、latexmk、Pandoc及Noto Serif CJK SC字体。模板与中文支持保留原许可证。

中英文45个显示数学块共享 `chinese/formulas.tex`，以英文公式标签作为键；调整公式时需同步该文件和中文文字，并重新运行 `python audit/preflight.py`。文档核验需要PyMuPDF。公式编号相同不等于自动证明数学正确，仍应审阅论证。

主图位于 `manuscript/figures/`；补充图位于 `supplement/figures/`。重算后如需更新排版图像，将 `reproducibility/figures/` 中对应PDF复制至上述目录。

完整审阅包包含中文说明及审计资料。正式投稿按系统类别选择英文主稿、图像、英文补充材料及需要的代码／数据，勿将作者阅读说明当作正式主稿上传。PLA实时形式要求仍应以官网系统核对。
