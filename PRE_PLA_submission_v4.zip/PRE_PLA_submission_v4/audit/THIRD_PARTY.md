# Third-party material and provenance

The Elsevier elsarticle bundle was retrieved on 3 November 2026 from https://mirrors.ctan.org/macros/latex/contrib/elsarticle.zip , resolving to the MIT CTAN mirror. The class was generated from the supplied elsarticle.ins and elsarticle.dtx using LaTeX; no class code was edited. The vendor bundle and original notices are retained under vendor/elsarticle/. The bundle uses the LaTeX Project Public License, version 1.3 or later. See template_provenance.json for hashes and generation details.

Chinese typesetting support under texsupport/ was already in the user upload. Its source, notices, README and LPPL text are retained. Chinese typesetting uses the installed Noto Serif CJK SC font; font binaries are not redistributed.

The model, original validation code and plot definitions originate in the user upload. They were inspected and rerun. This revision adds a validation script and its actual results. Original input hashes are retained separately.

Primary article PDFs consulted for comparison are not redistributed. Metadata and a targeted reading record are included. Unavailable publisher pages are recorded as unavailable.
