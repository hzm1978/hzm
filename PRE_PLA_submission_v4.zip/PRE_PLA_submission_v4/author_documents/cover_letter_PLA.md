---
title: "Cover letter draft — Physics Letters A"
date: ""
---

Dear Editor,

Please consider **“Phase-dependent recovery and lifetime of encoded entanglement under collective detector noise”** for publication in *Physics Letters A*.

The manuscript studies a four-qubit encoding in which two register qubits experience collective detector noise. Locally prepared states have identical initial reference–register negativity and detector marginals. An exact trace-norm reduction proves an optimal phase at every time within the stated secular weak-coupling generator. A specified detector measurement and conditional correction recover a two-qubit resource, linking its negativity to distinguishability of evolved sector populations.

Weak singlet–triplet mixing gives a metastable lifetime through a slow-sector projection. Applying this resource law to established accelerated-vacuum and thermal spectra yields a leading lifetime ratio at matched local rates and an observation time maximizing the resource contrast. The work connects collective open-system dynamics with an explicit recoverable-entanglement quantity.

We distinguish the calculation from earlier local-rotation studies of cluster-state robustness, known erasure correction, singlet protection and collective-detector spectra. Optimality is restricted to the specified phase family; recovery is a stated procedure. Exact common-coupling protection is separated from the conditional weak-coupling interpretation of the finite-separation lifetime. Necessary proofs follow the main propositions. Explicit conditional states and a comparison of fast and slow recovery stages clarify the operational interpretation. Supplementary derivations, reproducible code and figure data accompany the manuscript.

Thank you for considering this submission.

Sincerely,

Zhiming Huang  
School of Economics and Management, Wuyi University  
Jiangmen 529020, China  
465609785@qq.com
