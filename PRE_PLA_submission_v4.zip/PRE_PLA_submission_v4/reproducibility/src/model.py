"""Independent full Liouvillian calculation for the detector register.

The four-qubit basis is ordered as A, B, C, D. Each qubit has basis 0, 1.
Only C and D interact with the bath. A CD density matrix has 4 by 4 entries,
so flattening it produces a vector with 16 entries. Its Liouvillian is the
16 by 16 matrix returned by generator(). The full register density matrix
is also 16 by 16, but represents all four qubits rather than a superoperator.
"""
from pathlib import Path
import numpy as np
from scipy.linalg import expm

I = np.eye(2, dtype=complex)
sm = np.array([[0, 1], [0, 0]], dtype=complex)
sc = np.kron(sm, I)
sd = np.kron(I, sm)


def generator(q, f, exchange=0.0):
    """Row-vectorized CD generator; dimensionless time is z=Gamma*tau.

    q is the upward/downward rate ratio; f is the spatial correlation factor.
    exchange is the exchange Hamiltonian coefficient divided by Gamma.
    The operators below omit the 1/sqrt(2) in J_+ and J_-, so their rates
    include the compensating factor 1/2.
    """
    eye = np.eye(4)
    out = np.zeros((16, 16), dtype=complex)
    for op, rate in [(sc + sd, (1 + f) / (2 * (1 + q))),
                     (sc - sd, (1 - f) / (2 * (1 + q))),
                     (sc.conj().T + sd.conj().T, q * (1 + f) / (2 * (1 + q))),
                     (sc.conj().T - sd.conj().T, q * (1 - f) / (2 * (1 + q)))]:
        prod = op.conj().T @ op
        out += rate * (np.kron(op, op.conj())
                       - .5 * np.kron(prod, eye)
                       - .5 * np.kron(eye, prod.T))
    h = exchange * (sc.conj().T @ sd + sd.conj().T @ sc)
    out += -1j * (np.kron(h, eye) - np.kron(eye, h.T))
    return out


def state(theta):
    psi = np.zeros(16, dtype=complex)
    psi[1], psi[2], psi[13], psi[14] = .5, .5*np.exp(1j*theta), .5, -.5*np.exp(1j*theta)
    return np.outer(psi, psi.conj())


def evolve(rho, q, f, z, exchange=0.0):
    """Apply the CD channel to every AB block of the four-qubit state."""
    channel = expm(generator(q, f, exchange) * z)
    blocks = rho.reshape(4, 4, 4, 4).transpose(0, 2, 1, 3).reshape(16, 16)
    return (blocks @ channel.T).reshape(4, 4, 4, 4).transpose(0, 2, 1, 3).reshape(16, 16)


def negativity(rho):
    """Exchange the two A indices and sum absolute eigenvalues minus one."""
    pt = rho.reshape(2, 8, 2, 8).transpose(2, 1, 0, 3).reshape(16, 16)
    ev = np.linalg.eigvalsh((pt + pt.conj().T)/2)
    return float(np.abs(ev).sum() - 1)

