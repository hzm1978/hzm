"""Validate the analytic reduction and generate the two manuscript figures.

Run from any directory: python src/validate.py
Requires numpy, scipy and matplotlib. All assertions concern the specified
effective generator or exact finite-dimensional channel identities.
"""
from pathlib import Path
import csv
import hashlib
import json
import re
import numpy as np
from scipy.linalg import expm, eigvals
from scipy.integrate import quad
from scipy.optimize import minimize_scalar
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from model import state, evolve, negativity

ROOT = Path(__file__).resolve().parents[1]
RESULTS, FIGURES = ROOT / "results", ROOT / "figures"


def population_matrix(q, f):
    """M in p'=M p, for column vector p=(p_g,p_t,p_e,p_s).

    Off-diagonal entry M[i,j] is the rate from state j to state i.
    The zero column sums express conservation of total probability.
    """
    rp, rm = (1 + f) / (1 + q), (1 - f) / (1 + q)
    return np.array([[-q*(rp+rm), rp, 0, rm],
                     [q*rp, -(1+q)*rp, rp, 0],
                     [0, q*rp, -(rp+rm), q*rm],
                     [q*rm, 0, rm, -(1+q)*rm]])


def population_difference(q, f, z):
    """Difference between the populations evolved from P_t and from P_s."""
    return expm(population_matrix(q, f)*z) @ np.array([0, 1, 0, -1])


def closed_negativity(theta, q, f, z):
    """Evaluate the manuscript's trace-norm formula, label eq:exact."""
    dg, dt, de, ds = population_difference(q, f, z)
    alpha = np.sin(theta)/2
    b, c = (1+np.cos(theta))/2, (1-np.cos(theta))/2
    E = np.exp(-2*z)
    radicand = (alpha**2*(dt**2+ds**2) + (b*b+c*c)*E
                + 2*alpha**2*abs(dt*ds+E))
    return float(abs(alpha)*(abs(dg)+abs(de)) + np.sqrt(max(0, radicand)))


def recovered_formula(theta, q, f, z):
    return float(abs(np.sin(theta))*np.abs(population_difference(q, f, z)).sum()/2)


def correlation_factor(a, omega, length):
    if length == 0:
        return 1.0
    if a == 0:
        return float(np.sinc(omega*length/np.pi))
    return float(np.sin(2*omega/a*np.arcsinh(a*length/2)) /
                 (omega*length*np.sqrt(1+a*a*length*length/4)))


def slow_rate(q, f):
    eigenvalues = sorted(eigvals(population_matrix(q, f)).real, reverse=True)
    return float(-eigenvalues[1])


def channel_cd(rho, kraus):
    return sum(np.kron(np.eye(4), k) @ rho @ np.kron(np.eye(4), k).conj().T
               for k in kraus)


def apply_cd_operator(rho_cd, kraus):
    return sum(k @ rho_cd @ k.conj().T for k in kraus)


def negativity_ab(rho):
    pt = rho.reshape(2, 2, 2, 2).transpose(2, 1, 0, 3).reshape(4, 4)
    return float(np.abs(np.linalg.eigvalsh((pt+pt.conj().T)/2)).sum()-1)


def dicke_basis():
    g, e = np.eye(4)[0], np.eye(4)[3]
    t, s = np.array([0, 1, 1, 0])/np.sqrt(2), np.array([0, 1, -1, 0])/np.sqrt(2)
    return g, t, e, s


def recover_by_measurement(rho):
    blocks = rho.reshape(4, 4, 4, 4)
    recovered = np.zeros((4, 4), complex)
    for ket in dicke_basis():
        conditional = np.einsum("i,aibj,j->ab", ket.conj(), blocks, ket)
        phase = np.angle(conditional[0, 3])
        U = np.diag([1, np.exp(1j*phase), 1, np.exp(1j*phase)])
        recovered += U @ conditional @ U.conj().T
    return recovered


def average_teleportation_fidelity(resource):
    """Bell measurement and feedforward, averaged over a qubit 2-design.

    Qubit order is input, Alice's resource, Bob's resource. Compute every
    unnormalized Bob branch rather than using the singlet-fraction formula.
    """
    eye = np.eye(2, dtype=complex)
    px = np.array([[0, 1], [1, 0]], complex)
    pz = np.diag([1, -1])
    phi = np.array([1, 0, 0, 1], complex)/np.sqrt(2)
    corrections = [eye, px, pz, px@pz]
    bells = [np.kron(eye, op)@phi for op in corrections]
    inputs = [np.array([1, 0], complex), np.array([0, 1], complex)]
    inputs += [np.array([1, phase], complex)/np.sqrt(2)
               for phase in (1, -1, 1j, -1j)]
    fidelities = []
    for psi in inputs:
        joint = np.kron(np.outer(psi, psi.conj()), resource)
        blocks = joint.reshape(4, 2, 4, 2)
        output = np.zeros((2, 2), complex)
        for bell, correction in zip(bells, corrections):
            branch = np.einsum("i,iajb,j->ab", bell.conj(), blocks, bell)
            output += correction@branch@correction.conj().T
        assert abs(np.trace(output)-1) < 1e-10
        fidelities.append(float(np.vdot(psi, output@psi).real))
    return float(np.mean(fidelities))


def random_channel(dimension, environment_dimension, rng):
    raw = (rng.normal(size=(dimension*environment_dimension, dimension))
           + 1j*rng.normal(size=(dimension*environment_dimension, dimension)))
    isometry = np.linalg.qr(raw)[0]
    return [isometry[k*dimension:(k+1)*dimension, :]
            for k in range(environment_dimension)]


def random_sector_channel(rng):
    g, t, e, s = dicke_basis()
    BT, Ps = np.column_stack([g, t, e]), np.outer(s, s)
    triplet = random_channel(3, 4, rng)
    singlet = rng.normal(size=4)+1j*rng.normal(size=4)
    singlet /= np.linalg.norm(singlet)
    return [BT @ k @ BT.conj().T + c*Ps for k, c in zip(triplet, singlet)]


def save_csv(filename, header, rows):
    with (RESULTS/filename).open("w", newline="", encoding="utf-8") as stream:
        writer = csv.writer(stream)
        writer.writerow(header)
        writer.writerows(rows)


def axes_for_figure():
    fig, ax = plt.subplots(figsize=(4.8, 3.55))
    fig.subplots_adjust(left=.20, right=.97, bottom=.23, top=.72)
    ax.spines[["top", "right"]].set_visible(False)
    ax.grid(alpha=.15, linewidth=.6)
    ax.margins(x=0, y=0)
    return fig, ax


def isolate_pdf_font_subsets(path, panel):
    """Give each panel's embedded font subsets distinct PDF names.

    Matplotlib reuses subset names across independent PDFs. Distinct names
    prevent a PDF reader from reusing a different panel's incomplete subset
    when LaTeX includes several panels. Equal-length replacement preserves
    all stream lengths and cross-reference offsets.
    """
    original = path.read_bytes()
    updated = original
    fonts = set(re.findall(rb'/(?:BaseFont|FontName)\s+/([A-Z]{6}\+[^\s/<>()\[\]]+)', original))
    for font in sorted(fonts):
        digest = hashlib.sha256(panel.encode('ascii') + b'/' + font[6:]).digest()
        prefix = bytes(65 + value % 26 for value in digest[:6])
        replacement = prefix + font[6:]
        updated = updated.replace(b'/' + font, b'/' + replacement)
    assert len(updated) == len(original)
    path.write_bytes(updated)


def export_figure(fig, name):
    legend = fig.axes[0].get_legend()
    if legend is not None:
        legend.set_bbox_to_anchor((.5, .995), transform=fig.transFigure)
        legend.set_loc("upper center")
    # Draw the raster canvas before exporting the vector version as well.
    # This keeps tick labels consistent when a figure contains inset axes.
    fig.canvas.draw()
    for suffix in ("png", "pdf"):
        fig.savefig(FIGURES/(name+"."+suffix), dpi=240)
    isolate_pdf_font_subsets(FIGURES/(name+".pdf"), name)
    plt.close(fig)


def optimal_contrast(alpha, length):
    """Maximize N_thermal-N_accelerated at fixed alpha=a/omega, length=omega L.

    The optimization variable is w=Gamma*omega^2*L^2*tau/6.
    An independent broad time grid in main() checks the maximum.
    """
    q = np.exp(-2*np.pi/alpha)
    fa = correlation_factor(alpha, 1., length)
    ft = np.sinc(length/np.pi)
    C, R = (1+q)**2/(1+q+q*q), 1+alpha*alpha
    w0 = np.log(R)/(C*(R-1))
    objective = lambda w: -(closed_negativity(np.pi/2, q, ft, 6*w/length**2)
                          - closed_negativity(np.pi/2, q, fa, 6*w/length**2))
    solution = minimize_scalar(objective, bounds=(.02*w0, 5*w0),
                               method="bounded", options={"xatol":1e-9})
    return float(solution.x), float(-solution.fun)


def make_figures():
    """Plot the formulas without changing or displacing any data points.

    Line patterns and staggered marker positions distinguish nearby results.
    Insets show the actual difference from the asymptotic formula. The common
    lower coordinate bounds are zero, so no automatic padding precedes time 0.
    """
    RESULTS.mkdir(exist_ok=True)
    FIGURES.mkdir(exist_ok=True)
    plt.rcParams.update({"font.size":14, "axes.labelsize":16, "legend.fontsize":12,
                         "pdf.fonttype":42, "ps.fonttype":42})
    colors = ["#205b8d", "#c17b22", "#237e62"]
    patterns = ["-", "--", "-."]
    markers = ["o", "s", "^"]
    curve_rows, sample_rows, error_rows = [], [], []
    statistics = {"coordinate_origin": [0, 0], "data_displacement": 0,
                  "legends_outside_axes": True,
                  "distinct_pdf_font_subsets": True, "panels": {}}

    def add_samples(panel, series, xs, ys):
        sample_rows.extend([panel, series, x, y] for x, y in zip(xs, ys))

    def error_axes(ax, x_label, x_max, y_max, xticks, yticks):
        inset = ax.inset_axes([.59, .48, .39, .43])
        inset.spines[["top", "right"]].set_visible(False)
        inset.grid(alpha=.15, linewidth=.5)
        inset.set(xlim=(0, x_max), ylim=(0, y_max), xticks=xticks, yticks=yticks)
        inset.tick_params(labelsize=10, pad=1, length=2.5)
        inset.set_xlabel(x_label, fontsize=11, labelpad=0)
        inset.set_ylabel(r"$10^3|\delta\mathcal{N}|$", fontsize=11, labelpad=1)
        return inset

    fig, ax = axes_for_figure()
    zs = np.linspace(0, 8, 201)
    for k, (theta, label, color, style, marker) in enumerate(zip(
            (0, np.pi/4, np.pi/2),
            (r"$\theta=0$", r"$\theta=\pi/4$", r"$\theta=\pi/2$"),
            colors, patterns, markers)):
        ys = np.array([closed_negativity(theta, .4, 1, z) for z in zs])
        marked = [i for i in range(7+7*k, len(zs), 30) if ys[i] > .025]
        ax.plot(zs, ys, color=color, linestyle=style, lw=1.8, marker=marker,
                markevery=marked, ms=5, mfc="white", mew=1.1, label=label)
        curve_rows.extend(["collective", theta, .4, 1, z, y] for z, y in zip(zs, ys))
        add_samples("1a", "theta="+str(theta), zs, ys)
    ax.set(xlabel=r"$z=\Gamma\tau$", ylabel=r"$\mathcal{N}_{A|BCD}$",
           xlim=(0, 8), ylim=(0, 1.04), xticks=[0, 2, 4, 6, 8])
    ax.legend(frameon=False, ncol=3, handlelength=2.0, columnspacing=.9)
    statistics["panels"]["1a"] = {"series": 3, "x_range": [0, 8]}
    export_figure(fig, "collective")

    fig, ax = axes_for_figure()
    us = np.linspace(0, 4, 201)
    C = 1.4**2/(1+.4+.4**2)
    leading = np.exp(-C*us)
    ax.plot(us, leading, "k-", lw=1.7, label=r"$e^{-\mathcal{C}(q)u}$", zorder=1)
    inset = error_axes(ax, r"$u$", .7, 8.5, [0, .3, .6], [0, 4, 8])
    errors = {}
    for k, (eps, color, style, marker) in enumerate(zip(
            (.1, .03, .01), colors, ("--", "-.", ":"), markers)):
        ys = np.array([closed_negativity(np.pi/2, .4, 1-eps, u/eps) for u in us])
        marked = [i for i in range(6+9*k, len(us), 27) if ys[i] > .025]
        ax.plot(us, ys, color=color, linestyle=style, lw=1.25, marker=marker,
                markevery=marked, ms=5.7, mfc="white", mew=1.15,
                label=r"$\epsilon="+str(eps)+"$", zorder=2+k)
        difference = np.abs(ys-leading)
        inset.plot(us, 1000*difference, color=color, linestyle=style, lw=1.2,
                   marker=marker, markevery=(2+k, 7), ms=3.5, mfc="white", mew=.9)
        curve_rows.extend(["slow", np.pi/2, .4, 1-eps, u/eps, y]
                          for u, y in zip(us, ys))
        add_samples("1b", "epsilon="+str(eps), us, ys)
        error_rows.extend(["1b", "epsilon="+str(eps), u, error]
                          for u, error in zip(us, difference))
        errors[str(eps)] = float(difference.max())
    add_samples("1b", "slow limit", us, leading)
    ax.set(xlabel=r"$u=\epsilon\Gamma\tau$", ylabel=r"$\mathcal{N}_{A|BCD}$",
           xlim=(0, 4), ylim=(0, 1.04), xticks=[0, 1, 2, 3, 4])
    handles, labels = ax.get_legend_handles_labels()
    order = [1, 2, 3, 0]
    ax.legend([handles[i] for i in order], [labels[i] for i in order],
              frameon=False, ncol=2, handlelength=2.3, columnspacing=1.2)
    statistics["panels"]["1b"] = {"series": 4, "x_range": [0, 4],
                                 "maximum_absolute_errors": errors}
    export_figure(fig, "slow_decay")

    fig, ax = axes_for_figure()
    alpha, length = 2., .2
    q, R = np.exp(-2*np.pi/alpha), 1+alpha**2
    C = (1+q)**2/(1+q+q*q)
    ws = np.linspace(0, 3, 241)
    inset = error_axes(ax, r"$w$", 1.5, 14.5, [0, .75, 1.5], [0, 7, 14])
    errors = {}
    for k, (environment, f, rate, color, style, marker, leading_color) in enumerate([
            ("Accelerated vacuum", correlation_factor(alpha, 1., length),
             C*R, colors[0], "-", "o", "#237e62"),
            ("Thermal bath", np.sinc(length/np.pi),
             C, colors[1], "-.", "s", "#7651a8")]):
        ys = np.array([closed_negativity(np.pi/2, q, f, 6*w/length**2) for w in ws])
        leading = np.exp(-rate*ws)
        stem = "Acc." if k == 0 else "Therm."
        offset = 8+11*k
        indices = np.array([i for i in range(offset, len(ws), 25) if ys[i] > .025])
        ax.plot(ws, ys, color=color, linestyle=style, lw=1.9, marker=marker,
                markevery=indices.tolist(), ms=5.5, mfc="white", mew=1.1,
                label=stem+" exact", zorder=2)
        ax.plot(ws, leading, color=leading_color, linestyle="--" if k == 0 else ":",
                lw=1.5, label=stem+" leading", zorder=3)
        # Redraw the same marker positions above the nearly coincident lines.
        ax.plot(ws[indices], ys[indices], color=color, linestyle="none",
                marker=marker, ms=5.5, mfc="white", mew=1.1, zorder=4)
        difference = np.abs(ys-leading)
        inset.plot(ws, 1000*difference, color=color, linestyle=style, lw=1.2,
                   marker=marker, markevery=(3+6*k, 22), ms=3.5, mfc="white", mew=.9)
        curve_rows.extend([environment, np.pi/2, q, f, 6*w/length**2, y]
                          for w, y in zip(ws, ys))
        add_samples("2a", environment+" exact", ws, ys)
        add_samples("2a", environment+" leading", ws, leading)
        error_rows.extend(["2a", environment, w, error]
                          for w, error in zip(ws, difference))
        errors[environment] = float(difference.max())
    ax.set(xlabel=r"$w=\Gamma\omega^2 L^2\tau/6$", ylabel=r"$\mathcal{N}_{A|BCD}$",
           xlim=(0, 3), ylim=(0, 1.04), xticks=[0, 1, 2, 3])
    ax.legend(frameon=False, ncol=2, handlelength=2.3, columnspacing=1.0)
    statistics["panels"]["2a"] = {"series": 4, "x_range": [0, 3],
                                 "maximum_absolute_errors": errors}
    export_figure(fig, "environment_comparison")

    fig, ax = axes_for_figure()
    alphas = np.linspace(.1, 3.2, 151)
    Rs = 1+alphas**2
    limiting = (1-1/Rs)*Rs**(-1/(Rs-1))
    xs = np.r_[0., alphas]
    ax.plot(xs, np.r_[0., limiting], color=colors[0], lw=1.9,
            label="Small-separation limit")
    add_samples("2b", "small-separation limit", xs, np.r_[0., limiting])
    for k, (length, color, marker, style) in enumerate([
            (.4, colors[1], "o", "--"), (.15, colors[2], "s", "-.")]):
        deltas = np.array([optimal_contrast(value, length)[1] for value in alphas])
        ax.plot(xs, np.r_[0., deltas], color=color, linestyle=style, lw=1.3,
                marker=marker, markevery=(7+8*k, 19), ms=5.3, mfc="white", mew=1.1,
                label=r"$\omega L="+str(length)+"$")
        add_samples("2b", "omega L="+str(length), xs, np.r_[0., deltas])
    ax.set(xlabel=r"$a/\omega$", ylabel=r"$\Delta\mathcal{N}_{\max}$",
           xlim=(0, 3.2), ylim=(0, .75), xticks=[0, 1, 2, 3])
    ax.legend(frameon=False, ncol=1, handlelength=2.3)
    statistics["panels"]["2b"] = {"series": 3, "x_range": [0, 3.2],
                                 "zero_acceleration_contrast": 0.0}
    export_figure(fig, "optimal_contrast")

    save_csv("curves.csv", ["regime", "theta", "q", "f", "Gamma_tau", "negativity"], curve_rows)
    save_csv("figure_samples.csv", ["panel", "series", "x", "value"], sample_rows)
    save_csv("figure_errors.csv", ["panel", "series", "x", "absolute_error"], error_rows)
    (RESULTS/"figure_statistics.json").write_text(
        json.dumps(statistics, indent=2), encoding="utf-8")
    return statistics


def main():
    RESULTS.mkdir(exist_ok=True)
    FIGURES.mkdir(exist_ok=True)
    rng = np.random.default_rng(20261002)
    checks = {}
    errors, trace_errors, min_eigenvalue, cases = [], [], 1., 0
    for q in (0, .05, .4, .95):
        for f in (-.8, 0, .6, .995, 1):
            for theta in (0, .37, np.pi/4, np.pi/2, 2.2):
                for z in (0, .03, 1, 6):
                    for exchange in (0, 1.7):
                        rho = evolve(state(theta), q, f, z, exchange)
                        errors.append(abs(negativity(rho)-closed_negativity(theta, q, f, z)))
                        trace_errors.append(abs(np.trace(rho)-1))
                        min_eigenvalue = min(min_eigenvalue, float(np.linalg.eigvalsh(rho).min()))
                        cases += 1
    checks["full_density_cases"] = cases
    checks["maximum_formula_error"] = max(errors)
    checks["maximum_trace_error"] = float(max(trace_errors))
    checks["minimum_density_eigenvalue"] = min_eigenvalue
    assert max(errors) < 1e-10
    assert max(trace_errors) < 1e-10 and min_eigenvalue > -1e-10

    local_errors, sector_errors, decoder_errors, completeness = [], [], [], []
    g, t, e, s = dicke_basis()
    Ps, PT = np.outer(s, s), np.eye(4)-np.outer(s, s)
    V = np.kron(np.diag([1, 1j]), PT) + np.kron(np.diag([1, -1j]), Ps)
    Vfull = np.kron(np.eye(2), V)
    bell = np.array([1, 0, 0, 1])/np.sqrt(2)
    xi = (np.exp(1j*np.pi/4)*t+np.exp(-1j*np.pi/4)*s)/np.sqrt(2)
    for _ in range(24):
        local_ks = random_channel(2, 4, rng)
        for theta in (0, .4, np.pi/2):
            for side in (0, 1):
                kraus = [np.kron(k, np.eye(2)) if side == 0 else np.kron(np.eye(2), k)
                         for k in local_ks]
                local_errors.append(abs(negativity(channel_cd(state(theta), kraus))-1))
        kraus = random_sector_channel(rng)
        completeness.append(np.linalg.norm(sum(k.conj().T@k for k in kraus)-np.eye(4)))
        out = channel_cd(state(np.pi/2), kraus)
        sector_errors.append(abs(negativity(out)-1))
        expected = np.kron(np.outer(bell, bell),
                           apply_cd_operator(np.outer(xi, xi.conj()), kraus))
        decoder_errors.append(np.linalg.norm(Vfull@out@Vfull.conj().T-expected))
    # This channel really destroys triplet coherence; unitary-only tests would be vacuous.
    kraus = [Ps]+[np.outer(a, b)/np.sqrt(3) for a in (g, t, e) for b in (g, t, e)]
    for theta in (0, .4, np.pi/4, np.pi/2):
        sector_errors.append(abs(negativity(channel_cd(state(theta), kraus))-abs(np.sin(theta))))
    checks["random_local_channel_cases"] = len(local_errors)
    checks["nonunitary_sector_channels"] = 25
    checks["maximum_local_channel_error"] = max(local_errors)
    checks["maximum_sector_channel_error"] = max(sector_errors)
    checks["maximum_decoder_error"] = max(decoder_errors)
    assert max(local_errors+sector_errors+decoder_errors+completeness) < 1e-10

    phase_violation, recovery_error, zero_temperature_error = 0., 0., 0.
    resource_error, teleportation_error, recovery_bound_violation = 0., 0., 0.
    phase_cases = 0
    for q in (0, .1, .4, .9):
        for f in (-.8, 0, .7, .999, 1):
            for z in (.001, .1, 1, 8):
                maximum = closed_negativity(np.pi/2, q, f, z)
                for theta in np.linspace(0, 2*np.pi, 25):
                    N = closed_negativity(theta, q, f, z)
                    phase_violation = max(phase_violation, N-maximum, np.exp(-z)-N)
                    phase_cases += 1
                for theta in (.3, np.pi/2):
                    rec = recover_by_measurement(evolve(state(theta), q, f, z, 2.3))
                    nrec = recovered_formula(theta, q, f, z)
                    recovery_error = max(recovery_error,
                        abs(negativity_ab(rec)-nrec))
                    expected = np.zeros((4, 4), complex)
                    expected[0, 0] = expected[3, 3] = .5
                    expected[0, 3] = expected[3, 0] = nrec/2
                    resource_error = max(resource_error, np.linalg.norm(rec-expected))
                    teleportation_error = max(teleportation_error,
                        abs(average_teleportation_fidelity(rec)-(2+nrec)/3))
                    recovery_bound_violation = max(recovery_bound_violation,
                        nrec-closed_negativity(theta, q, f, z))
    for f in (-.9, 0, .7, 1):
        for z in (.01, .5, 3):
            for theta in (0, .4, np.pi/2):
                h = abs(np.sin(theta))
                predicted = np.exp(-z)*(h*abs(np.sinh(f*z))+
                                      np.sqrt(1+h*h*np.sinh(f*z)**2))
                zero_temperature_error = max(zero_temperature_error,
                    abs(predicted-closed_negativity(theta, 0, f, z)))
    checks.update(phase_cases=phase_cases, maximum_phase_violation=phase_violation,
                  maximum_recovery_error=recovery_error,
                  maximum_zero_temperature_error=zero_temperature_error,
                  maximum_recovered_state_error=resource_error,
                  maximum_teleportation_protocol_error=teleportation_error,
                  maximum_recovery_bound_violation=recovery_bound_violation)
    assert max(phase_violation, recovery_error, zero_temperature_error,
               resource_error, teleportation_error, recovery_bound_violation) < 1e-10

    spectra_errors = []
    for a in (.5, 1.3, 3.):
        omega, shift = .8, .07/a
        for length in (0, .2, 1.3):
            def integrand(x):
                G = -a*a/(16*np.pi*np.pi)/(np.sinh(a*(x-1j*shift)/2)**2-a*a*length*length/4)
                return float((np.exp(1j*omega*x)*G).real)
            numeric = 2*quad(integrand, 0, 60/a, epsabs=2e-11, limit=600)[0]
            expected = (omega/(2*np.pi*(1-np.exp(-2*np.pi*omega/a))) *
                        correlation_factor(a, omega, length)*np.exp(-omega*shift))
            spectra_errors.append(abs(numeric-expected))
    checks["maximum_numerical_spectral_transform_error"] = max(spectra_errors)
    assert max(spectra_errors) < 1e-8

    rate_rows = []
    for q in (.01, .1, .4, .9):
        C = (1+q)**2/(1+q+q*q)
        for eps in (1e-2, 1e-3, 1e-4):
            measured = slow_rate(q, 1-eps)/eps
            rate_rows.append([q, eps, measured, C, abs(measured-C)/C])
    assert max(row[4] for row in rate_rows if row[1] == 1e-4) < 1e-4
    save_csv("slow_rates.csv", ["q", "epsilon", "kappa_over_epsilon_Gamma",
                               "leading_prediction", "relative_error"], rate_rows)

    contrast_rows, ratio_rows = [], []
    for alpha in (.5, 1, 2, 3):
        q, R = np.exp(-2*np.pi/alpha), 1+alpha*alpha
        C = (1+q)**2/(1+q+q*q)
        leading_w, leading_delta = np.log(R)/(C*(R-1)), (1-1/R)*R**(-1/(R-1))
        for length in (.15, .05, .01):
            w, delta = optimal_contrast(alpha, length)
            contrast_rows.append([alpha, length, w, leading_w, delta, leading_delta])
            fa, ft = correlation_factor(alpha, 1., length), np.sinc(length/np.pi)
            ratio_rows.append([alpha, length, slow_rate(q, fa)/slow_rate(q, ft), R])
    assert max(abs(row[2]-row[3])/row[3] for row in ratio_rows if row[1] == .01) < 1e-3
    assert max(abs(row[4]-row[5]) for row in contrast_rows if row[1] == .01) < 1e-4

    # Check the optimum against a broad time grid, including the larger
    # separation used in figure 2(b), where leading-limit plots are insufficient.
    grid_excess = 0.
    for alpha in np.r_[.1, .2, np.linspace(.3, 3, 10), 3.1, 3.2]:
        q, R = np.exp(-2*np.pi/alpha), 1+alpha**2
        C = (1+q)**2/(1+q+q*q)
        w0 = np.log(R)/(C*(R-1))
        for length in (.15, .4):
            _, maximum = optimal_contrast(alpha, length)
            fa = correlation_factor(alpha, 1., length)
            ft = np.sinc(length/np.pi)
            grid = np.linspace(0, 10*w0, 401)
            contrasts = [closed_negativity(np.pi/2, q, ft, 6*w/length**2)
                         - closed_negativity(np.pi/2, q, fa, 6*w/length**2)
                         for w in grid]
            grid_excess = max(grid_excess, max(contrasts)-maximum)
    checks["maximum_contrast_time_grid_excess"] = grid_excess
    assert grid_excess < 1e-7
    save_csv("environment_rate_ratios.csv",
             ["a_over_omega", "omega_L", "rate_ratio", "limiting_ratio"], ratio_rows)
    save_csv("optimal_contrast.csv",
             ["a_over_omega", "omega_L", "exact_w_max", "leading_w_max",
              "exact_negativity_contrast", "leading_negativity_contrast"], contrast_rows)

    slope_error = 0.
    for q in (.01, .4, .9):
        for f in (0, .7, .99, 1):
            step = 1e-6
            measured = (closed_negativity(np.pi/2, q, f, step)-1)/step
            slope_error = max(slope_error, abs(measured+(1-f)))
    checks["maximum_initial_slope_error_at_step_1e_6"] = slope_error
    assert slope_error < 2e-6

    make_figures()
    checks["status"] = "passed"
    checks["scope"] = ("Exact finite-dimensional channel identities and the stated secular GKSL "
                       "generator. No uniform microscopic memory-error estimate is inferred.")
    (RESULTS/"validation.json").write_text(json.dumps(checks, indent=2), encoding="utf-8")
    print(json.dumps(checks, indent=2))


if __name__ == "__main__":
    main()
