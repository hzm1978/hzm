"""Check the explicit v4 readout derivation and generate a pedagogical plot.

All assertions concern the given finite-dimensional channel. No microscopic
long-time accuracy or unrestricted recovery optimality is inferred.
"""
from pathlib import Path
import csv
import json
import numpy as np
from scipy.linalg import expm
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from model import state, evolve, negativity
from validate import (dicke_basis, population_difference, closed_negativity,
                      recovered_formula, population_matrix, recover_by_measurement,
                      negativity_ab, channel_cd, isolate_pdf_font_subsets)

ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / "results"
FIGURES = ROOT / "figures"


def save(name, header, rows):
    with (RESULTS/name).open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(header)
        w.writerows(rows)


def main():
    RESULTS.mkdir(exist_ok=True)
    FIGURES.mkdir(exist_ok=True)
    basis = dicke_basis()
    errors, probability_errors = [], []
    for q in (0, .1, .4, .9):
        for f in (-.5, 0, .97, 1):
            for theta in (0, .37, np.pi/4, np.pi/2):
                alpha = np.sin(theta)/2
                b, c = (1+np.cos(theta))/2, (1-np.cos(theta))/2
                for z in (0, .5, 4):
                    rho = evolve(state(theta), q, f, z, exchange=1.7)
                    blocks = rho.reshape(4, 4, 4, 4)
                    pt = expm(population_matrix(q, f)*z)[:, 1]
                    ps = expm(population_matrix(q, f)*z)[:, 3]
                    for j, ket in enumerate(basis):
                        projected = np.einsum("i,aibj,j->ab", ket.conj(), blocks, ket)
                        analytic = np.zeros((4, 4), complex)
                        analytic[0, 0] = (b*pt[j]+c*ps[j])/2
                        analytic[3, 3] = (c*pt[j]+b*ps[j])/2
                        analytic[0, 3] = 1j*alpha*(pt[j]-ps[j])/2
                        analytic[3, 0] = analytic[0, 3].conjugate()
                        errors.append(float(np.linalg.norm(projected-analytic)))
                        probability_errors.append(float(abs(np.trace(projected)-(pt[j]+ps[j])/2)))
    assert max(errors) < 1e-11
    assert max(probability_errors) < 1e-11

    g, t, e, s = basis
    Ps = np.outer(s, s)
    PT = np.eye(4)-Ps
    swap = PT-Ps
    K0 = np.outer(g, g)+np.outer(e, e)+Ps
    K1 = np.outer(s, t)
    assert np.linalg.norm(K0.conj().T@K0+K1.conj().T@K1-np.eye(4)) < 1e-12
    assert np.linalg.norm(K1@Ps-Ps@K1) > .9
    rng = np.random.default_rng(20261103)
    covariance_errors = []
    channel = lambda x: K0@x@K0.conj().T+K1@x@K1.conj().T
    for _ in range(20):
        x = rng.normal(size=(4, 4))+1j*rng.normal(size=(4, 4))
        x = x@x.conj().T
        x /= np.trace(x)
        covariance_errors.append(float(np.linalg.norm(channel(swap@x@swap)-swap@channel(x)@swap)))
    counterexample_errors = []
    target = np.kron(np.diag([.5, 0, 0, .5]), Ps)
    for theta in np.linspace(0, 2*np.pi, 12, endpoint=False):
        out = channel_cd(state(theta), [K0, K1])
        counterexample_errors.append(float(np.linalg.norm(out-target)))
        assert abs(negativity(out)) < 1e-11
    assert max(covariance_errors) < 1e-11
    assert max(counterexample_errors) < 1e-11

    plt.rcParams.update({"font.size": 12, "axes.labelsize": 13,
                         "pdf.fonttype": 42, "ps.fonttype": 42})
    fig, axes = plt.subplots(1, 2, figsize=(7.4, 3.6))
    fig.subplots_adjust(left=.09, right=.98, bottom=.20, top=.78, wspace=.29)
    q, f, theta = .4, .97, np.pi/4
    eps, h = 1-f, abs(np.sin(theta))
    C = (1+q)**2/(1+q+q*q)
    samples, markers, point_errors = [], [], []
    for panel, ax, xs, points in [
        ("fast", axes[0], np.linspace(0, 6, 241), [0, .25, .5, 1, 2, 4, 6]),
        ("slow", axes[1], np.r_[0, np.geomspace(1e-4, 3, 300)], [0, .05, .1, .3, .8, 1.5, 3])]:
        zs = xs if panel == "fast" else xs/eps
        full = np.array([closed_negativity(theta, q, f, z) for z in zs])
        rec = np.array([recovered_formula(theta, q, f, z) for z in zs])
        leading = h*np.exp(-C*eps*zs)
        ax.plot(xs, full, color="#205b8d", lw=1.8, label=r"Full $\mathcal{N}_{A|BCD}$")
        ax.plot(xs, rec, color="#c17b22", lw=1.7, linestyle="--", label=r"Recovered $\mathcal{N}_{\rm rec}$")
        ax.plot(xs, leading, color="#7651a8", lw=1.5, linestyle=":", label="Leading slow envelope")
        for x, z, n, r, lead in zip(xs, zs, full, rec, leading):
            samples.append([panel, x, z, n, r, lead])
        for x in points:
            z = x if panel == "fast" else x/eps
            rho = evolve(state(theta), q, f, z)
            n = negativity(rho)
            r = negativity_ab(recover_by_measurement(rho))
            point_errors += [abs(n-closed_negativity(theta, q, f, z)),
                             abs(r-recovered_formula(theta, q, f, z))]
            ax.plot(x, n, "o", color="#205b8d", ms=4.8, mfc="white", mew=1.0)
            ax.plot(x, r, "s", color="#c17b22", ms=4.5, mfc="white", mew=1.0)
            markers.append([panel, x, z, n, r])
        ax.set_xlim(0, 6 if panel == "fast" else 3)
        ax.set_ylim(0, 1.04)
        ax.set_xlabel(r"$z=\Gamma\tau$" if panel == "fast" else r"$u=\epsilon\Gamma\tau$")
        ax.set_ylabel("Negativity")
        ax.set_title("(a) Fast stage" if panel == "fast" else "(b) Slow stage", fontsize=12)
        ax.spines[["top", "right"]].set_visible(False)
        ax.grid(alpha=.15, linewidth=.6)
    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="upper center", bbox_to_anchor=(.5, 1.0),
               ncol=3, frameon=False, fontsize=10, columnspacing=1.0)
    for suffix in ("pdf", "png"):
        fig.savefig(FIGURES/("recovery_stages."+suffix), dpi=240)
    isolate_pdf_font_subsets(FIGURES/"recovery_stages.pdf", "recovery_stages_v4")
    plt.close(fig)
    assert max(point_errors) < 1e-10
    save("recovery_stages_curves.csv",
         ["panel", "x", "Gamma_tau", "full_negativity", "recovered_negativity", "leading_slow"], samples)
    save("recovery_stages_markers.csv",
         ["panel", "x", "Gamma_tau", "full_density_negativity", "measured_resource_negativity"], markers)
    result = {"status": "passed", "full_state_cases": len(errors)//4,
              "conditional_branches": len(errors),
              "maximum_conditional_matrix_Frobenius_error": max(errors),
              "maximum_outcome_probability_error": max(probability_errors),
              "exchange_covariance_cases": len(covariance_errors),
              "maximum_exchange_covariance_error": max(covariance_errors),
              "sector_erasure_phases": len(counterexample_errors),
              "maximum_sector_erasure_state_error": max(counterexample_errors),
              "figure_full_state_points": len(markers),
              "maximum_figure_point_error": float(max(point_errors)),
              "scope": "Finite-dimensional effective model and an explicit diagnostic CPTP channel; no additional microscopic validity claim."}
    (RESULTS/"clarity_validation.json").write_text(json.dumps(result, indent=2))
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
