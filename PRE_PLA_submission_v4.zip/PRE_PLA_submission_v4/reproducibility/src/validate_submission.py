"""Additional PLA-revision checks: boundary cases and asymptotic convergence.

These calculations test the stated effective GKSL dynamics. They provide no
uniform microscopic long-time error estimate or proof of literature priority.
"""
from pathlib import Path
import csv
import json
import platform
import numpy as np
import scipy
from scipy.linalg import eigvals
from scipy.optimize import minimize_scalar
from model import evolve, state, negativity
from validate import (population_matrix, population_difference, closed_negativity,
                      recovered_formula, correlation_factor)

ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / "results"


def compact_formula(theta, q, f, z):
    dg, dt, de, ds = population_difference(q, f, z)
    h, E = abs(np.sin(theta)), np.exp(-2*z)
    K = (dt*dt + ds*ds - 2*E + 2*abs(dt*ds + E))/4
    assert K > -1e-12
    return h*(abs(dg)+abs(de))/2 + np.sqrt(max(0, E+h*h*K))


def write_csv(name, header, rows):
    with (RESULTS/name).open("w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(header)
        writer.writerows(rows)


def main():
    RESULTS.mkdir(exist_ok=True)
    comparisons = []
    # Includes the zero-temperature boundary, f=0 degeneracy, exact collective
    # limits, and near-collective evolution at late dimensionless times.
    for q in (0, .01, .4, .95):
        for f in (-1, 0, .6, .999, 1):
            for theta in (0, .37, np.pi/2):
                for z in (0, .01, 1, 12, 500):
                    exact = negativity(evolve(state(theta), q, f, z, 1.7))
                    compact = compact_formula(theta, q, f, z)
                    comparisons.append(abs(exact-compact))
    assert max(comparisons) < 1e-10

    rates, slow_errors = [], []
    for q in (.01, .1, .4, .9):
        C = (1+q)**2/(1+q+q*q)
        for eps in (.1, .05, .02, .01, .005, .002):
            spectrum = sorted(eigvals(population_matrix(q, 1-eps)).real,
                              reverse=True)
            measured_rate = -spectrum[1]
            rates.append([q, eps, measured_rate, eps*C,
                          abs(measured_rate/(eps*C)-1)])
            for theta in (.37, np.pi/2):
                for u in (.5, 1., 2.):
                    leading = abs(np.sin(theta))*np.exp(-C*u)
                    full = compact_formula(theta, q, 1-eps, u/eps)
                    rec = recovered_formula(theta, q, 1-eps, u/eps)
                    slow_errors.append([q, eps, theta, u, full, rec, leading,
                                        abs(full-leading), abs(rec-leading)])
        subset = [row for row in rates if row[0] == q]
        assert subset[-1][4] < subset[0][4]
        for theta in (.37, np.pi/2):
            for u in (.5, 1., 2.):
                subset = [row for row in slow_errors
                          if row[0] == q and row[2] == theta and row[3] == u]
                assert subset[-1][7] < subset[0][7]
                assert subset[-1][8] < subset[0][8]

    contrast = []
    for alpha in (.5, 1., 2., 3.):
        q, R = np.exp(-2*np.pi/alpha), 1+alpha*alpha
        C = (1+q)**2/(1+q+q*q)
        wstar = np.log(R)/(C*(R-1))
        limiting = (1-1/R)*R**(-1/(R-1))
        for length in (.4, .2, .1, .05):
            fa = correlation_factor(alpha, 1., length)
            ft = np.sinc(length/np.pi)
            def delta(w):
                z = 6*w/length**2
                return (compact_formula(np.pi/2, q, ft, z)
                        - compact_formula(np.pi/2, q, fa, z))
            # Broad grid first, then an independent bracket around its maximum.
            grid = np.geomspace(1e-5*wstar, 100*wstar, 501)
            values = np.array([delta(w) for w in grid])
            i = int(values.argmax())
            assert 0 < i < len(grid)-1
            solution = minimize_scalar(lambda w: -delta(w),
                                      bounds=(grid[i-1], grid[i+1]),
                                      method="bounded",
                                      options={"xatol": 1e-10})
            observed = -solution.fun
            assert observed >= values.max()-1e-9
            contrast.append([alpha, length, solution.x, wstar, observed,
                             limiting, abs(solution.x-wstar),
                             abs(observed-limiting)])
        subset = [row for row in contrast if row[0] == alpha]
        assert subset[-1][6] < subset[0][6]
        assert subset[-1][7] < subset[0][7]

    write_csv("submission_slow_rates.csv",
              ["q", "epsilon", "exact_rate_over_Gamma", "leading_rate_over_Gamma",
               "relative_rate_error"], rates)
    write_csv("submission_slow_law.csv",
              ["q", "epsilon", "theta", "u", "full_negativity",
               "specified_recovery", "leading", "full_absolute_error",
               "recovery_absolute_error"], slow_errors)
    write_csv("submission_contrast.csv",
              ["a_over_omega", "omega_L", "optimized_w", "leading_w",
               "optimized_contrast", "leading_contrast", "time_error",
               "contrast_error"], contrast)
    report = {
        "status": "passed", "full_density_boundary_cases": len(comparisons),
        "maximum_compact_formula_error": float(max(comparisons)),
        "slow_rate_cases": len(rates), "slow_law_cases": len(slow_errors),
        "contrast_cases": len(contrast),
        "maximum_relative_rate_error_at_epsilon_0_002": max(
            row[4] for row in rates if row[1] == .002),
        "maximum_slow_law_error_at_epsilon_0_002": max(
            row[7] for row in slow_errors if row[1] == .002),
        "maximum_contrast_error_at_omega_L_0_05": max(
            row[7] for row in contrast if row[1] == .05),
        "convergence": "For each sampled parameter family, endpoint errors decrease as epsilon or separation decreases; this is numerical evidence, not a uniform error theorem.",
        "scope": "Specified effective GKSL generator only.",
        "versions": {"python": platform.python_version(), "numpy": np.__version__,
                     "scipy": scipy.__version__},
    }
    (RESULTS/"submission_validation.json").write_text(json.dumps(report, indent=2))
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
