# 中文编译兼容宏包

本目录提供 xeCJK 3.9.1、其配置和配套文件，以及 CTEX hook 2.5.10。源文件保持原样，版权声明保留在各文件头部。许可证为 LPPL 1.3c 或更新版本，完整文本见 `LPPL.txt`。

当系统中已安装 `xeCJK.sty` 时，中文稿使用系统版本。缺少该宏包时，中文稿自动将本目录加入 LaTeX 搜索路径，加载随包版本及依赖。用户无需配置 `TEXINPUTS`。

这些文件仍要求 XeLaTeX 和 TeX 发行版内的 `expl3`、`xtemplate`、`fontspec` 等基础宏包。

未修改的发行包来源：

- <https://ftp.math.utah.edu/pub/tex/historic/systems/texlive/2023/tlnet-final/archive/xecjk.tar.xz>
- <https://ftp.math.utah.edu/pub/tex/historic/systems/texlive/2023/tlnet-final/archive/ctex.tar.xz>

相应的原始源文件置于 `source/`。源代码包来自相同目录中的 `xecjk.source.tar.xz` 和 `ctex.source.tar.xz`。维护项目：<https://github.com/CTeX-org/ctex-kit>。
