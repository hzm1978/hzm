# Foundations of Physics: requirements checked on 4 November 2026

| Item | Official information | Treatment in v9 |
|---|---|---|
| Scope | Conceptual/foundational aspects of quantum theory, field theory, relativity and information | One organizing question: inference from local field measurements to resource certification |
| Review route | “Prospective authors of review-type articles are encouraged to first contact the Editor-in-Chief with their proposal.” | Proposal and email text drafted; not sent. This is encouragement, not an invitation-only rule |
| Abstract | 150–250 words; no undefined abbreviations or unspecified citations | 194 words by the archive's word-count rule; no references |
| Keywords | 4–6 | 6 |
| Author details | Name, affiliation and corresponding email; ORCID if available | Author/affiliation/email recovered from supplied same-author sources; no invented ORCID |
| Editable sources | Relevant editable sources required at submission/revision | Main/SI .tex, .bib, .bbl, official .cls/.bst, figures and build helper |
| Citations | Numeric references ordered by first appearance; DOI as full link when available | Official sn-mathphys-num.bst; 102 used records; 96 DOI fields; no guessed Wald DOI |
| Preprints | Springer policy expressly permits preprint citations | 5 versioned preprints explicitly identified; no invented journal status |
| Declarations | Funding, interests, contributions, relevant data/code statements; document substantive LLM use | Separate declarations included; user-supplied no-funding/no-conflict facts retained; AI work disclosed |
| Length | No strict review word/page cap found on the pages checked | Focused main article and technical SI; no invented limit imposed |
| Publication route | Subscription publication and optional open access are distinct | No OA purchase or publication transaction initiated |

Sources:

- [Aims and scope](https://link.springer.com/journal/10701/aims-and-scope)
- [Submission guidelines](https://link.springer.com/journal/10701/submission-guidelines)
- [Publishing options](https://link.springer.com/journal/10701/how-to-publish-with-us)
- [Springer journal policies, including preprints](https://link.springer.com/brands/springer/journal-policies): “Preprints may be cited in the reference list of articles under consideration at Springer Nature journals …”
- [Springer Nature LaTeX author support](https://www.springernature.com/gp/authors/campaigns/latex-author-support)

The official LaTeX files were obtained from the December 2024 package linked by the current author-support page. Their unmodified hashes are recorded in validation_v9.json and provenance/template_retrieval.json. The main article uses the numeric physics style and is built with XeLaTeX. The class's `pdflatex` option is retained to avoid its obsolete breakurl route; compilation is explicitly XeLaTeX because fontspec is used.

These checks concern preparation. No communication with the journal or editorial approval is implied. Submission-system facts such as concurrent-submission status must be entered accurately by the author; they were not fabricated in the cover-letter draft.
