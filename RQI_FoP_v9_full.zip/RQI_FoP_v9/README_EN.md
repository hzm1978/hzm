# FoP review: English submission materials, v9

Title: **From local quantum-field measurements to certified resources**  
Author: Zhiming Huang  
Prepared: 4 November 2026

The main article is a critical narrative review. The English main/SI PDFs and editable sources form the scientific submission materials. The editorial directory contains a review proposal, a presubmission-email draft, and a cover-letter draft. None has been sent or submitted.

## Build

Use a complete TeX Live installation with XeLaTeX, latexmk, BibTeX, and the packages used by the included sources. Run from this directory:

```bash
python build_manuscripts.py --language en
```

The helper compiles the main article, exports its labels, and then compiles the supplement. Keep `fop_review_en_v9_labels.aux` with the supplement source for cross-references. The included `.bbl` files preserve the built bibliographies. `sn-jnl.cls` and `sn-mathphys-num.bst` are official, unmodified Springer Nature files. Figures are vector PDFs in `figures/`.

The English-only archive does not contain the Chinese reading copies. The complete bilingual archive additionally contains a document-audit script, revision notes, reference/source records and verification logs. References are numbered separately in the main article and supplement; supplement equations carry the S prefix.

## Reproducibility

See `reproducibility/README.md`. The scripts check the specified examples and archived scan data. They do not supply an all-orders continuum detector calculation, certify an actual experimental output, or independently prove all cited papers. The distinction between exact identities, perturbative diagnostics and numerical convergence is explicit in the manuscripts.

FoP encourages prospective review authors to contact the Editor-in-Chief with a proposal first. The proposal is prepared for that purpose. Before any actual submission, the author remains responsible for the final text, attributions and truthful submission-system declarations.
