# Foundations of Physics 定向修订稿 v9

修订日期：2026-11-04。基于本次 review.zip 的 v8 修订稿，目标期刊为 **Foundations of Physics**。这是一篇批判性叙述综述。英文正文使用 Springer Nature 官方 LaTeX 模板。

题目：**From local quantum-field measurements to certified resources**  
中文题目：**从量子场的局域测量到可靠的资源认证**

## 先看哪些文件

| 用途 | 文件 |
|---|---|
| 英文正文，拟投稿版本 | [fop_review_en_v9.pdf](fop_review_en_v9.pdf) |
| 中文阅读对照稿 | [fop_review_zh_v9.pdf](fop_review_zh_v9.pdf) |
| 英文补充材料 | [fop_supplement_en_v9.pdf](fop_supplement_en_v9.pdf) |
| 中文补充材料 | [fop_supplement_zh_v9.pdf](fop_supplement_zh_v9.pdf) |
| 给编辑的综述提案 | [editorial/review_proposal_en.pdf](editorial/review_proposal_en.pdf) |
| 正式投稿信草稿 | [editorial/cover_letter_en.pdf](editorial/cover_letter_en.pdf) |
| 提案邮件正文草稿 | [editorial/presubmission_email_en.txt](editorial/presubmission_email_en.txt) |
| 修改理由、处理的问题和投稿状态 | [REVISION_REPORT_v9_zh.md](REVISION_REPORT_v9_zh.md) |
| 期刊要求核查 | [JOURNAL_REQUIREMENTS_v9.md](JOURNAL_REQUIREMENTS_v9.md) |
| 文献与计算核验的实际范围 | [SOURCE_AUDIT_v9.md](SOURCE_AUDIT_v9.md) |

正文集中为八节，补充材料为七节。正文六张比较表，补充材料两幅矢量图和一张数据表。正文不再平行铺陈黑洞径向散射、未经控制的区域互信息 ansatz 等支线。

## 本次最关键的修改

1. 主线改为：局域场测量怎样支持一个可靠的资源主张。明确对照 Papageorgiou–Fraser 在 FoP 的 2024 年综述，说明本文继续讨论操作/记录到资源认证的推断。
2. 增加相同 POVM、不同测量反作用的具体例子和证明，同时说明：保留的探针输出还需要完整的系统—装置实现。
3. 数据处理上界补齐场与探针初态的乘积假设、相对熵和维数定义；场区域包含完整相互作用支撑，闭支撑采用小的正扩大。
4. 严格区分二阶点极限系数、精确有限耦合结果和数值积分收敛，不交换未经证明的极限。
5. 补出四比特双可分反例的解析谱论证，以及簇态局域信道不变性的约化态证明。
6. 将模型误差、实际见证测量误差和资源来源归因分开；统一负期望纠缠见证的置信上界约定。
7. 保留并限定近期语境性、复合耦合、实验与实现方案的结论。102 条参考文献全部在正文中引用，96 条带已核对 DOI，5 条明确引用预印本版本。

## 如何编译和复核

保留 `.tex`、`.bib`、官方 `.cls/.bst`、矢量图和英文/中文正文标签文件。`.bbl` 也随包提供。推荐在完整 TeX Live 环境或 Overleaf 中以 **XeLaTeX** 编译。

```bash
python build_manuscripts.py --language both
python audit_fop_v9.py
```

英文单独编译：

```bash
python build_manuscripts.py --language en
```

`build_manuscripts.py` 先编正文，再导出供补充材料引用的标签，最后编补充材料。不要先单独编补充材料并忽略正文标签。中文需 ctex 与 Noto Serif CJK SC 或 Fandol 字体。

文档审计另需 PyMuPDF，可用 `python -m pip install -r requirements-audit.txt` 安装。

数值复核入口见 [reproducibility/README.md](reproducibility/README.md)。`validation_v9.json` 记录文档一致性检查，`reproducibility/results/fop_v9_verification.json` 记录指定计算的复核结果。通过这些检查不等于所有引用文献均获独立验证。

## 使用与投稿状态

英文材料已整理完整，可用于综述提案及后续送审准备；中文版本用于核对内容。期刊官网**鼓励**综述作者先联系主编并提供提案，不是仅限邀请投稿。本包已备好提案、邮件正文和投稿信，**尚未发送邮件或提交期刊**。

作者姓名、单位及邮箱沿用同一作者已提供稿件中的信息；资助和利益冲突声明沿用已提供的“无”。未编造 ORCID、作者既有综述发表记录、编辑邀请或录用状态。正式提交时，作者仍须核实稿件最终内容及投稿系统中的事实声明。
