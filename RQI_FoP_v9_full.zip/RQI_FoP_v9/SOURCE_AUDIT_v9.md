# Source and verification audit: FoP v9

Date: 4 November 2026. This version adapts the v8 revision of the uploaded review.zip (input ZIP SHA256 `151e2add96223823d17bc240bc50f4e2dfa0308813c47780c6fc09e4b11fe507`). The PRE/PLA and DML manuscripts are different projects and are not sources for this article's scientific content.

## Evidence levels

A metadata match, obtaining a source PDF, targeted reading, and independently reproducing a stated calculation are different evidence levels. This archive distinguishes them. It does not claim an exhaustive literature/priority search, cover-to-cover reading of every reference, a full audit of all cited theorems, or experimental reanalysis.

The narrative-review update used topic/title searches, arXiv records, Crossref DOI/title queries, and an INSPIRE identification of the differently titled Lima preprint in v8. V9 retains the directly relevant results, checks the closest FoP review and the journal's current author instructions, and extends bibliographic checks to the retained classical sources. The older v8 reading is identified as inherited evidence. Full third-party source PDFs and full source abstracts are not redistributed.

## Closest review and the actual difference

**Papageorgiou and Fraser (2024), FoP 54:26, DOI https://doi.org/10.1007/s10701-024-00756-8.** The publisher's 75-page PDF was obtained. Targeted reading covered the abstract/introduction on pp. 1–3, discussion/conclusion on pp. 66–70, and the Sorkin reference on p. 70. This is not a line-by-line proof check of all 75 pages.

That review's comparison of detector, FV/algebraic and histories-based approaches is organized around impossible-measurement scenarios, causal consistency, dynamics, local algebras and state updates. V9 explicitly builds on it. V9 follows the additional inference to a specified retained probe resource, a scenario-dependent criterion and a calibrated certificate. It does not claim that the earlier review never discusses harvesting or that elementary channel inequalities are new theorems. The simple instrument, geometric-support, mixed-state and witness examples make the inference conditions checkable; they are not claimed as a universal resource theory.

**Watrous (2018), The Theory of Quantum Information, DOI https://doi.org/10.1017/9781316848142.** Book identity was verified through Crossref. The author's public chapter-5 PDF was obtained; targeted reading used pp. 280–283, especially Theorems 5.35 and 5.38 on relative-entropy monotonicity and quantum Pinsker. The book uses logarithms to base two. V9 explicitly uses natural logarithms and the converted constant. No claim is made of rereading the entire book or proving the operator-algebraic extension from a finite-dimensional textbook.

## Retained source-level checks from v8

| Source | Targeted material actually used | Limit retained in v9 |
|---|---|---|
| Campos Delgado–Ipek, arXiv:2610.41964v1 | Definitions, conditional channel proposition, gapless construction, discussion and proof appendix | Transport is reproduced conditionally. No arbitrary finite-coupling no-go is inferred; fixed-scenario contextual fractions are distinct |
| Mandrysch–Simmons–Navascués, arXiv:2607.12976v2 | Introduction and conclusion/discussion of causal versus FV-realizable operations | Not all 65 pages or the undecidability proof independently verified; neither causality nor FV is identified with every physical apparatus |
| Zambianco–Ragula–Martín-Martínez, arXiv:2607.13131v1 | Setup, pointlike Eqs. (33)–(50), Gaussian spatial analysis, conclusion | Local Eq. (35) and displayed cross reduction (44) require distinction. S6 derives a separated 1+1-dimensional kernel, not a blanket rejection of the smeared calculation |
| Morote-Balboa–Perche, arXiv:2604.06303v4 | Switching normalization, optimization hypotheses and perturbative limitations | Optimization not independently rerun; large second-order coefficients do not certify finite-coupling gain |
| Salomaa et al., arXiv:2604.13869v1 | Model, leading block, alternating-chain scaling, conclusion | No all-orders detector-number scaling or fixed-total-resource advantage proved |
| Perche–Gozzini–Oberthaler, arXiv:2512.21381v3 | Microscopic mapping, phononic approximation, main-text feasibility/readout estimates, especially pp. 4–5 | Source estimates remain proposals. No raw experiment or independent platform-specific precision optimization |
| LeMaitre, arXiv:2508.11773v5 | Measurement scenario, contextual fraction and harvesting criterion | No independent reproduction of contextual-fraction linear programs |
| Lima et al., arXiv:2508.15001v2 | Heisenberg–Weyl settings and contextual-fraction definitions | Public full text identified via INSPIRE after publisher-PDF access failure; numerical plots not rerun |
| Li et al. W, arXiv:2502.05881v2 | First-order state (11)–(15), second-order coefficients (B7)–(B8) | Truncated matrix and formal trace norm reconstructed; determinant −3ν⁴/64 derived; high-q branch not promoted to exact revival |
| Wu et al. Dicke, arXiv:2605.24424v2 | Matrix (10)–(13), negativity/residual (18)–(22) | Source matrix matches the normalized first-order diagnostic; residual π4 is distinguished from mixed-state GME |
| Herter et al., Nature Communications 17, 2863 (2026) | Experimental observables, results and methods | Vacuum/source correlation measurement is distinguished from reduced-probe entanglement certification; raw data not reanalyzed |
| Lindel et al., arXiv:2311.04642v2 | EOS model, proposed witness, relation to correlation sampling | Proposal, not an observed harvesting certificate; optical dynamics not fully reproduced |
| Teixidó-Bonfill et al., arXiv:2505.01516v2 | Circuit mapping, derivative coupling, soft cutoff and variable gap | No circuit simulation independently reproduced |
| Hirche et al., arXiv:2608.27171v1 | Definitions and MI/CMI contraction relations | V9 S2 also supplies a direct replacement-flag proof for the particular noise bound used |
| Panebianco–Wegener, arXiv:2110.05823v3 | Nuclearity and regional mutual-information conditions | No generic tensor factorization or finite mutual information assumed. V9 rechecked the arXiv page and a Crossref title query; no matching journal record was identified, so the explicit preprint citation is retained |

The retained retrieval manifest contains 15 inherited source-PDF records and the two new v9 PDF records above. The v8 Star-state branch and an uncited modular-probe source are not part of v9. This count is not a count of independently validated papers.

## Bibliographic identity checks

- `source_inventory_v9.csv` lists the 102 references in first-main-citation order, including metadata status and full-text scope. All 102 are cited in the main article; 18 also occur in the supplement. Each document's numeric list follows its own first appearance.
- `reference_checks_v9.json` records all 102 entries. The 93 journal articles have DOI metadata matches from v8 or the v9 inspection; three books and one chapter are checked separately. Five entries deliberately cite versioned preprints.
- 96 records carry a DOI. Wald's 1994 book is verified on the University of Chicago Press page and linked there. A guessed DOI returning 404 was rejected.
- Title-only hits were not accepted as identity checks. For CHSH, the Fox–Rosner follow-up and the 1970 erratum were rejected in favor of the 1969 four-author PRL. For Anastopoulos–Hu–Savvidou, the 2023 Annals of Physics DOI was used rather than the SSRN posting. Bell, Horodecki and Polo-Gómez needed direct DOI lookups after poor title-query results.
- Devetak's and Lloyd's published titles and Louko–Satz's final page were corrected. DOI, author, year, volume and page/article number were inspected together for candidate matches.
- Cambridge's live Sorkin chapter page and Crossref give an internally inconsistent 1956 print date for proceedings of the 1993 symposium. The chapter title, author, pp. 293–305 and DOI match; the 1993 year is retained, also documented in Papageorgiou–Fraser reference 1. That metadata error was not copied into the manuscript.

## Calculations and proofs checked in v9

1. The same-effects instrument example: effects I/2; Bell input; conventional negativities 1/2 and 0; a nontrivial local trace-preserving channel leaves an untouched marginal invariant.
2. Three- and four-qubit biseparable counterexamples. V9 additionally derives the four-qubit analytic spectrum using a parity-sector isometry and checks the negative eigenvalues −1/3, −1/12, −1/12 and pair-marginal form directly.
3. Cluster-state invariance under arbitrary local CPTP dynamics on D: proof uses the explicit flagged-Bell marginal, partial trace and the qubit negativity cap. Numerical checks cover amplitude damping, dephasing and replacement channels at stated parameter points; the general statement follows from the proof, not the grid.
4. Source-specific first-order W/Dicke turning points and normalization corrections; second-order W density truncation and its negative compression determinant. These are diagnostics of the displayed expressions, not exact detector dynamics.
5. The Pauli witness identity, sufficient Hoeffding/union bound, illustrative n=489 per setting and a binomial-tail consistency calculation. No experimental certificate is asserted.
6. The 1+1-dimensional separated energy-density kernel in chiral and Cartesian forms, plus a finite strictly spacelike cross integral as the regulator is removed. This is not a full local-response/harvesting calculation.
7. A finite-channel example of the conditional noncontextual-model transport identity; the general result has an explicit proof. Invertible approximants and a dephasing limit illustrate the limiting pitfall.
8. A rank-one Fisher example and numerical consistency of the bounded-witness trace-norm convention. General statements follow from the analytical score factorization and Hölder inequality.
9. JC sums, cutoff-30/40 comparison, table and scan consistency; compact-support Fourier reconstruction at two cutoff/quadrature settings. These are numerical convergence diagnostics. The pointlike limit is explicitly for the second-order coefficient; no uniform higher-order remainder in detector size is established.

Results are recorded in `reproducibility/results/` and successful logs in `provenance/`. Document consistency, bilingual equation/label numbering, first-citation order, 8/7 section structure, assets and PDF checks are recorded in `validation_v9.json`. A PASS is restricted to the checks actually implemented.

## Journal and editorial checks

The official scope accepts review-type articles and **encourages**, rather than requires, prior contact with the Editor-in-Chief. The proposal and cover letter are drafts. No email, submission, editor response or invitation is asserted.

The main English article uses official, unmodified Springer Nature class/style files, whose hashes are checked. The source and built PDFs, necessary labels and vector figures are supplied. The journal's 150–250-word abstract and 4–6-keyword requirements are met. Springer expressly permits preprint citations; their status and hypotheses remain explicit. Substantive AI assistance is disclosed. Author contact information comes from supplied same-author manuscripts; no ORCID, editor approval or expertise/track record was fabricated.
