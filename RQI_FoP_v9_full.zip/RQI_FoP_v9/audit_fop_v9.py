#!/usr/bin/env python3
"""Validate the assembled FoP documents and recorded example checks.

This checks document consistency and specified reproducibility results. It is
not a scientific validity certificate or proof of journal acceptance.
"""
from pathlib import Path
import re,json,sys,platform,hashlib,importlib.metadata
ROOT=Path(__file__).resolve().parent
FILES={f'{p}_{l}':ROOT/f'fop_{p}_{l}_v9.tex' for p in ['review','supplement'] for l in ['en','zh']}

def uncomment(text):
 return '\n'.join(re.split(r'(?<!\\)%',line,maxsplit=1)[0] for line in text.splitlines())

def unique_cites(text):
 out=[]
 for m in re.finditer(r'\\cite\w*\s*(?:\[[^\]]*\]\s*)*\{([^}]+)\}',text):
  for k in m.group(1).split(','):
   if k.strip() not in out:out.append(k.strip())
 return out

def bibliography(text):
 entries={}
 for m in re.finditer(r'@(\w+)\s*\{\s*([^,]+),',text):
  i=m.end();depth=1
  while depth and i<len(text):
   if text[i]=='\\':i+=2;continue
   if text[i]=='{':depth+=1
   if text[i]=='}':depth-=1
   i+=1
  if depth:raise ValueError('Unclosed bibliography entry: '+m.group(2))
  entries[m.group(2).strip()]=text[m.start():i]
 return entries

def numbered_labels(path):
 return dict(re.findall(r'\\newlabel\{([^}]+)\}\{\{([^}]*)\}',path.read_text()))

def main():
 import fitz
 result={'scope':'Document consistency, metadata records and specified reproducibility checks; not independent validation of all cited physics.','date':'2026-11-04','python':sys.version.split()[0],'platform':platform.platform(),'packages':{},'documents':{},'checks':{},'failures':[]}
 for pkg in ['numpy','scipy','pandas','PyMuPDF']:
  try:result['packages'][pkg]=importlib.metadata.version(pkg)
  except importlib.metadata.PackageNotFoundError:result['packages'][pkg]='not installed'
 def fail(message):result['failures'].append(message)
 texts={k:uncomment(p.read_text()) for k,p in FILES.items()}
 labels={k:re.findall(r'\\label\{([^}]+)\}',v) for k,v in texts.items()}
 bib=bibliography((ROOT/'rqi_refs.bib').read_text());union=set()
 for k,p in FILES.items():
  t=texts[k];cites=unique_cites(t);union.update(cites);local=set(labels[k])
  available=local | set(labels['review_'+k.rsplit('_',1)[1]]) if k.startswith('supplement') else local
  refs=re.findall(r'\\(?:eqref|ref|autoref|pageref)\*?\{([^}]+)\}',t)
  assets=re.findall(r'\\includegraphics(?:\[[^\]]*\])?\{([^}]+)\}',t)
  stack=[];errors=[]
  for m in re.finditer(r'\\(begin|end)\{([^}]+)\}',t):
   action,name=m.groups()
   if action=='begin':stack.append(name)
   elif not stack or stack.pop()!=name:errors.append(m.group(0))
  bbl=p.with_suffix('.bbl');biborder=re.findall(r'\\bibitem(?:\[[\s\S]*?\])?\{([^}]+)\}',bbl.read_text()) if bbl.exists() else []
  log=p.with_suffix('.log');logtext=log.read_text(errors='replace') if log.exists() else 'Missing log'
  bad=[x for x in logtext.splitlines() if re.search(r'undefined|multiply defined|Missing character|Overfull|^!',x,re.I)]
  rec={'citation_keys':len(cites),'labels':len(labels[k]),'missing_citations':sorted(set(cites)-set(bib)),'missing_cross_references':sorted(set(refs)-available),'duplicate_labels':sorted(x for x in local if labels[k].count(x)>1),'figures':assets,'missing_assets':[x for x in assets if not (ROOT/x).exists()],'bibliography_first_appearance_order':cites==biborder,'unclosed_environments':stack,'environment_errors':errors,'build_errors_or_overflow':bad,'underfull_boxes':logtext.count('Underfull'),'sections':len(re.findall(r'\\section\{',t)),'tables':len(re.findall(r'\\begin\{table\}',t))}
  pdf=p.with_suffix('.pdf')
  if pdf.exists():
   d=fitz.open(pdf);pt='\n'.join(page.get_text() for page in d);outside=[]
   for n,page in enumerate(d,1):
    for block in page.get_text('blocks'):
     if block[0]<-1 or block[1]<-1 or block[2]>page.rect.width+1 or block[3]>page.rect.height+1:outside.append(n)
   rec['pdf']={'pages':len(d),'bytes':pdf.stat().st_size,'unresolved_question_mark_pairs':pt.count('??'),'replacement_characters':pt.count('\ufffd'),'pages_with_content_outside_media_box':sorted(set(outside)),'sha256':hashlib.sha256(pdf.read_bytes()).hexdigest()};d.close()
  else:rec['pdf']={'missing':True}
  for field in ['missing_citations','missing_cross_references','duplicate_labels','missing_assets','unclosed_environments','environment_errors','build_errors_or_overflow']:
   if rec[field]:fail(k+': '+field)
  if not rec['bibliography_first_appearance_order']:fail(k+': bibliography order')
  if any(rec['pdf'].get(x) for x in ['missing','unresolved_question_mark_pairs','replacement_characters','pages_with_content_outside_media_box']):fail(k+': PDF extraction/layout')
  result['documents'][k]=rec
 for part in ['review','supplement']:
  en,zh=part+'_en',part+'_zh';en_num=numbered_labels(FILES[en].with_suffix('.aux'));zh_num=numbered_labels(FILES[zh].with_suffix('.aux'))
  record={'same_citation_order':unique_cites(texts[en])==unique_cites(texts[zh]),'same_label_order':labels[en]==labels[zh],'same_numbers_for_common_labels':all(en_num.get(x)==zh_num.get(x) for x in labels[en]),'section_counts':[result['documents'][x]['sections'] for x in [en,zh]]}
  result['checks'][part+'_bilingual']=record
  if not all(record[x] for x in ['same_citation_order','same_label_order','same_numbers_for_common_labels']):fail(part+': bilingual structure/numbering')
  if record['section_counts']!=([8,8] if part=='review' else [7,7]):fail(part+': section count')
  if part=='review':
   orders=[]
   for lang in ['en','zh']:
    seq=[]
    for num in re.findall(r'(?<![A-Za-z])S([1-7])(?!\d)',texts['review_'+lang]):
     if num not in seq:seq.append(num)
    orders.append(seq)
   result['checks']['supplement_first_mention_order']=orders
   if any(seq!=list('1234567') for seq in orders):fail('Supplement first-mention order')
 unused=sorted(set(bib)-union)
 result['checks']['bibliography']={'entries':len(bib),'cited_union':len(union),'unused_entries':unused,'doi_fields':sum(bool(re.search(r'\bdoi\s*=',v)) for v in bib.values()),'explicit_preprints':sum(v.lower().startswith('@misc') for v in bib.values())}
 if unused:fail('Unused bibliography records')
 ab=re.search(r'\\abstract\{([^}]+)\}',texts['review_en']).group(1);words=len(re.findall(r"\b[\w]+(?:[-’'][\w]+)*\b",ab))
 keywords=re.search(r'\\keywords\{([^}]+)\}',texts['review_en']).group(1).split(',')
 result['checks']['journal_front_matter']={'abstract_words':words,'keywords':len(keywords),'official_class':texts['review_en'].startswith('\\documentclass[pdflatex,sn-mathphys-num]{sn-jnl}'),'email_present':'465609785@qq.com' in texts['review_en'],'declarations_present':all(x in texts['review_en'] for x in ['Statements and Declarations','Funding','Competing interests','Data and code availability','Author contributions','Generative AI assistance'])}
 if not 150<=words<=250 or len(keywords)!=6:fail('Journal abstract/keywords')
 if not all(result['checks']['journal_front_matter'][x] for x in ['official_class','email_present','declarations_present']):fail('Journal front matter/declarations')
 meta=json.loads((ROOT/'reference_checks_v9.json').read_text())
 result['checks']['metadata_record']={'recorded':meta['entries'],'matches_bibliography':{r['key'] for r in meta['records']}==set(bib)}
 if not result['checks']['metadata_record']['matches_bibliography']:fail('Reference metadata record')
 core=json.loads((ROOT/'reproducibility/results/fop_v9_verification.json').read_text());result['checks']['retained_examples']=core.get('status')
 if core.get('status')!='PASS':fail('Retained example checks')
 for key,name,phrase in [('benchmarks','test_benchmarks.log','All JC/compact-support consistency checks passed.'),('compact_fourier','test_fourier.log','Independent compact-support Fourier reconstruction passed.')]:
  path=ROOT/'provenance'/name;passed=path.exists() and phrase in path.read_text()
  result['checks'][key]='PASS' if passed else 'FAILED OR MISSING'
  if not passed:fail(key+' run log')
 expected={'sn-jnl.cls':'36d0c3273a59d48dc6a9c7b080dfa1ec50dc10229d8751568d1f2e490ffa5ecc','sn-mathphys-num.bst':'b3a7c7fbcc1e7f9619de634fcea2f5bb7a245818a5942bc576e40ea001633332'}
 result['checks']['official_template_hashes']={name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==sha for name,sha in expected.items()}
 if not all(result['checks']['official_template_hashes'].values()):fail('Official template integrity')
 result['status']='PASS' if not result['failures'] else 'FAIL'
 (ROOT/'validation_v9.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False,indent=2))
 if result['failures']:raise SystemExit(1)

if __name__=='__main__':main()
