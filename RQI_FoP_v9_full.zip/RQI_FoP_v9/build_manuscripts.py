#!/usr/bin/env python3
"""Build bilingual manuscripts, then export main labels for the supplements."""
from pathlib import Path
import argparse,subprocess

ROOT=Path(__file__).resolve().parent

def compile_one(stem):
 subprocess.run(['latexmk','-xelatex','-interaction=nonstopmode','-halt-on-error',stem+'.tex'],cwd=ROOT,check=True)

def main():
 p=argparse.ArgumentParser();p.add_argument('--language',choices=['en','zh','both'],default='both');a=p.parse_args()
 for lang in ['en','zh'] if a.language=='both' else [a.language]:
  stem=f'fop_review_{lang}_v9';compile_one(stem)
  labels=[x for x in (ROOT/(stem+'.aux')).read_text().splitlines() if x.startswith('\\newlabel')]
  (ROOT/(stem+'_labels.aux')).write_text('\n'.join(labels)+'\n')
  compile_one(f'fop_supplement_{lang}_v9')

if __name__=='__main__':main()
