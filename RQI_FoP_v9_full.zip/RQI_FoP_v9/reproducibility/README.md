# Reproducibility for the retained FoP v9 examples

Python 3.12 was used with numpy 2.3.5, scipy 1.17.0 and pandas 2.2.3. Run these commands from this directory:

```bash
python -m pip install -r requirements.txt
python verify_fop_v9.py
python verify_benchmarks.py
python reproduce_compact_detector.py
```

- `verify_fop_v9.py` checks the two local instruments, untouched marginal, finite-state counterexamples and analytic four-qubit spectrum, local-channel cluster identity, source-specific W/Dicke expressions, finite-sample witness, separated 1+1-dimensional energy kernel, conditional noncontextual transport, illustrative Fisher rank and witness norm convention.
- `finite_state_checks.py` and `scope_checks.py` contain the retained finite-state and analytic-kernel helpers. Negativity in the finite-state module is **N = 2 times conventional negativity**; the instrument report explicitly converts back to conventional negativity.
- `verify_benchmarks.py` reconstructs the JC sums, compares cutoffs and the manuscript table, checks the two archived CSV scans, fits the small-size gap and verifies the strict spacelike margin.
- `reproduce_compact_detector.py` independently reconstructs the compact-support response using the spherical-Bessel switching transform at two cutoff/quadrature settings. Results go to `results/compact_fourier_check_v9.csv`.
- `resource_transfer_jc_angle_scan_v2.7.csv` and `udw_pointlike_size_scan_v2.8.csv` preserve the input scans associated with the two retained vector figures. Their historical filenames are retained to preserve data provenance. The scripts verify these data; no claim of a newly generated continuum all-orders curve is made.

The main result record is `results/fop_v9_verification.json`; successful console logs are in `../provenance/` in the full archive. All examples use stated finite-state inputs or idealized theoretical kernels, not experimental raw data. Numerical convergence differences are diagnostics, not certified truncation/remainder bounds. The toy instrument is not claimed to be an implemented QFT apparatus.
