#!/usr/bin/env python3
"""Reconstruct the compact-support Fourier integrals without using archived results as inputs.

Uses an analytic switching transform, an independently normalized compact radial
profile, and adaptive spectral quadrature. Two numerical settings test stability.
Requirements: numpy, scipy, pandas.
"""
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.integrate import quad
from scipy.special import spherical_jn
from numpy.polynomial.legendre import leggauss

ROOT = Path(__file__).resolve().parent
GAP = 9.0
SEPARATION = 61.0 / 30.0


def chi_transform(w):
    """Fourier transform of (1-t*t)**6 on [-1,1]; even and real."""
    w = abs(float(w))
    if w < 1e-4:
        return 92160.0 / 135135.0 * (1 - w*w/30)
    return 92160.0 * spherical_jn(6, w) / w**6


def response(sigma, cutoff=300.0, n_radial=96):
    x, w = leggauss(n_radial)
    r = (x+1)/2
    weights = w/2 * r*r * np.exp(-1/(1-r*r))
    weights /= weights.sum()

    def form(k):
        return float(np.dot(weights, np.sinc(k*sigma*r/np.pi))) if sigma else 1.0

    p = quad(lambda k: k*form(k)**2*chi_transform(GAP+k)**2,
             0, cutoff, epsabs=2e-15, epsrel=2e-10, limit=300)[0]/(4*np.pi**2)
    m = -quad(lambda k: form(k)**2*chi_transform(GAP-k)*chi_transform(GAP+k),
              0, cutoff, weight='sin', wvar=SEPARATION,
              epsabs=2e-15, epsrel=2e-10, limit=300)[0]/(4*np.pi**2*SEPARATION)
    return p, abs(m)


def main():
    archived = pd.read_csv(ROOT/'udw_pointlike_size_scan_v2.8.csv')
    rows = []
    for _, row in archived.iterrows():
        sigma = row['sigma_over_T']
        a = np.array(response(sigma, 300, 96))
        b = np.array(response(sigma, 500, 160))
        target = np.array([row['P_over_lambda2'], row['abs_M_over_lambda2']])
        rows.append({'sigma_over_T': sigma, 'P_reconstructed': b[0],
                     'abs_M_reconstructed': b[1], 'gap_reconstructed': b[1]-b[0],
                     'max_change_two_settings': float(abs(b-a).max()),
                     'max_difference_from_archive': float(abs(b-target).max())})
    result = pd.DataFrame(rows)
    result.to_csv(ROOT/'results/compact_fourier_check_v9.csv', index=False)
    print(result.to_string(index=False))
    assert result['max_change_two_settings'].max() < 1e-14
    assert result['max_difference_from_archive'].max() < 1e-14
    print('Independent compact-support Fourier reconstruction passed.')


if __name__ == '__main__':
    main()
