# Frontiers of Physics 专题综述 v15

目标：**Frontiers of Physics — Topical Review**。日期：2026-11-05。

题目：**Quantum resources from localized quantum-field measurements: extraction and certification**  
中文：**局域量子场测量中的量子资源：提取与认证**。

按作者要求，正文与技术附录 A–G 保留在同一份 TeX 和连续 PDF 中，共用参考文献；没有拆出独立的科学补充稿。作者阅读版与匿名送审版共用科学源文件。

## 文件

| 文件 | 用途 |
|---|---|
| `manuscript_en.tex` / `.pdf` | 英文署名阅读版，含完整正文与附录 A–G |
| `manuscript_zh.tex` / `.pdf` | 对应中文署名阅读版，含完整正文与附录 A–G |
| `manuscript_en_anonymous.tex` / `.pdf` | 英文匿名送审版，含同样的完整附录；包装文件调用英文主源文件 |
| `manuscript_zh_anonymous.tex` / `.pdf` | 对应中文匿名工作稿，不向期刊提交 |
| `author_en.tex`, `author_zh.tex` | 署名阅读版调用的作者信息；匿名分支不读取这些文件 |
| `rqi_refs.bib`, `figures/` | 共用文献与五幅矢量图 |
| `calculations/` | 计算、输入数据、绘图程序及本次重跑结果 |
| `submission/cover_letter_en.pdf` | 面向本刊的匿名投稿信 |
| `submission/titlepage_en.pdf` | 作者信息页，仅供编辑部或投稿系统非送审字段使用 |
| `submission/graphical_abstract_en.pdf` | 英文图文摘要，复用正文操作链图 |
| `submission/UPLOAD_GUIDE_zh.md` | 投稿时各文件的用途与上传顺序 |
| `FRONTIERS_READINESS_zh.md` | 定向修改、篇幅判断与投稿状态说明 |
| `SOURCE_AUDIT.md`, `verification/` | 文献复核范围、实际编译/计算记录、双语与匿名检查 |

## 编译

需要 Python 3.10+，完整 TeX Live 的 XeLaTeX、BibTeX、latexmk，以及 ctex 和中文字体。依赖安装：

```bash
python -m pip install -r requirements.txt
```

生成四份中英文署名/匿名稿及投稿信、作者信息页：

```bash
python build.py
```

重新生成图表、编译、运行计算与文档检查：

```bash
python run_all_checks.py --figures --build
```

如修改英文源文件，可在安装 TeXcount 后用 `python count_words.py` 更新字数记录；工具不在路径中时可加 `--texcount PATH`。

只编译英文可使用 `python build.py --language en`。程序根据脚本位置查找文件，可以从其他工作目录调用。中文绘图可用 `python calculations/make_figures.py --chinese-font FONT_PATH` 指定字体。署名和匿名版始终共用正文，避免维护两套内容。

## 篇幅与期刊要求

TeXcount 的 text + headers + captions 为 14,321 词，另计默认忽略的表格文字 594 词，总计约 1.49 万英文词，包含摘要、附录和声明，不包含参考文献；公式另计。详见 `verification/english_word_count.json`。这在 Topical Review 约 8,000–15,000 词的参考范围内，但不等于期刊正式排版页数。

该刊允许初投稿格式自由，因此保留可读的学术排版。官网同时倾向将长推导放入电子补充材料；本版依照作者要求完整保留文内附录，是否接受这一篇幅安排仍由编辑决定，可能要求压缩或调整。

全部文件是投稿准备材料；尚未向期刊发送或提交。书目记录和数值 PASS 不代表全部被引论文的所有证明均已独立验证，也不代表编辑认可或保证录用。
