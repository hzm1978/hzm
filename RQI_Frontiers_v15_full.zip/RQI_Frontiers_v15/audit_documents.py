#!/usr/bin/env python3
"""Check current sources, built PDFs and actually rerun numerical records.

A PASS is document consistency and stated-example verification, not peer review
or independent validation of every cited paper.
"""
from pathlib import Path
import re,json,hashlib,sys,platform,importlib.metadata
ROOT=Path(__file__).resolve().parent

def uncomment(s):return '\n'.join(re.split(r'(?<!\\)%',x,maxsplit=1)[0] for x in s.splitlines())
def cites(s):
 out=[]
 for m in re.finditer(r'\\cite\w*\*?\s*(?:\[[^\]]*\]\s*)*\{([^}]+)\}',s):
  for k in m.group(1).split(','):
   if k.strip() not in out:out.append(k.strip())
 return out

def entries(s):
 out={}
 for m in re.finditer(r'@(\w+)\s*\{\s*([^,]+),',s):
  i=m.end();depth=1
  while depth:
   if s[i]=='\\':i+=2;continue
   if s[i]=='{':depth+=1
   if s[i]=='}':depth-=1
   i+=1
  if m.group(2) in out:raise ValueError('Duplicate bibliography key: '+m.group(2))
  out[m.group(2)]=s[m.start():i]
 return out

def numbered(path):return dict(re.findall(r'\\newlabel\{([^}]+)\}\{\{([^}]*)\}',path.read_text()))

def main():
 import fitz
 report={'scope':'Current bilingual document consistency, retained numerical checks and source-record coverage; not a journal-acceptance or all-cited-theorem certificate.','date':'2026-11-05','python':sys.version.split()[0],'packages':{},'documents':{},'checks':{},'failures':[]}
 for package in ['numpy','scipy','pandas','matplotlib','PyMuPDF']:
  try:report['packages'][package]=importlib.metadata.version(package)
  except importlib.metadata.PackageNotFoundError:report['packages'][package]='not installed'
 def fail(x):report['failures'].append(x)
 bib=entries((ROOT/'rqi_refs.bib').read_text());texts={};labels={};all_cites=set();nums={}
 for lang in ['en','zh']:
  stem=ROOT/f'manuscript_{lang}';s=uncomment(stem.with_suffix('.tex').read_text());texts[lang]=s
  c=cites(s);all_cites.update(c);ls=re.findall(r'\\label\{([^}]+)\}',s);labels[lang]=ls;refs=re.findall(r'\\(?:ref|eqref|autoref|pageref)\*?\{([^}]+)\}',s)
  assets=re.findall(r'\\includegraphics(?:\[[^\]]*\])?\{([^}]+)\}',s)
  bbl=stem.with_suffix('.bbl').read_text();order=re.findall(r'\\bibitem(?:\[[\s\S]*?\])?\{([^}]+)\}',bbl)
  stack=[];env_errors=[]
  for m in re.finditer(r'\\(begin|end)\{([^}]+)\}',s):
   action,name=m.groups()
   if action=='begin':stack.append(name)
   elif not stack or stack.pop()!=name:env_errors.append(m.group(0))
  log=stem.with_suffix('.log').read_text(errors='replace');bad=[x for x in log.splitlines() if re.search(r'Overfull|Missing character|^!|(?:Citation|Reference) .+ undefined|There were undefined|multiply defined',x)]
  apps=re.findall(r'\\label\{(app:[^}]+)\}',s);body=s.split('\\appendix')[0];app_order=[]
  for m in re.finditer(r'\\(?:ref|eqref)\{(app:[^}]+)\}',body):
   if m.group(1) not in app_order:app_order.append(m.group(1))
  rec={'citations':len(c),'labels':len(ls),'sections':len(re.findall(r'\\section\{',s)),'figures':len(re.findall(r'\\begin\{figure\}',s)),'tables':len(re.findall(r'\\begin\{table\}',s)),'missing_citations':sorted(set(c)-set(bib)),'missing_refs':sorted(set(refs)-set(ls)),'duplicate_labels':sorted(x for x in set(ls) if ls.count(x)>1),'missing_assets':[a for a in assets if not (ROOT/a).is_file()],'uncited_figures_tables':sorted(x for x in ls if x.startswith(('fig:','tab:')) and x not in refs),'citation_first_appearance_order':c==order,'appendix_first_appearance_order':app_order==apps,'appendices':apps,'unclosed_environments':stack,'environment_errors':env_errors,'build_errors_or_overflows':bad,'underfull_boxes':log.count('Underfull')}
  pdf=stem.with_suffix('.pdf');d=fitz.open(pdf);pt='\n'.join(p.get_text() for p in d);outside=[]
  for i,page in enumerate(d,1):
   for block in page.get_text('blocks'):
    if block[0]<-1 or block[1]<-1 or block[2]>page.rect.width+1 or block[3]>page.rect.height+1:outside.append(i)
  rec['pdf']={'pages':len(d),'bytes':pdf.stat().st_size,'unresolved_question_mark_pairs':pt.count('??'),'replacement_characters':pt.count('\ufffd'),'content_outside_page':sorted(set(outside)),'sha256':hashlib.sha256(pdf.read_bytes()).hexdigest()};d.close()
  rec['source_sha256']=hashlib.sha256(stem.with_suffix('.tex').read_bytes()).hexdigest();nums[lang]=numbered(stem.with_suffix('.aux'));report['documents'][lang]=rec
  for key in ['missing_citations','missing_refs','duplicate_labels','missing_assets','uncited_figures_tables','unclosed_environments','environment_errors','build_errors_or_overflows']:
   if rec[key]:fail(lang+': '+key)
  if not rec['citation_first_appearance_order'] or not rec['appendix_first_appearance_order']:fail(lang+': reference/appendix order')
  if any(rec['pdf'][x] for x in ['unresolved_question_mark_pairs','replacement_characters','content_outside_page']):fail(lang+': PDF check')
 same={'same_citation_order':cites(texts['en'])==cites(texts['zh']),'same_label_order':labels['en']==labels['zh'],'same_label_numbers':all(nums['en'].get(x)==nums['zh'].get(x) for x in labels['en'])}
 report['checks']['bilingual']=same
 if not all(same.values()):fail('Bilingual structure or numbering')
 unused=sorted(set(bib)-all_cites);report['checks']['bibliography']={'entries':len(bib),'unused':unused,'doi_records':sum(bool(re.search(r'\bdoi\s*=',x)) for x in bib.values()),'explicit_preprints':sum(x.lower().startswith('@misc') for x in bib.values())}
 if unused:fail('Unused references')
 ab=re.search(r'\\abstract\{([^}]+)\}',texts['en']).group(1);wc=len(re.findall(r"\b[\w]+(?:[-’'][\w]+)*\b",ab));kw=len(re.search(r'\\keywords\{([^}]+)\}',texts['en']).group(1).split(','))
 report['checks']['front_matter']={'abstract_words':wc,'keywords':kw,'funding_interests_data_author_AI_statements':all(x in texts['en'] for x in ['Funding','Competing interests','Data and code availability','Author contributions','OpenAI ChatGPT'])}
 if not 150<=wc<=250 or not 4<=kw<=6 or not report['checks']['front_matter']['funding_interests_data_author_AI_statements']:fail('Front matter/declarations')
 metadata=json.loads((ROOT/'verification/reference_audit.json').read_text());report['checks']['reference_record_coverage']={r['key'] for r in metadata['records']}==set(bib)
 if not report['checks']['reference_record_coverage']:fail('Reference-record coverage')
 for name in ['fop_v9_verification.json','v14_new_diagnostics.json']:
  p=ROOT/'calculations/results'/name;r=json.loads(p.read_text()) if p.exists() else {};report['checks'][name]=r.get('status','MISSING')
  if r.get('status')!='PASS':fail(name)
 for name,phrase in [('benchmarks','All JC/compact-support consistency checks passed.'),('independent_fourier','Independent compact-support Fourier reconstruction passed.')]:
  p=ROOT/'verification'/(name+'.log');ok=p.exists() and phrase in p.read_text();report['checks'][name]='PASS' if ok else 'MISSING OR FAILED'
  if not ok:fail(name)
 # Each referenced diagram is a readable one-page vector PDF asset.
 for f in (ROOT/'figures').glob('*.pdf'):
  d=fitz.open(f)
  if len(d)!=1 or not d[0].get_text().strip():fail('Empty/non-vector figure: '+f.name)
  d.close()
 report['status']='PASS' if not report['failures'] else 'FAIL';(ROOT/'verification/document_audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps(report,ensure_ascii=False,indent=2))
 if report['failures']:raise SystemExit(1)
if __name__=='__main__':main()
