#!/usr/bin/env python3
"""Check current Frontiers review copies, integrated appendices and identity separation."""
from pathlib import Path
import re,json,hashlib
import fitz
from audit_documents import numbered,cites
ROOT=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()

def normalized(text):return re.sub(r'[\s\W_]+','',text.casefold())
def pdf_record(path):
 doc=fitz.open(path);text='\n'.join(p.get_text() for p in doc);outside=[];targets=[];annotations=[]
 for i,p in enumerate(doc,1):
  targets.extend(str(link.get('uri') or link.get('file') or '') for link in p.get_links())
  for annotation in p.annots() or []:annotations.append(json.dumps(annotation.info,ensure_ascii=False))
  for b in p.get_text('blocks'):
   if b[0]<-1 or b[1]<-1 or b[2]>p.rect.width+1 or b[3]>p.rect.height+1:outside.append(i)
 record={'pages':len(doc),'sha256':sha(path),'metadata':doc.metadata,'unresolved_references':text.count('??'),'replacement_glyphs':text.count('\ufffd'),'outside_page':sorted(set(outside)),'external_link_targets_checked':sum(bool(x) for x in targets),'annotation_records_checked':len(annotations),'embedded_files':doc.embfile_count()}
 doc.close();return record,text+'\n'+'\n'.join(targets+annotations)

def main():
 report={'date':'2026-11-05','target':'Frontiers of Physics','article_type':'Topical Review','checks':{},'anonymous_documents':{},'failures':[]}
 def check(name,condition):
  report['checks'][name]=bool(condition)
  if not condition:report['failures'].append(name)
 provenance=json.loads((ROOT/'verification/revision_provenance.json').read_text())
 for lang in ['en','zh']:
  stem=ROOT/f'manuscript_{lang}';s=stem.with_suffix('.tex').read_text()
  check(lang+'_source_matches_revision_record',sha(stem.with_suffix('.tex'))==provenance['documents'][lang]['source_sha256'])
  check(lang+'_integrated_seven_appendices',len(re.findall(r'\\label\{app:[^}]+\}',s))==7 and s.index('\\appendix')<s.index('\\bibliography'))
  body=s.split('\\appendix',1)[0]
  check(lang+'_all_appendices_referenced',set(re.findall(r'\\label\{(app:[^}]+)\}',s))<=set(re.findall(r'\\ref\{(app:[^}]+)\}',body)))
  wrapper=ROOT/f'manuscript_{lang}_anonymous.tex'
  check(lang+'_anonymous_uses_same_source',wrapper.read_text().strip()=='\\def\\ForAnonymousReview{1}\n\\input{manuscript_'+lang+'.tex}')
  anon=ROOT/f'manuscript_{lang}_anonymous'
  rec,text=pdf_record(anon.with_suffix('.pdf'));report['anonymous_documents'][lang]=rec
  payload=normalized(text+'\n'+json.dumps(rec['metadata'],ensure_ascii=False))
  hits=[x for x in ['Zhiming Huang','465609785','Wuyi University','Jiangmen','五邑大学','江门'] if normalized(x) in payload]
  rec['author_identity_hits']=hits
  check(lang+'_anonymous_identity_scan',not hits)
  check(lang+'_anonymous_pdf_render_checks',not any(rec[x] for x in ['unresolved_references','replacement_glyphs','outside_page']))
  log=anon.with_suffix('.log').read_text(errors='replace')
  problems=[x for x in log.splitlines() if re.search(r'Overfull|Missing character|^!|(?:Citation|Reference) .+ undefined|There were undefined|multiply defined',x)]
  rec['build_problems']=problems;check(lang+'_anonymous_build',not problems)
  check(lang+'_same_equation_figure_table_numbers',numbered(stem.with_suffix('.aux'))==numbered(anon.with_suffix('.aux')))
  bbl=lambda p:re.findall(r'\\bibitem(?:\[[\s\S]*?\])?\{([^}]+)\}',p.read_text())
  check(lang+'_anonymous_citation_order',bbl(anon.with_suffix('.bbl'))==cites(s))
  check(lang+'_graphical_abstract_reuses_figure',sha(ROOT/'submission'/f'graphical_abstract_{lang}.pdf')==sha(ROOT/'figures'/f'Fig1_operational_chain_{lang}.pdf'))
 check('no_separate_scientific_supplement',not list(ROOT.glob('supplement*.tex')))
 wc=json.loads((ROOT/'verification/english_word_count.json').read_text());report['editorial_word_count']=wc
 check('current_word_count_record',wc['source_sha256']==sha(ROOT/'manuscript_en.tex'))
 check('word_count_in_approximate_range',8000<=wc['total_including_table_text']<=15000)
 for name,digest in provenance['input_csvs'].items():check('input_unchanged_'+name,sha(ROOT/'calculations'/name)==digest)
 cover=ROOT/'submission/cover_letter_en';rec,text=pdf_record(cover.with_suffix('.pdf'));report['cover_letter']=rec
 p=normalized(text+'\n'+json.dumps(rec['metadata'],ensure_ascii=False))
 check('cover_letter_anonymous',not any(normalized(x) in p for x in ['Zhiming Huang','465609785','Wuyi University','Jiangmen']))
 check('cover_letter_target_and_type','Frontiers of Physics' in text and 'Topical Review' in text and 'Foundations of Physics' not in text)
 check('cover_letter_render',not any(rec[x] for x in ['unresolved_references','replacement_glyphs','outside_page']))
 check('AI_assistance_disclosed',all(x in (ROOT/'manuscript_en.tex').read_text() for x in ['OpenAI ChatGPT/Codex','GPT-6-based','November 2026','Computational preparation and AI assistance']))
 rec,text=pdf_record(ROOT/'submission/titlepage_en.pdf');report['editor_only_titlepage']=rec
 check('editor_only_titlepage_has_identity',all(x in text for x in ['Zhiming Huang','Wuyi University','465609785@qq.com']))
 report['scope']='Consistency, supplied examples and identity scan of review PDFs; not a guarantee that public preprints cannot be identified or that journal length exceptions will be granted.'
 report['status']='PASS' if not report['failures'] else 'FAIL'
 (ROOT/'verification/frontiers_audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps(report,ensure_ascii=False,indent=2))
 if report['failures']:raise SystemExit(1)
if __name__=='__main__':main()
