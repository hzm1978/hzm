#!/usr/bin/env python3
"""Build integrated signed and anonymous manuscripts plus editor-facing material."""
from pathlib import Path
import argparse,subprocess,shutil
ROOT=Path(__file__).resolve().parent

def build(stem):
 args=['latexmk','-xelatex','-interaction=nonstopmode','-halt-on-error']
 if '/' in stem:args.append('-outdir='+str(Path(stem).parent))
 subprocess.run(args+[stem+'.tex'],cwd=ROOT,check=True)

def main():
 p=argparse.ArgumentParser();p.add_argument('--language',choices=['en','zh','both'],default='both');p.add_argument('--manuscripts-only',action='store_true');a=p.parse_args()
 for lang in (['en','zh'] if a.language=='both' else [a.language]):
  build('manuscript_'+lang);build('manuscript_'+lang+'_anonymous')
 if not a.manuscripts_only:
  build('submission/titlepage_en');build('submission/cover_letter_en')
 for lang in ['en','zh']:
  f=ROOT/'figures'/f'Fig1_operational_chain_{lang}.pdf'
  if f.exists():shutil.copy2(f,ROOT/'submission'/f'graphical_abstract_{lang}.pdf')
if __name__=='__main__':main()
