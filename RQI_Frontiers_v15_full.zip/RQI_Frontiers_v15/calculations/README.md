# Computation and figure files

Run from any directory using the full script path, or use `python run_all_checks.py --figures --build` from the package root. Inputs and outputs are resolved relative to each script, not the shell's current directory.

| Script | What it actually checks or regenerates | Manuscript location |
|---|---|---|
| `verify_fop_v9.py` | Same-effects instruments, untouched marginal, biseparable counterexamples, cluster channels, source-specific W/Dicke truncations, calibrated witness, separated energy kernel, contextual-model transport, Fisher-rank example | Sections 2, 5–7; Appendices A, D–G |
| `finite_state_checks.py`, `scope_checks.py` | Finite-state and kernel helpers used by that driver | Same as above |
| `verify_benchmarks.py` | JC sums and cutoff comparison, archived angle/size scans, table values, small-size fit and full-support spacelike margin | Appendices B–C |
| `reproduce_compact_detector.py` | Independent switching-transform/Fourier reconstruction at two cutoffs and quadrature settings | Appendix C |
| `verify_new_diagnostics.py` | Phase-family self-duality/concurrence/QFI counterexample; rare high-energy code under fixed mean energy; unequal-probability negativity formula checked by diagonalizing positive states | Section 7; Appendices A–B |
| `make_figures.py` | All five figures: bilingual conceptual diagrams, JC curves, compact-gap main panel and quadratic-variation panel | Main text and Appendices B–C |

The scientific scripts require numpy, scipy and pandas; plotting also requires matplotlib. The supplied CSV scans keep their historical v2.7/v2.8 names to preserve input provenance. Tiny negative roundoff values around zero in finite-state output are numerical zero, not negative physical entanglement. Plotting clips only those roundoff values for display; the input CSV files remain unchanged.

`finite_state_checks.negativity` returns **N = ||rho^T||_1 - 1**, twice conventional negativity. The two-qubit instrument and JC reports explicitly use conventional negativity where stated. Entropies in the computations use natural logarithms.

Results are written to `results/`. The old filename `fop_v9_verification.json` identifies the retained core driver, not an inherited result claimed as new: the current file is regenerated when the script runs. New phase/MI/block checks are in `results/v14_new_diagnostics.json`.

The finite-state identities are accompanied by analytical arguments in the manuscripts. Numerical parameter grids do not prove arbitrary-channel claims; those follow from the stated proofs. Cutoff/quadrature differences are convergence diagnostics, not rigorous all-orders error bounds. No experiment is simulated as a measured resource certificate. No script downloads literature or needs a network connection after dependencies are installed.

For Frontiers v15, all scientific derivations remain in the integrated manuscript, Appendices A–G. The numerical models and input scans are unchanged from v14 and are rerun for this delivery. The graphical abstract reuses the operational-chain figure rather than introducing a new scientific result.
