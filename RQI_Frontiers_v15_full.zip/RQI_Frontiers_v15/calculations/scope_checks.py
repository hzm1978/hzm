"""Numerical consistency examples for retained supplementary formulas.
These do not establish a continuum channel or an all-orders remainder.
"""
import math
import numpy as np
from scipy.integrate import quad
from scipy.stats import binom

def w_second(q, nu2):
    d = 1 - q
    k0 = nu2 / (4 * d)
    k1 = (d - nu2) / (4 * d)
    k2 = (2 * d - (1 + q) * nu2) / (8 * d)
    k3 = (d - q * nu2) / (4 * d)
    k4 = q * nu2 / (4 * d)
    rho = np.zeros((16, 16))
    rho[0, 0] = k0
    rho[1, 1] = k1
    for i in [2, 4, 8]:
        rho[1, i] = rho[i, 1] = k2
        for j in [2, 4, 8]:
            rho[i, j] = k3
    for i in [3, 5, 9]:
        for j in [3, 5, 9]:
            rho[i, j] = k4
    return (rho, (k0, k1, k2, k3, k4))

def witness_checks():
    I = np.eye(2)
    X = np.array([[0, 1], [1, 0]])
    Y = np.array([[0, -1j], [1j, 0]])
    Z = np.diag([1, -1])
    phi = np.array([1, 0, 0, 1]) / np.sqrt(2)
    w = (np.eye(4) - np.kron(X, X) + np.kron(Y, Y) - np.kron(Z, Z)) / 4
    assert np.max(abs(w - (np.eye(4) / 2 - np.outer(phi, phi)))) < 1e-14
    delta = 0.05
    margin = 0.125
    cal = 0.02
    required = 9 * np.log(6 / delta) / (8 * (margin - cal) ** 2)
    n = math.floor(required) + 1
    assert n == 489
    t = 2 * np.sqrt(np.log(6 / delta) / (2 * n))

    def error_probability(p):
        low = n * (p - t / 2)
        high = n * (p + t / 2)
        return float(binom.cdf(math.floor(low), n, p) + binom.sf(math.ceil(high) - 1, n, p))
    union = sum((error_probability(p) for p in [0.75, 0.25, 0.75]))
    assert union < delta
    return {'Pauli_operator_identity_error': float(np.max(abs(w - (np.eye(4) / 2 - np.outer(phi, phi))))), 'example_n_per_setting': n, 'unrounded_sufficient_threshold': required, 'exact_binomial_union_probability_for_illustrative_Werner_state': union, 'scope': 'Checks mathematical bound and hypothetical example; no experimental data.'}

def kernel_checks():
    errors = []
    for u in np.linspace(-1.9, 1.9, 41):
        z = u - 1j * 1e-08
        L = 3.0
        den = L * L - z * z
        tt = -(z * z + L * L) / (2 * np.pi * den ** 2)
        tx = z * L / (np.pi * den ** 2)
        cartesian = tt ** 2 + tx ** 2
        chiral = ((z - L) ** (-4) + (z + L) ** (-4)) / (8 * np.pi ** 2)
        errors.append(abs(cartesian - chiral))
    assert max(errors) < 1e-15

    def integral(eps):

        def inner(t):

            def f(tp):
                z = t - tp - 1j * eps
                kernel = ((z - 3) ** (-4) + (z + 3) ** (-4)) / (8 * np.pi ** 2)
                return np.real(np.exp(1j * (t + tp)) * kernel) * (1 - tp * tp) ** 4 * (1 - t * t) ** 4
            return quad(f, -1, 1, epsabs=1e-11)[0]
        return quad(inner, -1, 1, epsabs=1e-11)[0]
    vals = [integral(eps) for eps in [0.001, 1e-05, 1e-07, 0]]
    assert abs(vals[-2] - vals[-1]) < 1e-13
    return {'Cartesian_vs_chiral_max_error': float(max(errors)), 'L': 3, 'T': 1, 'gap': 1, 'cross_integral_real_parts': dict(zip(['1e-3', '1e-5', '1e-7', '0'], vals)), 'scope': 'Smooth strictly spacelike cross-kernel check; not a full local response or harvesting calculation.'}

def channel_checks():
    p = 0.4
    I = np.eye(2)
    Z = np.diag([1.0, -1.0])
    G = [(I + Z) / 2, (I - Z) / 2]
    sigmas = [G[0], G[1]]
    channel = lambda a: (1 - p) * a + p * np.trace(a) * I / 2
    inverse = lambda a: (a - p * np.trace(a) * I / 2) / (1 - p)
    gp = [inverse(g) for g in G]
    sp = [channel(a) for a in sigmas]
    rng = np.random.default_rng(20261104)
    errors = []
    for t in [0.0, 0.2, 0.5, 1.0]:
        rho = t * G[0] + (1 - t) * G[1]
        output = channel(rho)
        weights = np.array([np.trace(output @ g).real for g in gp])
        assert np.min(weights) > -1e-14
        for _ in range(10):
            v = rng.normal(size=2) + 1j * rng.normal(size=2)
            v /= np.linalg.norm(v)
            M = np.outer(v, v.conj())
            errors.append(abs(np.trace(output @ M) - sum((weights[j] * np.trace(sp[j] @ M) for j in range(2)))))
    assert max(errors) < 1e-13
    return {'transport_max_probability_error': float(max(errors)), 'transformed_G_min_eigenvalue': float(np.linalg.eigvalsh(gp[0]).min()), 'dephasing_limit_smallest_superoperator_eigenvalues': [1 / n for n in [1, 10, 100, 1000]], 'scope': 'Finite example of the conditional transport identity; not a simulation of a QFT channel.'}
