#!/usr/bin/env python3
"""Independent consistency checks for RQI review supplement sections S2 and S3.

This script re-evaluates the finite-mode Jaynes--Cummings sums in S5 and checks
that the archived S6 pointlike-scan CSV is consistent with its stated limit,
small-size fit, and strict-spacelike margin. This checker does NOT reconstruct
the S6 Fourier quadrature. The separate reproduce_s6_fourier.py script does so
without using the archived response values as inputs.

Requirements: Python 3, NumPy, pandas.
Run from this directory: python verify_s5_s6_benchmarks.py
"""
from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent


def entropy_from_eigenvalues(values):
    values = np.asarray(values, dtype=float)
    values = values[values > 1e-14]
    return float(-np.sum(values * np.log(values)))


def jc_detector_state(r, theta, nmax):
    """Return the exact X-state coefficients with the stated Fock cutoff."""
    lam = np.tanh(r)
    n = np.arange(nmax + 1)
    a = np.cos(theta * np.sqrt(n)) ** 2
    b = np.sin(theta * np.sqrt(n)) ** 2
    weights = (1.0 - lam**2) * lam ** (2 * n)

    p_gg = np.sum(weights * a**2)
    p_ge = np.sum(weights * a * b)
    p_ee = np.sum(weights * b**2)
    z = -(1.0 - lam**2) * lam * np.sum(
        lam ** (2 * n) * a * np.r_[b[1:], 0.0]
    )

    rho = np.array(
        [[p_gg, 0, 0, z], [0, p_ge, 0, 0],
         [0, 0, p_ge, 0], [z, 0, 0, p_ee]],
        dtype=complex,
    )
    p_exc = p_ge + p_ee
    rho_d = np.diag([1.0 - p_exc, p_exc])
    i_detector = 2 * entropy_from_eigenvalues(np.linalg.eigvalsh(rho_d))
    i_detector -= entropy_from_eigenvalues(np.linalg.eigvalsh(rho))

    nbar = np.sinh(r) ** 2
    g = (nbar + 1.0) * np.log(nbar + 1.0) - nbar * np.log(nbar)
    i_field = 2.0 * g
    negativity = max(0.0, abs(z) - p_ge)
    return i_field, i_detector, negativity


def one_sided_mutual_information(r, theta, nmax):
    """Compute I(D_A:F_B) after the first local JC channel."""
    lam = np.tanh(r)
    d = nmax + 1
    c = np.sqrt(1.0 - lam**2) * lam ** np.arange(nmax + 2)
    rho = np.zeros((2 * d, 2 * d), dtype=complex)

    for m in range(nmax + 1):
        v = np.zeros(2 * d, dtype=complex)
        v[m] = c[m] * np.cos(theta * np.sqrt(m))
        if m + 1 < d:
            v[d + m + 1] = -1j * c[m + 1] * np.sin(theta * np.sqrt(m + 1))
        rho += np.outer(v, v.conj())

    rho_d = np.zeros((2, 2), dtype=complex)
    rho_f = np.zeros((d, d), dtype=complex)
    for da in range(2):
        for db in range(2):
            for n in range(d):
                for m in range(d):
                    rho_f[n, m] += rho[da * d + n, da * d + m] if da == db else 0.0
                    if n == m:
                        rho_d[da, db] += rho[da * d + n, db * d + n]

    return (
        entropy_from_eigenvalues(np.linalg.eigvalsh(rho_d))
        + entropy_from_eigenvalues(np.linalg.eigvalsh(rho_f))
        - entropy_from_eigenvalues(np.linalg.eigvalsh(rho))
    )


def check_s5():
    rs = [0.05, 0.10, 0.20, 0.40, 0.60, 0.80]
    expected = np.array([
        [0.03499, 0.03480, 0.04983],
        [0.11251, 0.11009, 0.09866],
        [0.34258, 0.31445, 0.18936],
        [0.96490, 0.69518, 0.32103],
        [1.68845, 0.84182, 0.36842],
        [2.45470, 0.78027, 0.34684],
    ])
    results = []
    max_cutoff_difference = 0.0
    for r in rs:
        row30 = np.array(jc_detector_state(r, np.pi / 2, 30))
        row40 = np.array(jc_detector_state(r, np.pi / 2, 40))
        max_cutoff_difference = max(
            max_cutoff_difference, float(np.max(np.abs(row30 - row40)))
        )
        results.append(row40)
    results = np.asarray(results)
    table_error = float(np.max(np.abs(results - expected)))

    reductions = []
    for r in [0.05, 0.10]:
        i_field = jc_detector_state(r, np.pi / 2, 40)[0]
        i_one_side = one_sided_mutual_information(r, np.pi / 4, 40)
        bound_field = min(0.5, np.sqrt(2.0 * i_field))
        bound_one_side = min(0.5, np.sqrt(2.0 * i_one_side))
        reductions.append(1.0 - bound_one_side / bound_field)

    print("S2: r, I_field, I_detector, negativity")
    for r, row in zip(rs, results):
        print(f"  {r:0.2f}: {row[0]:.8f}, {row[1]:.8f}, {row[2]:.8f}")
    print(f"S2 max table deviation from displayed values: {table_error:.3e}")
    print(f"S2 max cutoff-30/40 difference: {max_cutoff_difference:.3e}")
    print("S2 one-sided bound reductions at r=.05,.10:",
          ", ".join(f"{100*x:.2f}%" for x in reductions))
    assert table_error < 5.1e-6
    assert max_cutoff_difference < 1e-10
    assert all(0.28 < x < 0.31 for x in reductions)


def check_s6():
    path = ROOT / "udw_pointlike_size_scan_v2.8.csv"
    data = pd.read_csv(path)
    zero = data.loc[np.isclose(data["sigma_over_T"], 0.0)].iloc[0]
    small = data.loc[data["sigma_over_T"] <= 0.005]
    x = small["sigma_over_T"].to_numpy() ** 2
    y = small["raw_entangling_gap"].to_numpy()
    slope, intercept = np.polyfit(x, y, 1)
    min_margin = float(data["spacelike_margin_over_T"].min())

    print("S3 pointlike row:")
    print(f"  p0={zero['P_over_lambda2']:.11e}")
    print(f"  |m0|={zero['abs_M_over_lambda2']:.11e}")
    print(f"  gap0={zero['raw_entangling_gap']:.11e}")
    print(f"S3 small-size fit: intercept={intercept:.11e}, slope={slope:.8e}")
    print(f"S3 minimum spacelike margin/T={min_margin:.8e}")

    assert abs(intercept - 1.44327392e-6) < 2e-14
    assert abs(slope - 1.96659e-6) < 5e-11
    assert min_margin > 0.0


if __name__ == "__main__":
    check_s5()
    check_s6()
    print("All JC/compact-support consistency checks passed.")
