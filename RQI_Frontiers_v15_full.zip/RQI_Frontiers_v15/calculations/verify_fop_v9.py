#!/usr/bin/env python3
"""Check retained FoP review examples and the explicit instrument comparison.

The checks establish finite-state identities and numerical consistency for the
stated examples. They are not a complete source audit, a QFT implementation of
the toy instruments, or a higher-order dynamical remainder bound.
"""
from pathlib import Path
import json,math
import numpy as np
from scipy.optimize import minimize_scalar
from finite_state_checks import (partial_transpose,negativity,check_counterexamples,
                                check_cluster,check_turning_points,diagnostic_state)
from scope_checks import w_second,witness_checks,kernel_checks,channel_checks

ROOT=Path(__file__).resolve().parent

def conventional_negativity(rho):
 return negativity(rho,0,2)/2

def instrument_check():
 eye=np.eye(2);zero=np.array([[1.,0.],[0.,0.]]);one=np.array([[0.,1.],[0.,0.]])
 preserve=[eye/math.sqrt(2)];replace=[zero/math.sqrt(2),one/math.sqrt(2)]
 effects=[sum(k.T@k for k in ks) for ks in [preserve,replace]]
 assert all(np.allclose(e,eye/2) for e in effects)
 phi=np.array([1.,0,0,1])/math.sqrt(2);rho=np.outer(phi,phi)
 reports=[]
 for ks in [preserve,replace]:
  output=sum(np.kron(eye,k)@rho@np.kron(eye,k.T) for k in ks)
  prob=float(np.trace(output));conditional=output/prob
  assert abs(prob-.5)<1e-14
  reports.append({'probability_each_outcome':prob,'conditional_negativity':conventional_negativity(conditional)})
 assert abs(reports[0]['conditional_negativity']-.5)<1e-14
 assert abs(reports[1]['conditional_negativity'])<1e-14
 # Nonselective trace preservation for an independent, nontrivial instrument.
 p=.31;K0=np.diag([1,math.sqrt(1-p)]);K1=np.array([[0,math.sqrt(p)],[0,0]])
 rng=np.random.default_rng(20261104);max_error=0.
 for _ in range(20):
  x=rng.normal(size=(4,4))+1j*rng.normal(size=(4,4));r=x@x.conj().T;r/=np.trace(r)
  # The first qubit is measured; the second is untouched.
  out=sum(np.kron(k,eye)@r@np.kron(k.conj().T,eye) for k in [K0,K1])
  untouched=np.trace(r.reshape(2,2,2,2),axis1=0,axis2=2)
  untouched_out=np.trace(out.reshape(2,2,2,2),axis1=0,axis2=2)
  max_error=max(max_error,float(np.max(abs(untouched-untouched_out))))
 assert max_error<1e-13
 return {'same_effect_max_error':float(np.max(abs(effects[0]-effects[1]))),'outputs':reports,'untouched_marginal_max_error':max_error,'scope':'Local finite-dimensional instruments on an initially shared resource; no field harvesting or QFT implementation claimed.'}

def w_second_order_check():
 optimum=minimize_scalar(lambda q:negativity(w_second(q,.04)[0],0,4),bounds=(.9,.97),method='bounded',options={'xatol':1e-13})
 r,ks=w_second(optimum.x,.04);det=3*(ks[1]*ks[3]-ks[2]**2)
 assert abs(det+3*.04**2/64)<1e-14
 assert abs(np.trace(r)-1)<1e-13
 eig=float(np.linalg.eigvalsh(r).min());assert eig<0
 assert abs(optimum.x-.944272)<1e-5
 return {'q_at_formal_trace_norm_minimum':float(optimum.x),'minimum_density_eigenvalue':eig,'compression_determinant':det,'nu2_over_1_minus_q':.04/(1-optimum.x),'source':'arXiv:2502.05881v2, Eqs. B7-B8','scope':'A second-order matrix truncation; the trace norm is not the entanglement of an exact state.'}

def dicke_source_check():
 v=np.array([i.bit_count()==2 for i in range(16)],float)/math.sqrt(6);errors=[]
 for q in [.1,.5,.99]:
  rho,delta=diagnostic_state(v,q,.01)
  den=3*.01*(1+q)+6*(1-q);z0=(1-q)/den;z1=.01/den;z2=q*z1
  source=np.zeros((16,16))
  for inds,z in [([3,5,6,9,10,12],z0),([2,4,8],z1),([7,11,13],z2)]:source[np.ix_(inds,inds)]=z
  errors.append(float(np.max(abs(rho-source))))
  assert abs(delta-.01*(1+q)/(2*(1-q)))<1e-12
 assert max(errors)<1e-12
 return {'source_matrix_max_error':max(errors),'cases':len(errors),'source':'arXiv:2605.24424v2, Eqs. 10-13','scope':'Reproduction of the stated normalized first-order expression; no exact CPTP dynamics inferred.'}

def fisher_rank_check():
 # Illustrative Bernoulli thermometer with T_eff=theta+nu, known gap=1.
 theta,nu=.4,.7;T=theta+nu;p=1/(1+math.exp(1/T));dp=p*(1-p)/(T*T)
 gradient=np.array([dp,dp]);F=np.outer(gradient,gradient)/(p*(1-p))
 eig=np.linalg.eigvalsh(F)
 assert abs(eig[0])<1e-14 and eig[1]>0
 return {'Fisher_eigenvalues':[float(x) for x in eig],'rank':int(np.linalg.matrix_rank(F)),'scope':'Illustrates the rank-one dependence on a single effective parameter; not a QFT thermometry simulation.'}

def dynamical_witness_bound_check():
 rng=np.random.default_rng(20261104);max_excess=-float('inf')
 for _ in range(50):
  states=[]
  for __ in range(2):
   x=rng.normal(size=(4,4))+1j*rng.normal(size=(4,4));r=x@x.conj().T;states.append(r/np.trace(r))
  w=rng.normal(size=(4,4))+1j*rng.normal(size=(4,4));w=(w+w.conj().T)/2
  diff=states[0]-states[1];lhs=abs(np.trace(w@diff));rhs=np.max(abs(np.linalg.eigvalsh(w)))*np.sum(abs(np.linalg.eigvalsh(diff)))
  max_excess=max(max_excess,float(lhs-rhs))
 assert max_excess<1e-13
 return {'sampled_cases':50,'max_lhs_minus_holder_bound':max_excess,'scope':'Numerical consistency of the norm convention; the general bound follows analytically from Holder inequality.'}

def main():
 result={'status':'PASS','instrument':instrument_check(),'mixed_state_counterexamples':check_counterexamples(),'cluster_local_channels':check_cluster(),'first_order_turning_points':check_turning_points(),'W_second_order':w_second_order_check(),'Dicke_source_matrix':dicke_source_check(),'finite_sample_witness':witness_checks(),'separated_energy_kernel':kernel_checks(),'conditional_contextuality_transport':channel_checks(),'Fisher_rank':fisher_rank_check(),'witness_model_error':dynamical_witness_bound_check(),'limitations':['No all-orders continuum detector remainder','No complete experimental reanalysis','No implication that a finite-system toy instrument is a specified QFT apparatus']}
 out=ROOT/'results';out.mkdir(exist_ok=True);(out/'fop_v9_verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))

if __name__=='__main__':main()
