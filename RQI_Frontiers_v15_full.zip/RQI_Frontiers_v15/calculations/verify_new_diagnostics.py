#!/usr/bin/env python3
"""Independent finite-state and entropy checks introduced during the v14 audit."""
from pathlib import Path
import json,math
import numpy as np
from scipy.special import xlogy
from finite_state_checks import partial_transpose,negativity
ROOT=Path(__file__).resolve().parent

def concurrence_pure(v):
 m=v.reshape(2,2);rho_a=m@m.conj().T
 return 2*math.sqrt(max(0,float(np.linalg.det(rho_a).real)))

def phase_counterexample():
 y=np.array([[0,-1j],[1j,0]]);spin=np.kron(y,y);rows=[]
 for g in [-1.2,0.,.7,2.4]:
  def vector(z):return np.array([1.,0.,0.,np.exp(1j*z)])/math.sqrt(2)
  v=vector(g);dv=np.array([0.,0.,0.,1j*np.exp(1j*g)])/math.sqrt(2);rho=np.outer(v,v.conj())
  fidelity_terms=(float(np.vdot(dv,dv).real),float(abs(np.vdot(v,dv))**2));Fq=4*(fidelity_terms[0]-fidelity_terms[1]);h=1e-3
  curvature=(concurrence_pure(vector(g+h))-2*concurrence_pure(v)+concurrence_pure(vector(g-h)))/h**2
  self_dual=float(np.max(abs(spin@rho.conj()@spin-rho)))
  assert abs(concurrence_pure(v)-1)<1e-13 and abs(Fq-1)<1e-13
  assert abs(curvature)<1e-8 and self_dual<1e-13
  rows.append({'g':g,'concurrence':concurrence_pure(v),'finite_difference_C_curvature':curvature,'pure_state_QFI':Fq,'spin_flip_self_duality_error':self_dual})
 return {'rows':rows,'scope':'Finite-dimensional spin-flip counterexample; not a QFT modular construction.'}

def entropy(p):
 return float(-xlogy(p,p)-xlogy(1-p,1-p))

def rare_energy_code():
 theta=.71;E=.3;rows=[]
 for j in [2,8,32,128]:
  a=(math.pi/2+j*math.pi)/theta;n=int(math.floor(a*a+.5));p=math.sin(theta*math.sqrt(n))**2;q=E/n
  ratio=(entropy(q*p)-q*entropy(p))/entropy(q)
  assert 0<q<1 and 0<=ratio<=1+1e-12 and abs(q*n-E)<1e-14
  rows.append({'j':j,'n':n,'transition_probability':p,'rare_probability':q,'mean_photon_number':q*n,'MI_ratio':ratio})
 assert rows[-1]['MI_ratio']>.99999
 return {'theta':theta,'E':E,'rows':rows,'scope':'Numerical illustration of the analytically proved subsequence; not a finite-energy lower bound on actual harvesting.'}

def asymmetric_block():
 # Positive X states with unequal local excitation probabilities. This constructs
 # the density matrix first and obtains negativity by direct diagonalization.
 rows=[]
 for coupling in [.01,.04,.08]:
  PA=coupling**2;PB=2*coupling**2;M=2*coupling**2;Pee=9*coupling**4;Pgg=1-PA-PB-Pee
  rho=np.diag([Pgg,PB,PA,Pee]).astype(complex);rho[0,3]=rho[3,0]=M
  eig=float(np.linalg.eigvalsh(rho).min());assert eig>=-1e-14 and abs(np.trace(rho)-1)<1e-14
  actual=negativity(rho,1,2)/2;formula=max(0,(math.sqrt((PA-PB)**2+4*M*M)-PA-PB)/2)
  threshold_expression=max(0,M-math.sqrt(PA*PB))
  assert abs(actual-formula)<1e-13 and abs(actual-threshold_expression)>1e-7
  rows.append({'coupling':coupling,'density_min_eigenvalue':eig,'direct_negativity':actual,'correct_block_formula':formula,'threshold_not_value':threshold_expression})
 return rows

def main():
 r={'status':'PASS','phase_curvature_counterexample':phase_counterexample(),'mean_energy_rare_code':rare_energy_code(),'asymmetric_negativity_block':asymmetric_block()}
 (ROOT/'results').mkdir(exist_ok=True);(ROOT/'results/v14_new_diagnostics.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
if __name__=='__main__':main()
