#!/usr/bin/env python3
"""Count integrated English prose, captions and table cells with installed TeXcount."""
from pathlib import Path
import argparse,subprocess,tempfile,re,hashlib,json,shutil
ROOT=Path(__file__).resolve().parent
OPTIONS=['-utf8','-sum=1,1,1,0,0,0,0']

def main():
 p=argparse.ArgumentParser();p.add_argument('--texcount',default=shutil.which('texcount'),help='Path to the installed TeXcount Perl script');a=p.parse_args()
 if not a.texcount:p.error('Install TeXcount (e.g. texlive-extra-utils), or pass --texcount PATH.')
 tool=Path(a.texcount);source=ROOT/'manuscript_en.tex';s=source.read_text();ver=ROOT/'verification';ver.mkdir(exist_ok=True)
 def run(path):return subprocess.run(['perl',str(tool),*OPTIONS,str(path)],capture_output=True,text=True,check=True).stdout
 def fields(text):
  return {name:int(re.search(re.escape(label)+r':\s*(\d+)',text).group(1)) for name,label in [('text','Words in text'),('headers','Words in headers'),('captions','Words outside text (captions, etc.)'),('displayed_math','Number of math displayed'),('inline_math','Number of math inlines')]}
 raw=run(source);counts=fields(raw);parts=[]
 # TeXcount's default tabular rule omits cells. Count their prose separately,
 # retaining mathematical delimiters and citation commands so these stay excluded.
 for m in re.finditer(r'\\begin\{tabular\}',s):
  i=m.end()
  while s[i].isspace():i+=1
  if s[i]!='{':raise ValueError('Expected braced tabular column specification')
  depth=1;i+=1
  while depth:
   if s[i]=='{':depth+=1
   elif s[i]=='}':depth-=1
   i+=1
  j=s.index('\\end{tabular}',i);parts.append(s[i:j].replace('&',' ').replace('\\\\','\n'))
 with tempfile.TemporaryDirectory(prefix='rqi_texcount_') as td:
  f=Path(td)/'table_cells.tex';f.write_text('\\documentclass{article}\n\\begin{document}\n'+'\n\n'.join(parts)+'\n\\end{document}\n');table_raw=run(f)
 table_fields=fields(table_raw);base=sum(counts[x] for x in ['text','headers','captions']);table_words=sum(table_fields[x] for x in ['text','headers','captions'])
 record={'source':source.name,'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'tool':'TeXcount (CTAN Perl tool)','tool_sha256':hashlib.sha256(tool.read_bytes()).hexdigest(),'command_options':OPTIONS,'counts':counts,'text_headers_captions_total':base,'table_cells_counted_separately':len(parts),'additional_table_words':table_words,'total_including_table_text':base+table_words,'scope':'Includes abstract, integrated Appendices A–G, declarations, captions and table prose; excludes bibliography. Formulas are counted separately. Text embedded in figure files is not counted. Conditional author macros follow TeXcount defaults. Approximate editorial word count, not a journal-page guarantee.','journal_reference_range_words':[8000,15000],'within_reference_range':8000<=base+table_words<=15000}
 (ver/'english_word_count.json').write_text(json.dumps(record,indent=2)+'\n');(ver/'english_word_count_texcount.txt').write_text(raw+'\nTABLE CELL COUNT (added because default tabular contents are omitted):\n'+table_raw)
 print(json.dumps(record,indent=2))
if __name__=='__main__':main()
