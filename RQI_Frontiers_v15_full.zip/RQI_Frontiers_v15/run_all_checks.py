#!/usr/bin/env python3
"""Execute current calculations and document checks from any working directory."""
from pathlib import Path
import subprocess,sys,argparse,json
ROOT=Path(__file__).resolve().parent;VER=ROOT/'verification';VER.mkdir(exist_ok=True)
p=argparse.ArgumentParser();p.add_argument('--build',action='store_true');p.add_argument('--figures',action='store_true');a=p.parse_args();records=[]
steps=[]
if a.figures:steps.append(('figure_generation',ROOT/'calculations/make_figures.py'))
if a.build:steps.append(('build',ROOT/'build.py'))
steps.extend((name,ROOT/'calculations'/file) for name,file in [('core','verify_fop_v9.py'),('benchmarks','verify_benchmarks.py'),('independent_fourier','reproduce_compact_detector.py'),('new_diagnostics','verify_new_diagnostics.py')])
steps.append(('documents',ROOT/'audit_documents.py'))
steps.append(('frontiers',ROOT/'audit_frontiers.py'))
for name,script in steps:
 print('Running',name,flush=True)
 with (VER/(name+'.log')).open('w') as log:r=subprocess.run([sys.executable,str(script)],cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
 records.append({'check':name,'exit_code':r.returncode,'log':name+'.log'})
 if r.returncode:
  print((VER/(name+'.log')).read_text()[-6000:]);(VER/'run_results.json').write_text(json.dumps({'status':'FAIL','checks':records},indent=2)+'\n');raise SystemExit(r.returncode)
 print(name,'PASS',flush=True)
(VER/'run_results.json').write_text(json.dumps({'status':'PASS','checks':records},indent=2)+'\n');print('All current checks passed; see verification/run_results.json.')
