# RQI 综述 v14.1：以作者上传的 v14 为基础的小修

日期：2026-11-05。当前期刊目标沿用 **Frontiers of Physics — Topical Review**。

本版以作者重新上传的 `RQI_review_v14.zip` 为准。摘要、引言、结论、章节顺序、全部原有显示公式、125 条参考文献、图表内容、布局和计算输入均保留；没有采用 v15 的压缩改写。正文和附录 A–G 始终在同一份 TeX/PDF 内，共用参考文献。

## 文件

| 文件 | 用途 |
|---|---|
| `manuscript_en.tex` / `.pdf` | 英文署名阅读稿，含全部附录 |
| `manuscript_zh.tex` / `.pdf` | 对应中文署名阅读稿，保留上传稿的 XeLaTeX 提示 |
| `manuscript_en_anonymous.tex` / `.pdf` | 英文匿名送审稿；共用英文主源文件，含全部附录 |
| `manuscript_zh_anonymous.tex` / `.pdf` | 中文匿名工作稿 |
| `author_en.tex`, `author_zh.tex` | 署名分支调用的作者信息，匿名分支不读取 |
| `rqi_refs.bib`, `figures/` | 保留共用书目及图表内容；三幅中文图修复字体嵌入 |
| `calculations/` | 原有计算程序、输入和本次重跑结果 |
| `MINOR_REVISION_REPORT_zh.md` | 必要改动、数学与文献核查、投稿状态 |
| `verification/` | 当前编译/计算日志、125 条书目核对、引用顺序及保留内容检查 |
| `changes/` | 相对本次上传稿的中英文逐行差异 |
| `submission/` | Frontiers 匿名投稿信、图文摘要、编辑部作者页及上传说明 |

## 编译和核查

需要 Python 3.10+、XeLaTeX、BibTeX、latexmk、ctex 和可用中文字体。先安装 Python 依赖：

```bash
python -m pip install -r requirements.txt
```

编译署名、匿名双语稿及投稿材料：

```bash
python build.py
```

编译并重跑数值、文档和引用检查：

```bash
python run_all_checks.py --build
```

本次保留英文及数值图原文件，三幅中文示意图仅修复字体嵌入，图中文字、布局和数据不变；需要重画时可加 `--figures`。脚本按自身路径寻找输入，可从其他工作目录调用。

如果修改英文源文件，安装 TeXcount 后可用 `python count_words.py` 更新字数记录，或用 `--texcount PATH` 指定工具。

## 注意

该刊匿名送审使用 `manuscript_en_anonymous.pdf`；作者信息页只供编辑部或投稿系统非送审字段使用。完整双语交付包包含署名文件，不应整包作为匿名主稿提交。

含附录、表格文字和声明约 15,718 英文词，略高于 Topical Review 约 8,000–15,000 词的参考范围。依作者要求未为了控字数继续大幅改写或拆分附录；编辑仍可能要求压缩。格式自由初投的排版页数不等于正式期刊页数。

书目身份已逐条核对；被引论文的全部证明并未重新独立证明。检查结果表示明确模型、假设和例子范围内的一致性与复算证据，不是期刊认可或录用保证。没有向期刊发送或提交材料。
