#!/usr/bin/env python3
"""Check preservation, anonymous review PDFs and citation/appendix ordering."""
from pathlib import Path
import re,json,hashlib,csv
import fitz
from audit_documents import cites,numbered
ROOT=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def norm(s):return re.sub(r'[\s\W_]+','',s.casefold())
def main():
 r={'date':'2026-11-05','scope':'Minimal-change preservation, compiled anonymous/signed agreement, complete bibliographic verification records and integrated appendices.','checks':{},'anonymous_pdfs':{},'failures':[]}
 def check(key,value):
  r['checks'][key]=bool(value)
  if not value:r['failures'].append(key)
 record=json.loads((ROOT/'verification/minimal_change_record.json').read_text())
 for lang in ['en','zh']:
  p=ROOT/f'manuscript_{lang}';s=p.with_suffix('.tex').read_text();d=record['documents'][lang]
  check(lang+'_source_matches_audited_revision',sha(p.with_suffix('.tex'))==d['source_sha256'])
  blocks=[m.group(0) for m in re.finditer(r'\\begin\{(equation\*?|align\*?|gather\*?|multline\*?|displaymath)\}[\s\S]*?\\end\{\1\}',s)]
  blocks=[x for x in blocks if not any('\\label{'+k+'}' in x for k in record['new_labels'])]
  check(lang+'_all_original_display_math_preserved',hashlib.sha256('\n'.join(blocks).encode()).hexdigest()==d['preserved_display_math_sha256'])
  check(lang+'_integrated_appendices',len(re.findall(r'\\label\{app:[^}]+\}',s))==7 and '\\appendix' in s and not list(ROOT.glob('supplement*.tex')))
  main=s.split('\\appendix',1)[0]
  check(lang+'_all_references_also_cited_in_main_text',len(cites(main))==125 and cites(main)==cites(s))
  anon=ROOT/f'manuscript_{lang}_anonymous';doc=fitz.open(anon.with_suffix('.pdf'));text='\n'.join(page.get_text() for page in doc);meta=doc.metadata;targets=[];outside=[]
  for page in doc:
   targets.extend(str(x.get('uri') or x.get('file') or '') for x in page.get_links())
   for b in page.get_text('blocks'):
    if b[0]<-1 or b[1]<-1 or b[2]>page.rect.width+1 or b[3]>page.rect.height+1:outside.append(page.number+1)
  payload=norm(text+json.dumps(meta,ensure_ascii=False)+'\n'.join(targets));hits=[x for x in ['Zhiming Huang','465609785','Wuyi University','Jiangmen','五邑大学','江门'] if norm(x) in payload]
  problems=[x for x in anon.with_suffix('.log').read_text(errors='replace').splitlines() if re.search(r'Overfull|Missing character|^!|(?:Citation|Reference) .+ undefined|There were undefined|multiply defined',x)]
  check(lang+'_anonymous_identity_scan',not hits);check(lang+'_anonymous_render_and_build',not outside and '??' not in text and '\ufffd' not in text and not problems and doc.embfile_count()==0)
  check(lang+'_same_numbering_in_signed_and_anonymous',numbered(p.with_suffix('.aux'))==numbered(anon.with_suffix('.aux')))
  order=re.findall(r'\\bibitem(?:\[[\s\S]*?\])?\{([^}]+)\}',anon.with_suffix('.bbl').read_text());check(lang+'_anonymous_bibliography_order',order==cites(s))
  r['anonymous_pdfs'][lang]={'pages':len(doc),'sha256':sha(anon.with_suffix('.pdf')),'author_identity_hits':hits,'outside_page':sorted(set(outside)),'build_problems':problems};doc.close()
 for rel,digest in record['input_files'].items():check('preserved_'+rel,sha(ROOT/rel)==digest)
 for rel,entry in record.get('font_embedding_fixes',{}).items():check('font_fix_'+rel,sha(ROOT/rel)==entry['new_sha256'])
 check('bibliography_preserved',sha(ROOT/'rqi_refs.bib')==record['bibliography_sha256'])
 refs=json.loads((ROOT/'verification/reference_audit.json').read_text());check('all_125_reference_records_currently_verified',refs['count']==125 and not refs['unresolved'] and all(x['status']=='VERIFIED_METADATA' and x['http_status']==200 for x in refs['records']))
 inventory=list(csv.DictReader((ROOT/'verification/source_inventory.csv').open(encoding='utf-8-sig')));check('reference_inventory_in_first_citation_order',[x['key'] for x in inventory]==cites((ROOT/'manuscript_en.tex').read_text()))
 # Only editorial guidance, not a reason to silently shorten the author's preferred text.
 wc=json.loads((ROOT/'verification/english_word_count.json').read_text());check('word_count_matches_current_source',wc['source_sha256']==sha(ROOT/'manuscript_en.tex'));r['english_word_count_including_table_text']=wc['total_including_table_text'];r['editorial_length_note']='Topical Review guidance is approximately 8,000–15,000 words; retain the author-requested complete v14 text and integrated appendices, and report any excess openly.'
 r['status']='PASS' if not r['failures'] else 'FAIL';(ROOT/'verification/minimal_audit.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print(json.dumps(r,ensure_ascii=False,indent=2))
 if r['failures']:raise SystemExit(1)
if __name__=='__main__':main()
