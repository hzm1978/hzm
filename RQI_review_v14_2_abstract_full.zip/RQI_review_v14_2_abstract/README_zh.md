# RQI v14.2：简明摘要版

日期：2026-11-06。沿用作者选定的 v14 内容及 v14.1 必要小修；本次只改英文摘要和对应中文摘要，英文为 150 词。摘要之外的主源文件与 v14.1 完全一致。

## 主要文件

- `manuscript_en.tex` / `.pdf`：英文署名阅读稿，含正文、附录 A–G 及参考文献。
- `manuscript_zh.tex` / `.pdf`：对应中文阅读稿。
- `manuscript_en_anonymous.tex` / `.pdf`：英文匿名送审版，调用同一英文主源文件。
- `manuscript_zh_anonymous.tex` / `.pdf`：中文匿名工作稿。
- `author_en.tex`, `author_zh.tex`：署名阅读分支的作者信息。
- `rqi_refs.bib`, `figures/`, `calculations/`：已核查的文献、图表和计算文件。
- `ABSTRACT_REVISION_zh.md`, `changes/`：本轮摘要修改说明与逐行差异。
- `verification/`：本次文档核验与继承的数学、计算和书目证据。
- `provenance/v14_1/`：上一版必要小修报告及原始核验记录。
- `submission/`：Frontiers 投稿信、图文摘要、作者信息页和上传说明。

## 使用

需要 Python 3.10+ 和完整 TeX Live 的 XeLaTeX、BibTeX、latexmk、ctex 及中文字体。

```bash
python -m pip install -r requirements.txt
python build.py
```

需要重跑全部检查时：

```bash
python run_all_checks.py --build
```

投稿使用英文匿名稿；作者信息页仅供编辑部或系统非送审字段。完整双语包含署名信息，不应整包作为匿名主稿上传。科学附录始终和正文在同一稿件内。

全文约 15,705 英文词，略高于 Frontiers / Topical Review 的参考范围。本次没有修改原有内容来进一步压缩篇幅。此包仅是投稿准备文件，尚未向期刊提交。
