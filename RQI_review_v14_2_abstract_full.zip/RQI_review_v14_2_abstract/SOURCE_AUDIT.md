# Source and verification audit — v14.1 minimal revision

Prepared 5 November 2026 from the uploaded `RQI_FoP_v13_2_FINAL.zip`, SHA256 `65334233bbba3ec9f93751661bcf5d106289916fd27a2a963d63a68cf828c297`. The uploaded files remain intact outside this delivery directory.

## What was verified

The manuscript was reviewed as a critical narrative survey, with analytical examination and numerical reproduction of its explicit examples. Bibliographic identity, obtaining a PDF, targeted source reading, reproducing a calculation, and independently proving every claim in a source are separate evidence levels. A metadata record or a script PASS is not a complete scientific certification of that source.

The shared bibliography now has 125 used entries: 115 carry DOI fields, nine explicitly cite preprints, and Wald's book has its verified publisher link without an invented DOI. The two added methodological references are Weedbrook et al. (Gaussian quantum information) and Wootters (two-qubit concurrence). `verification/reference_audit.json` records coverage for every key.

For the 102 records already in the v9 bibliography, the previously obtained metadata checks were retained and compared against the uploaded v13.2 fields. That comparison found a regression in the last page of Louko–Satz 2006, corrected again to 6343. Twenty-one sources added after v9, plus the two methodological sources added here, received current arXiv/DOI identity checks. Initial Crossref rate limits were retried. Publisher PDF access failures were not treated as an absence of the papers; INSPIRE DOI matches located public preprints for the key Gaussian and degenerate-detector sources.

## Targeted full-text reading in this round

Ten public PDFs were obtained for these checks. The table describes the material actually used; it does not claim cover-to-cover proof verification of all ten papers.

| Source | Material used | Limit carried into the manuscript |
|---|---|---|
| Nyström et al., arXiv:2606.17287v1 | Abstract; pp. 2–5, Definitions 1–4 and Theorem 1 | Attribution is conditional on the initial product, free probe input, fixed interaction and environmental-free-set inclusion. The review does not claim a new induced resource theory or validate all examples in the source |
| Gao–Klco, arXiv:2410.04162v2 / PRA112,012430 | Abstract; pp. 3–4 and Appendix B on pp. 12–13 | Necessary/sufficient entanglement classification and mode consolidation retain AB symmetry, absence of field–momentum mixing and cross-block sign conditions. No arbitrary non-Gaussian or finite-energy UDW implementation inferred |
| Gao–Klco, arXiv:2506.23968v2 / PRA113,012430 | Abstract, setup and summary, particularly pp. 3 and 9 | Third-region Gaussian measurements and communicated records are additional resources; assistance/formation bounds are not unassisted harvesting yields |
| Agullo et al., arXiv:2512.18410v2 | Abstract and two-mode criterion, pp. 10–11 | Overlap must be compared with a state-dependent threshold involving local/joint symplectic invariants; overlap positivity alone is insufficient |
| Osawa–Nambu–Yoshimoto, arXiv:2504.18129v2 | Abstract, setting and conclusion around p. 18 | Gaussian partner-profile restrictions are not universal statements for every accelerated probe. Geometric overlap alone is not the complete separability criterion |
| Pozas-Kerstjens–Louko–Martín-Martínez, arXiv:1703.02982v2 | Setup and no-go treatment, particularly pp. 2–3 and 5–6 | Identical inertial inputs and matched switching/coupling are stated; the overlapping-window proof uses spherical profiles. The review invokes its leading-order result without asserting a new all-model theorem |
| Chatterjee, arXiv:2508.12497v2 / PRD112,085025 | Abstract; finite-dimensional spin-flip and curvature discussion, pp. 6–7 and 9–10 | No general curvature–QFI identity is imported. The review supplies a phase-family counterexample in the cited spin-flip representation, without equating it to all Tomita conjugations or rejecting every source-specific dynamical example |
| Caminiti–Myers–Wurtz, arXiv:2609.16109v2 | Abstract, code-subspace reconstruction on PDF pp. 6–7 and discussion on PDF p. 49 | A boundary representative of a bulk-local detector is not automatically a time-local laboratory boundary apparatus. Boundary-support overlap alone does not establish bulk signalling |
| Wurtz et al., arXiv:2602.07112v1 | Abstract/introduction and the stated coupling/scaling question | The review reports the CFT result as model-specific; the numerical optimization and asymptotic formulas were not independently reproduced |
| Weedbrook et al., arXiv:1110.3234 / RMP84,621 | Canonical variables and covariance/Williamson definitions, particularly pp. 5 and 9 | The source uses hbar=2; this manuscript explicitly converts to hbar=1, so symplectic eigenvalues have lower bound 1/2. Logarithms and conventional negativity are defined separately |

Previously documented targeted source reading for the retained v9 material remains inherited evidence. In particular, the closest FoP measurement review by Papageorgiou–Fraser was previously read in its introduction/conclusion, not independently re-proved across all 75 pages. Its role is acknowledged directly in the new introduction.

For newer peripheral examples (cavity fields, reflecting boundaries, superposed geometries and quench analogues), DOI records and available publisher/arXiv abstracts were checked. The two superposed-geometry abstracts were additionally retrieved through INSPIRE DOI matches. These checks support a limited description of their setup/results, not independent verification of their numerical curves. No experimental raw data were obtained or reanalyzed.

The source PDFs and full abstracts are not redistributed in this package. A compact retrieval manifest and the current bibliographic inventory are provided instead.

## Analytical and numerical checks

- The same-effects instrument construction has explicit Kraus operators and distinct conditional Bell-input outputs. Local trace preservation leaves the untouched marginal invariant.
- Relative-entropy data processing, the separable reference, Pinsker and finite-dimensional partial-transpose norm bound are distinguished from a lower bound or an optimal extraction protocol.
- Gaussian covariance conventions, the initial-product premises and the full support of the local channels are explicit. Mean-energy rare-code limits and their finite-information domain are stated.
- Mixed-state counterexamples and the analytic four-qubit partial-transpose spectrum are retained. Cluster invariance is proved for arbitrary local CPTP channels; numerical grids are described only as grids.
- Source-specific W/Dicke first-order models and the W second-order truncation are reconstructed. Their high-acceleration branches are not promoted to exact finite-coupling revival.
- The compact switching has enough decay for the spectral moments. Dominated convergence and the spatial Taylor remainder justify the second-order pointlike coefficients. No uniform all-orders remainder in detector radius is established.
- The separated 1+1-dimensional energy-density kernel is checked in two equivalent forms and in a smooth spacelike cross integral. This does not supply an uncomputed local response or a positive composite-coupling harvesting yield.
- The finite-sample witness and illustrative sufficient n=489 per setting are checked under the stated fixed-setting, bounded-independent-sample and calibration assumptions. The guarantee is frequentist, not posterior.
- The added phase family has concurrence identically one, spin-flip self-duality and QFI one, while concurrence curvature vanishes. The analytical derivation is in the main text; numerical points are a consistency check.
- The rare mean-energy code and asymmetric two-qubit block are constructed independently in `verify_new_diagnostics.py`. Positive X states verify the general negativity value and distinguish it from the threshold expression.

Current logs and JSON results are generated by the scripts in this package. The old checker that required absent manuscript/outputs directories, fixed PDF page counts and literal self-comparisons was replaced. Page count is now an observed layout result, not a scientific correctness condition.

## Documents and scope of the final checks

Both languages use the same citation and equation-label order. References and appendices are checked by first appearance, assets are present and cited, and built PDFs are checked for unresolved references, replacement glyphs, overflow and content outside the page. Figures are regenerated from local definitions/data, with larger readable diagram text and the compact-gap variation panel. No generative image model is used.

The genre remains a critical narrative review. Neither the evidence record nor successful compilation establishes exhaustive priority, journal acceptance, an all-orders continuum result or an implemented apparatus. The journal recommendation is based on current official scope/review/indexing pages and the paper's actual conceptual emphasis. No journal has been contacted or supplied an invitation or editorial endorsement.

## Current minimal revision

The author reselected the uploaded v14 as the scientific and stylistic baseline. Its abstract, introduction, conclusion, original display mathematics, bibliography, figure content/layout and scientific calculation inputs remain unchanged. Three Chinese diagrams receive a font-embedding repair after visual inspection found missing visible glyphs despite extractable text; no scientific labels or numerical data are changed. Subsection 2.1 adds only the reduced probe-state and readout-probability definitions; a body-text author accent is corrected. The Chinese XeLaTeX guard added by the author is preserved. Journal-facing anonymous wrappers and materials are separate from these content changes.

All 125 bibliographic identities received current public-source checks in this revision (115 Crossref DOI records, 9 arXiv records, one publisher book). The previous reading scopes above remain inherited targeted reading, not a claim of rereading every source. Crossref/Cambridge's Sorkin year conflict was checked against the original 1993 preprint and ISBN catalog; 1993 is retained. Full author-name identity was checked before accepting given/family partition differences. Current records appear in verification/reference_audit.json and reference_verification_current.csv.

## Abstract-only revision, 6 November 2026

Version v14.2 rewrites the English abstract (150 words) and its corresponding Chinese abstract. The main sources outside the abstract are identical to v14.1. Mathematical, numerical and bibliographic evidence is retained from the 5 November v14.1 audit; current runs rebuild documents and check numbering, citations, PDFs, anonymity and abstract-only preservation. The current run record distinguishes inherited scientific calculations from freshly executed document checks.
