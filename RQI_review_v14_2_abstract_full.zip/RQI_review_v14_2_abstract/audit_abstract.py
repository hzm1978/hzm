#!/usr/bin/env python3
"""Verify the author-requested abstract-only change against the recorded baseline."""
from pathlib import Path
import re,json,hashlib
ROOT=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
def main():
 base=json.loads((ROOT/'verification/abstract_edit_record.json').read_text());result={'date':'2026-11-06','checks':{},'failures':[]}
 for lang in ['en','zh']:
  s=(ROOT/f'manuscript_{lang}.tex').read_text();r=base['documents'][lang]
  if lang=='en':m=re.search(r'\\abstract\{([\s\S]*?)\}\n\\keywords',s);a,b=m.span(1)
  else:a=s.index('\\begin{abstract}')+len('\\begin{abstract}');b=s.index('\\end{abstract}',a)
  ab=s[a:b];masked=s[:a]+'<ABSTRACT>'+s[b:]
  tests={'current_source_hash':sha(s.encode())==r['source_sha256'],'current_abstract_hash':sha(ab.encode())==r['abstract_sha256'],'outside_abstract_unchanged':sha(masked.encode())==r['outside_abstract_sha256']}
  if lang=='en':tests['english_abstract_150_words']=len(re.findall(r"\b[\w]+(?:[-’'][\w]+)*\b",ab))==150
  for name,value in tests.items():
   result['checks'][lang+'_'+name]=value
   if not value:result['failures'].append(lang+'_'+name)
 result['status']='PASS' if not result['failures'] else 'FAIL';(ROOT/'verification/abstract_audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
 if result['failures']:raise SystemExit(1)
if __name__=='__main__':main()
