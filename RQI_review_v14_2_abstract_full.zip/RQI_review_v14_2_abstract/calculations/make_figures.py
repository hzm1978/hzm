#!/usr/bin/env python3
"""Regenerate the five manuscript figures from local specifications and CSV data."""
from pathlib import Path
import os,tempfile,subprocess,argparse
os.environ.setdefault('MPLCONFIGDIR',str(Path(tempfile.gettempdir())/'rqi_v14_matplotlib'))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch,FancyArrowPatch,Rectangle
from matplotlib import font_manager
import numpy as np,pandas as pd
ROOT=Path(__file__).resolve().parent;FIG=ROOT.parent/'figures';FIG.mkdir(exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'pdf.fonttype':42,'ps.fonttype':42,'axes.unicode_minus':False})

def chinese_font(explicit=None):
 if explicit:return font_manager.FontProperties(fname=explicit)
 for family in ['Noto Sans CJK SC','Noto Serif CJK SC','Microsoft YaHei','SimHei']:
  try:return font_manager.FontProperties(fname=font_manager.findfont(family,fallback_to_default=False))
  except ValueError:pass
 try:
  r=subprocess.run(['fc-match','-f','%{family}\n%{file}','Noto Sans CJK SC'],capture_output=True,text=True,check=True).stdout.splitlines()
  if len(r)>1 and any(x in r[0].lower() for x in ['cjk','noto','han']):return font_manager.FontProperties(fname=r[1])
 except (OSError,subprocess.SubprocessError):pass
 raise RuntimeError('A Chinese font is required. Install Noto CJK or pass --chinese-font FONT_PATH.')

def box(ax,x,y,w,h,text,fp,color='#eaf1f8',size=9):
 ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=.015',linewidth=.9,edgecolor='#34495e',facecolor=color))
 ax.text(x+w/2,y+h/2,text,ha='center',va='center',fontsize=size,fontproperties=fp)
def arrow(ax,start,end):ax.add_patch(FancyArrowPatch(start,end,arrowstyle='-|>',mutation_scale=12,linewidth=1,color='#34495e'))

def chain(zh,fp):
 fig,ax=plt.subplots(figsize=(5.2,4.4));ax.set(xlim=(0,1),ylim=(0,1));ax.axis('off')
 labels=(['场态与局域代数','局域相互作用与装置','保留探针态与记录','资源判据与校准','指定任务及资源代价'] if zh else ['Field state and local algebra','Localized interaction and apparatus','Retained probe state and record','Resource criterion and calibration','Specified task and resource costs'])
 notes=(['初态与完整支撑','物理实现与动力学','测量场景与读出','抽样与系统误差'] if zh else ['Preparation and complete supports','Realization and dynamics','Scenario and readout','Sampling and systematic errors'])
 ys=[.82,.63,.44,.25,.06]
 for i,(y,label) in enumerate(zip(ys,labels)):
  box(ax,.08,y,.84,.115,f'{i+1}. '+label,fp,size=10)
  if i<4:
   arrow(ax,(.5,y-.01),(.5,ys[i+1]+.13));ax.text(.52,y-.035,notes[i],ha='left',va='center',fontproperties=fp,fontsize=7.5)
 fig.savefig(FIG/f'Fig1_operational_chain_{"zh" if zh else "en"}.pdf',bbox_inches='tight');plt.close(fig)

def hierarchy(zh,fp):
 fig,ax=plt.subplots(figsize=(5.2,4.0));ax.set(xlim=(0,1),ylim=(0,1));ax.axis('off')
 labels=(['场区域互信息','探针互信息','相对熵纠缠','探针负性'] if zh else ['Field-region mutual information','Probe mutual information','Relative entropy of entanglement','Probe negativity'])
 formulas=[r'$I_{\rm F}(A:B)$',r'$I(D_A:D_B)$',r'$E_R(\rho_{AB})$',r'$\mathcal{N}(\rho_{AB})$']
 relations=[r'$I(D_A:D_B)\leq I_{\rm F}$',r'$E_R\leq I(D_A:D_B)$',r'$\mathcal{N}\leq d_B\sqrt{E_R/2}$']
 ys=[.81,.57,.33,.09]
 for i,y in enumerate(ys):
  box(ax,.05,y,.9,.13,labels[i]+'  '+formulas[i],fp,size=9)
  if i<3:
   arrow(ax,(.29,y-.01),(.29,ys[i+1]+.145));ax.text(.33,y-.055,relations[i],va='center',fontsize=9)
 fig.savefig(FIG/f'Fig3_accessibility_hierarchy_{"zh" if zh else "en"}.pdf',bbox_inches='tight');plt.close(fig)

def support(zh,fp):
 fig,ax=plt.subplots(figsize=(5.2,3.8));T=1.;radius=.35;L=3.1
 for x,col,name in [(-L/2,'#dceaf7','A'),(L/2,'#e4f0e2','B')]:
  ax.add_patch(Rectangle((x-radius,-T),2*radius,2*T,facecolor=col,edgecolor='#34495e'))
  ax.plot([x-radius,x-radius],[T,T],alpha=0);ax.text(x,0,name,ha='center',fontsize=12)
  ax.plot([x-(T+radius),x,x+(T+radius),x,x-(T+radius)],[0,T+radius,0,-(T+radius),0],'--',color='#6b7280',lw=.9)
 ax.annotate('',xy=(-L/2+radius,1.65),xytext=(L/2-radius,1.65),arrowprops={'arrowstyle':'<->'})
 ax.text(0,1.72,r'$L-2\sigma$',ha='center',fontsize=10)
 ax.annotate('',xy=(2.25,T),xytext=(2.25,-T),arrowprops={'arrowstyle':'<->'})
 ax.text(2.35,0,r'$2T$',va='center')
 ax.set(xlim=(-3.1,3.1),ylim=(-1.65,2.05));ax.set_xlabel('空间坐标 $x$' if zh else 'Spatial coordinate $x$',fontproperties=fp);ax.set_ylabel('时间坐标 $ct$' if zh else 'Time coordinate $ct$',fontproperties=fp)
 ax.set_title(r'$L-2\sigma>2T$',fontsize=11);ax.set_aspect('equal',adjustable='box');ax.grid(alpha=.2)
 fig.tight_layout();fig.savefig(FIG/f'Fig2_spacelike_support_{"zh" if zh else "en"}.pdf');plt.close(fig)

def numerical():
 data=pd.read_csv(ROOT/'resource_transfer_jc_angle_scan_v2.7.csv');fig,ax=plt.subplots(figsize=(5.2,3.4))
 for r,group in data.groupby('r',sort=True):
  line=ax.plot(group.theta,np.maximum(group.negativity,0),label=f'$r={r:g}$')[0]
  ax.axhline(float(group.negativity_bound.iloc[0]),ls='--',lw=.85,color=line.get_color(),alpha=.8)
 ax.set(xlabel=r'Interaction angle $\theta$',ylabel=r'Conventional negativity $\mathcal{N}$',ylim=(-.01,.53));ax.legend(ncol=3,fontsize=7.5,loc='lower center');ax.grid(alpha=.2);fig.tight_layout();fig.savefig(FIG/'FigS1_JC_transfer.pdf');plt.close(fig)
 data=pd.read_csv(ROOT/'udw_pointlike_size_scan_v2.8.csv').sort_values('sigma_over_T');x=data.sigma_over_T.to_numpy();y=data.raw_entangling_gap.to_numpy();y0=y[np.argmin(x)]
 fig,axs=plt.subplots(2,1,figsize=(5.2,4.5));axs[0].plot(x,y*1e6,'o-',ms=3);axs[0].axhline(0,ls='--',lw=.8,color='gray');axs[0].set(xlabel=r'Radius $\sigma/T$',ylabel=r'Gap coefficient ($10^{-6}$)',ylim=(-.03,1.6));axs[0].text(.02,.85,'(a)',transform=axs[0].transAxes)
 axs[1].plot(x*x,(y-y0)*1e10,'o',ms=3,label='Archived scan');axs[1].plot(x*x,1.96656e-6*x*x*1e10,'--',lw=1,label=r'Leading $\sigma^2$ term');axs[1].set(xlabel=r'$(\sigma/T)^2$',ylabel=r'Gap change ($10^{-10}$)');axs[1].legend(fontsize=7.5);axs[1].text(.02,.85,'(b)',transform=axs[1].transAxes)
 for ax in axs:ax.grid(alpha=.2)
 fig.tight_layout();fig.savefig(FIG/'FigS2_compact_gap.pdf');plt.close(fig)

def main():
 p=argparse.ArgumentParser();p.add_argument('--chinese-font');p.add_argument('--english-only',action='store_true');args=p.parse_args()
 latin=font_manager.FontProperties(family='DejaVu Sans')
 for zh in ([False] if args.english_only else [False,True]):
  fp=chinese_font(args.chinese_font) if zh else latin
  # CJK OpenType/CFF subsets can lose visible glyphs in Type-42 PDF output.
  # Type-3 vector glyph outlines retain the same text, metrics and layout.
  with plt.rc_context({'pdf.fonttype':3 if zh else 42}):
   chain(zh,fp);hierarchy(zh,fp);support(zh,fp)
 numerical();print('Regenerated manuscript vector figures in',FIG)
if __name__=='__main__':main()
