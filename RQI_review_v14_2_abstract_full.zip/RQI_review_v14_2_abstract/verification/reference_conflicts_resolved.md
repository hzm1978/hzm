# 本轮书目登记差异的处理

日期：2026-11-05。完整记录见 `reference_audit.json`。

## Sorkin 章节年份

保留 **1993**。题目和 DOI 均匹配，但 Crossref 与 Cambridge 当前网页元数据将出版年登记为 1956；该日期与出版社给出的“1993 International Symposium”书名以及原始预印本矛盾。

- [Crossref 章节记录](https://api.crossref.org/works/10.1017%2FCBO9780511524653.024)：错误的 1956 日期，题名、作者和 293–305 页匹配。
- [Cambridge 章节页面](https://doi.org/10.1017/CBO9780511524653.024)：同一日期登记问题，书名明确包含 1993。
- [原始预印本 gr-qc/9302018](https://arxiv.org/abs/gr-qc/9302018)：Rafael D. Sorkin，1993/02/17，题目匹配。
- [ISBN 9780521452670 图书目录](https://openlibrary.org/api/books?bibkeys=ISBN:9780521452670&format=json&jscmd=data)：该系列两卷的合并目录记录给出 publish_date=1993；作为出版年份的独立交叉证据，不用其合并题名替换章节书名。

## 作者姓名拆分

PercheGozzini2026、Torres2023、AgonCasiniGursoyPlanella2025、VeitchEtAl2014、CamposDelgadoIpek2026 的完整姓名和作者次序匹配，差异来自复合姓氏或名字被登记为 given/family 的不同部分。保留原书目姓名写法。正文另有 Martín-Martínez 重音符号缺少反斜杠的问题，已修正。

## 卷号

Paris2009：7 与 07 是同一卷，保留 7。没有据字符串差异制造新的书目改动。
