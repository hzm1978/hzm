# RQI 综述 v14：稿件、计算与投稿判断

日期：2026-11-05。输入为作者上传的 `RQI_FoP_v13_2_FINAL.zip`，原件未被覆盖。

论文题目：**Quantum resources from localized quantum-field measurements: extraction and certification**  
中文题目：**局域量子场测量中的量子资源：提取与认证**

## 主要文件

| 文件 | 内容 |
|---|---|
| `manuscript_en.tex` / `manuscript_en.pdf` | 完整英文稿，含附录 A–G |
| `manuscript_zh.tex` / `manuscript_zh.pdf` | 对应完整中文稿，含相同公式、图表及附录 |
| `rqi_refs.bib` | 共用参考文献；按各稿首次引用顺序生成编号 |
| `figures/` | 五幅图的英文/中文示意图及数值图，均为矢量 PDF |
| `calculations/` | 计算、独立积分重建、绘图程序、输入数据和结果 |
| `REVIEW_AND_JOURNALS_zh.md` | 是否值得投稿、期刊选择、问题及修改结论 |
| `SOURCE_AUDIT.md` | 文献核验和实际阅读/复算范围 |
| `verification/` | 当前运行日志、书目记录和文档核查结果 |
| `submission/` | 为首选 Foundations of Physics 准备的综述提案与投稿信草稿 |

## 编译与复核

建议 Python 3.10 以上，完整 TeX Live 的 XeLaTeX、BibTeX、latexmk，以及 ctex 和中文字体。Python 依赖：

```bash
python -m pip install -r requirements.txt
```

编译两份稿件：

```bash
python build.py
```

重新生成图表、编译并运行全部检查：

```bash
python run_all_checks.py --figures --build
```

程序均按自身位置查找文件，可以从其他工作目录调用，不依赖原工程目录。中文绘图自动查找 Noto CJK 等字体；也可使用 `python calculations/make_figures.py --chinese-font FONT_PATH` 指定本机字体。英文单独编译可用 `python build.py --language en`。

`calculations/README.md` 对应计算与论文位置。历史 CSV 和部分核心检查脚本保留原文件名，便于追溯；此次结果均由实际重跑生成。原包中的旧日志、缓存和依赖未交付目录的检查器没有被当作本次通过证据。

## 投稿定位

本稿适合作为批判性综述推进。首选 **Foundations of Physics**，备选 **Quantum Information Processing**；**Frontiers of Physics** 可作编辑咨询对象。三者的范围、综述政策及 SCIE 页面依据见核查报告。两本名为 Foundations / Frontiers 的期刊必须区分。

正文采用首选期刊适用的 Springer Nature 数字引文模板。英文稿为有署名版本；Foundations of Physics 的公开页面说明采用 single-blind review。没有冒充邀稿或编辑认可，也没有向期刊发送或提交材料。录用与否仍取决于编辑判断和同行评审。

本包提供计算和可编辑文件，不声称独立验证了全部引用论文的所有证明、全阶场论余项或实验原始数据。
