#!/usr/bin/env python3
"""Build English and Chinese manuscripts with XeLaTeX and BibTeX via latexmk."""
from pathlib import Path
import argparse,subprocess
ROOT=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--language',choices=['en','zh','both'],default='both');args=p.parse_args()
for lang in (['en','zh'] if args.language=='both' else [args.language]):
 subprocess.run(['latexmk','-xelatex','-interaction=nonstopmode','-halt-on-error',f'manuscript_{lang}.tex'],cwd=ROOT,check=True)
