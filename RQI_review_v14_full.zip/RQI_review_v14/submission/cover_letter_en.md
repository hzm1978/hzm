# Cover-letter draft — Foundations of Physics

5 November 2026

Dear Editor,

Please consider the review-type manuscript **“Quantum resources from localized quantum-field measurements: extraction and certification”** for publication in Foundations of Physics.

The article examines the inference from causal local operations and field correlations to a specified probe state, a scenario-dependent resource criterion and a calibrated measurement record. It builds on the local-measurement review by Papageorgiou and Fraser (2024) and the interaction-induced resource-attribution framework of Nyström and co-workers (2026). Its contribution is a focused critical synthesis with explicit diagnostics, not a new universal resource theory.

The review retains the assumptions of Gaussian accessibility and zero-gap results, distinguishes structural local-channel invariance from perturbative revival, and supplies a phase-family counterexample to an unrestricted curvature–QFI identification in the finite-dimensional spin-flip representation. Technical appendices and reproducibility files state which calculations were performed and their limits.

The manuscript includes funding, competing-interest, data/code and author-contribution statements. OpenAI ChatGPT assisted literature organization, explanatory drafting, bilingual revision, citation checks and Python/Matplotlib code work; this substantive assistance is disclosed. The author remains responsible for the final scientific content. No experiment or all-orders continuum calculation is claimed.

Thank you for considering the manuscript.

Sincerely,

Zhiming Huang  
School of Economics and Management, Wuyi University  
Jiangmen 529020, China  
465609785@qq.com

*Draft only. Concurrent-submission, originality and other submission-system facts must be entered truthfully by the author; they are not asserted here without confirmation. No letter has been sent.*
