# Review proposal for Foundations of Physics

**Proposed title:** Quantum resources from localized quantum-field measurements: extraction and certification

**Author:** Zhiming Huang, School of Economics and Management, Wuyi University, Jiangmen 529020, China; 465609785@qq.com.

**Article type:** Critical narrative review. Prepared 5 November 2026.

Dear Editor-in-Chief,

I would like to propose a review addressing the assumptions that connect a localized quantum-field interaction to a certified resource in a retained probe. The organizing question is foundational: which physical object and level of evidence support each step from field correlations and an admissible apparatus to a probe state, a resource claim, and an operational task?

The article builds on Papageorgiou and Fraser's review of local measurement theory, Foundations of Physics 54, 26 (2024), https://doi.org/10.1007/s10701-024-00756-8. It also incorporates the interaction-induced attribution conditions of Nyström and co-workers, arXiv:2606.17287v1. The proposed contribution is their connection to complete interaction supports, specified retained outputs, scenario-dependent resource criteria, and calibrated finite-sample records. It is not presented as a new universal resource theory or as an optimal harvesting protocol.

Examples distinguish equal measurement effects from unequal back-action, field-region mutual information from detector entanglement, mixed-state residual negativity from GME certification, and state sensitivity from entanglement curvature. A pure phase family explicitly shows why spin-flip self-duality alone does not identify concurrence curvature with quantum Fisher information. Gaussian mode access, noncompact switching, composite observables and perturbative revival diagnostics are discussed with their hypotheses. Communication and metrology remain conditional tests of utility.

The main article has eight sections: introduction; local measurements and causal structure; field correlations and detector access; harvesting with localized probes; resource criteria and certification; observables and readout; communication and estimation; conclusions. Seven technical appendices supply the benchmark definitions, derivations and checkable examples. The current complete draft includes five figures, seven tables, 125 references and reproducibility files. If preferable, the technical appendices can be supplied as electronic supplementary material.

The English manuscript, corresponding Chinese working copy, sources and verification files have been prepared. I would welcome advice on whether this topic and scope are suitable for a review-type submission to Foundations of Physics.

Sincerely,

Zhiming Huang
