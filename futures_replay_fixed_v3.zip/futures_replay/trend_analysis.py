from __future__ import annotations

"""Causal trend-trading structure analysis for the FuturesReplay main chart.

The rules are an operational interpretation of 鹿希武《趋势交易法》:
* market state: uptrend, downtrend or sideways consolidation;
* an uptrend line joins a significant low to a later higher low, with at
  least one intervening swing high and no price penetration between anchors;
* a downtrend line is the symmetric construction;
* the opposite-side exterior joins are shifted through their intervening
  structural extreme to construct a pivot line (printed pp. 69-82);
* trend-line penetration is a warning; a close through the latest structural
  pivot is the stronger trend-structure invalidation condition.

Only bars supplied in ``frame`` are used. A pivot at bar i is unavailable
until ``right`` subsequent bars have closed. This confirmation delay is
intentional and prevents the indicator from drawing a pivot before it could
have been known in real time.

Swing / ratio / candle / correction annotations share these confirmed pivots.
They do not reuse or alter the separate Elliott-wave count.
"""

from dataclasses import dataclass, replace
from math import isfinite

import numpy as np
import pandas as pd

from .trend_patterns import (
    TrendCorrection, TrendLabel, book_candle_patterns, correction_patterns,
    key_reversals, retracement_labels,
)


@dataclass(frozen=True)
class TrendPivot:
    index: int
    price: float
    kind: str  # "H" or "L"
    confirmed_at: int


@dataclass(frozen=True)
class TrendAnalysis:
    direction: str  # "up", "down", "sideways", "unknown"
    status: str
    pivots: tuple[TrendPivot, ...]
    trendline: tuple[TrendPivot, TrendPivot] | None
    trendline_slope: float | None
    trendline_value: float | None
    trendline_broken: bool
    channel_offset: float | None
    channel_value: float | None
    pivot_line_offset: float | None
    pivot_line_value: float | None
    pivot_line_broken: bool
    key_level: float | None
    key_level_kind: str | None
    key_level_index: int | None
    key_level_broken: bool
    breakout: str | None
    pullback_percent: float | None
    pullback_pivot: TrendPivot | None
    signal: str | None
    signal_index: int | None
    signal_pattern: str | None
    signal_price: float | None
    atr_value: float | None
    range_high: float | None
    range_low: float | None
    range_start_index: int | None
    as_of_index: int
    external_line: tuple[TrendPivot, TrendPivot] | None = None
    pivot_line_anchor: TrendPivot | None = None
    retracements: tuple[TrendLabel, ...] = ()
    reversals: tuple[TrendLabel, ...] = ()
    corrections: tuple[TrendCorrection, ...] = ()


def _wilder_atr(
    high: np.ndarray,
    low: np.ndarray,
    close: np.ndarray,
    period: int,
) -> np.ndarray:
    previous = np.concatenate(([close[0]], close[:-1]))
    tr = np.maximum(
        high - low,
        np.maximum(np.abs(high - previous), np.abs(low - previous)),
    )
    out = np.full(len(tr), np.nan, dtype=float)
    if not len(tr):
        return out
    seed_n = min(max(1, int(period)), len(tr))
    out[seed_n - 1] = float(np.mean(tr[:seed_n]))
    for i in range(seed_n, len(tr)):
        out[i] = (out[i - 1] * (period - 1) + tr[i]) / period
    out[:seed_n - 1] = np.cumsum(tr[:seed_n - 1]) / np.arange(1, seed_n)
    return out


def _confirmed_pivots(
    high: np.ndarray,
    low: np.ndarray,
    atr: np.ndarray,
    *,
    left: int,
    right: int,
    min_swing_atr: float,
    min_swing_percent: float,
) -> tuple[TrendPivot, ...]:
    """Return alternating local extrema, each delayed by ``right`` bars."""
    n = len(high)
    if n < left + right + 1:
        return ()

    candidates: list[TrendPivot] = []
    for i in range(left, n - right):
        hwin = high[i - left : i + right + 1]
        lwin = low[i - left : i + right + 1]

        # Asymmetric comparisons make ties deterministic: the candidate must
        # be at least as extreme as all bars to its left and strictly more
        # extreme than every bar to its right.
        is_high = high[i] >= float(np.max(hwin[:left])) and high[i] > float(np.max(hwin[left + 1 :]))
        is_low = low[i] <= float(np.min(lwin[:left])) and low[i] < float(np.min(lwin[left + 1 :]))
        if is_high == is_low:  # neither, or an ambiguous outside bar
            continue

        kind = "H" if is_high else "L"
        price = float(high[i] if is_high else low[i])
        candidates.append(TrendPivot(i, price, kind, i + right))

    pivots: list[TrendPivot] = []
    for point in candidates:
        if not pivots:
            pivots.append(point)
            continue

        previous = pivots[-1]
        if point.kind == previous.kind:
            more_extreme = (
                point.price > previous.price if point.kind == "H"
                else point.price < previous.price
            )
            if more_extreme:
                pivots[-1] = point
            continue

        local_atr = float(atr[point.index]) if isfinite(float(atr[point.index])) else 0.0
        threshold = max(
            local_atr * float(min_swing_atr),
            abs(point.price) * float(min_swing_percent),
            1e-12,
        )
        if abs(point.price - previous.price) >= threshold:
            pivots.append(point)

    return tuple(pivots)


def _line_value(a: TrendPivot, b: TrendPivot, index: int) -> tuple[float, float]:
    dx = int(b.index) - int(a.index)
    if dx == 0:
        return float(b.price), 0.0
    slope = (float(b.price) - float(a.price)) / dx
    return float(a.price) + slope * (int(index) - int(a.index)), float(slope)


def _select_valid_trendline(
    direction: str,
    pivots: tuple[TrendPivot, ...],
    high: np.ndarray,
    low: np.ndarray,
    atr: np.ndarray,
    global_to_local: dict[int, int],
    global_positions: np.ndarray,
    as_of_index: int,
    *,
    min_anchor_bars: int,
) -> tuple[TrendPivot, TrendPivot] | None:
    """Choose a book-style, non-penetrated trendline from confirmed pivots.

    Uptrend: low -> higher low, with a swing high between the anchors.
    Downtrend: high -> lower high, with a swing low between the anchors.
    The line is checked against all intervening candle extremes. The newest
    valid second anchor is preferred; longer spans break ties.
    """
    kind = "L" if direction == "up" else "H"
    candidates = [p for p in pivots if p.kind == kind and p.index in global_to_local][-14:]
    if len(candidates) < 2:
        return None

    opposite = "H" if direction == "up" else "L"
    other_pivots = [p for p in pivots if p.kind == opposite][-20:]
    valid: list[tuple[tuple[int, int, int], TrendPivot, TrendPivot]] = []

    for i, a in enumerate(candidates[:-1]):
        for b in candidates[i + 1 :]:
            span = int(b.index) - int(a.index)
            if span < min_anchor_bars:
                continue

            if direction == "up" and b.price <= a.price:
                continue
            if direction == "down" and b.price >= a.price:
                continue

            between = [p for p in other_pivots if a.index < p.index < b.index]
            if not between:
                continue

            local_a = global_to_local[a.index]
            local_b = global_to_local[b.index]
            # Book pp. 37-38 / 46-49: the second anchor precedes the trend's
            # extreme. The only stated exception is a confirmed double top /
            # bottom, whose intervening neckline may be the second anchor.
            extreme_local = local_a + int(np.argmax(high[local_a:]) if direction == "up" else np.argmin(low[local_a:]))
            if b.index >= int(global_positions[extreme_local]):
                double_turn = False
                for p, q in zip(other_pivots, other_pivots[1:]):
                    if not (a.index < p.index < b.index < q.index):
                        continue
                    tolerance = max(float(atr[local_b]) * 0.5, abs(float(p.price)) * 0.001)
                    between_points = [z for z in candidates if p.index < z.index < q.index]
                    neck = (min(between_points, key=lambda z: z.price) if direction == "up"
                            else max(between_points, key=lambda z: z.price)) if between_points else None
                    if abs(p.price - q.price) <= tolerance and neck is not None and neck.index == b.index:
                        double_turn = True
                        break
                if not double_turn:
                    continue
            line_a, slope = _line_value(a, b, b.index)
            if direction == "up" and slope <= 0:
                continue
            if direction == "down" and slope >= 0:
                continue

            # The line may be tested only between its two construction points.
            # A later penetration is kept and reported as a break, not used to
            # erase the historical trendline.
            crossed = False
            for local_i in range(local_a, local_b + 1):
                global_i = int(global_positions[local_i])
                line_price = float(a.price) + slope * (global_i - int(a.index))
                tolerance = max(abs(line_price) * 1e-10, 1e-12)
                if direction == "up" and float(low[local_i]) < line_price - tolerance:
                    crossed = True
                    break
                if direction == "down" and float(high[local_i]) > line_price + tolerance:
                    crossed = True
                    break
            if crossed:
                continue

            touches = 0
            for p in candidates:
                if a.index <= p.index <= b.index:
                    line_price, _ = _line_value(a, b, p.index)
                    if abs(p.price - line_price) <= max(
                        float(atr[global_to_local[p.index]]) * 0.35,
                        abs(p.price) * 0.0002,
                    ):
                        touches += 1

            # Prefer the latest valid second anchor, then more touches, then
            # a wider time span. This avoids choosing an obsolete early line.
            score = (int(b.index), int(touches), int(span))
            valid.append((score, a, b))

    if not valid:
        return None
    _score, a, b = max(valid, key=lambda item: item[0])
    return a, b


def _select_external_channel(direction, pivots, high, low, atr, global_to_local):
    """Book pp. 69-82: find the opposite exterior, then shift through D.

    Rising trend: connect two exterior highs C/E and shift through the low D
    between them. Falling trend: connect two exterior lows and shift through
    the intervening high. Its slope need not equal the primary trendline.
    """
    kind = "H" if direction == "up" else "L"
    exterior = [p for p in pivots if p.kind == kind][-14:]
    local_to_global = {local: global_index for global_index, local in global_to_local.items()}
    candidates = []
    for i, a in enumerate(exterior[:-1]):
        for b in exterior[i + 1:]:
            if (b.price - a.price) * (1 if direction == "up" else -1) <= 0:
                continue
            inside = [p for p in pivots if p.kind != kind and a.index < p.index < b.index]
            if not inside:
                continue
            passed = True
            for j in range(global_to_local[a.index], global_to_local[b.index] + 1):
                position = local_to_global[j]
                value, _ = _line_value(a, b, position)
                tolerance = max(abs(value) * 1e-10, 1e-12)
                if (kind == "H" and high[j] > value + tolerance) or (kind == "L" and low[j] < value - tolerance):
                    passed = False
                    break
            if passed:
                # If more than one interior turn exists, use the exterior
                # displacement (not the lowest/highest nominal price). This
                # keeps the shifted line outside every intervening swing.
                residual = lambda p: p.price - _line_value(a, b, p.index)[0]
                anchor = min(inside, key=lambda p: (residual(p), -p.index)) if direction == "up" else max(inside, key=lambda p: (residual(p), p.index))
                candidates.append((b.index, b.index - a.index, a, b, anchor))
    if not candidates:
        return None, None
    _, _, a, b, anchor = max(candidates, key=lambda item: item[:2])
    return (a, b), anchor


def _bullish_reversal(
    open_: np.ndarray,
    high: np.ndarray,
    low: np.ndarray,
    close: np.ndarray,
) -> str | None:
    if len(close) < 3:
        return None

    o, h, l, c = map(float, (open_[-1], high[-1], low[-1], close[-1]))
    po, ph, pl, pc = map(float, (open_[-2], high[-2], low[-2], close[-2]))
    ppo, ppc = float(open_[-3]), float(close[-3])
    body = abs(c - o)
    span = max(h - l, 1e-12)
    lower = min(o, c) - l
    upper = h - max(o, c)

    if c > o and pc < po and o <= pc and c >= po:
        return "阳包阴"
    if c > o and lower >= max(body * 1.8, span * 0.35) and upper <= max(body * 0.8, span * 0.15):
        return "锤头线"
    if ppc < ppo and abs(pc - po) <= abs(ppc - ppo) * 0.55 and c > o and c >= (ppo + ppc) / 2:
        return "启明星"
    if c > o and c > ph:
        return "阳线突破前高"
    return None


def _bearish_reversal(
    open_: np.ndarray,
    high: np.ndarray,
    low: np.ndarray,
    close: np.ndarray,
) -> str | None:
    if len(close) < 3:
        return None

    o, h, l, c = map(float, (open_[-1], high[-1], low[-1], close[-1]))
    po, ph, pl, pc = map(float, (open_[-2], high[-2], low[-2], close[-2]))
    ppo, ppc = float(open_[-3]), float(close[-3])
    body = abs(c - o)
    span = max(h - l, 1e-12)
    lower = min(o, c) - l
    upper = h - max(o, c)

    if c < o and pc > po and o >= pc and c <= po:
        return "阴包阳"
    if c < o and upper >= max(body * 1.8, span * 0.35) and lower <= max(body * 0.8, span * 0.15):
        return "射击之星"
    if ppc > ppo and abs(pc - po) <= abs(ppc - ppo) * 0.55 and c < o and c <= (ppo + ppc) / 2:
        return "黄昏星"
    if c < o and c < pl:
        return "阴线跌破前低"
    return None


def analyze_trend(
    frame: pd.DataFrame,
    *,
    left: int = 3,
    right: int = 3,
    atr_period: int = 14,
    min_swing_atr: float = 0.8,
    min_swing_percent: float = 0.0025,
    lookback: int = 1200,
) -> TrendAnalysis | None:
    """Analyze the visible historical prefix only; never inspect future bars."""
    required = {"open", "high", "low", "close"}
    if frame is None or frame.empty or not required.issubset(frame.columns):
        return None

    try:
        raw = frame.loc[:, ["open", "high", "low", "close"]].apply(
            pd.to_numeric, errors="coerce"
        )
        raw_values = raw.to_numpy(dtype=float)
        valid = np.isfinite(raw_values).all(axis=1)
        valid_positions = np.flatnonzero(valid)
        if valid_positions.size == 0:
            return None
        valid_positions = valid_positions[-max(80, int(lookback)) :]
        data = raw.iloc[valid_positions]
        if "_trend_position" in frame.columns:
            global_positions = pd.to_numeric(
                frame["_trend_position"].iloc[valid_positions], errors="coerce"
            ).to_numpy(dtype=float)
            global_positions = np.where(
                np.isfinite(global_positions), global_positions, valid_positions
            ).astype(int)
        else:
            global_positions = valid_positions.astype(int)

        open_ = data["open"].to_numpy(dtype=float)
        high = data["high"].to_numpy(dtype=float)
        low = data["low"].to_numpy(dtype=float)
        close = data["close"].to_numpy(dtype=float)
    except Exception:
        return None

    n = len(close)
    as_of = int(global_positions[-1])
    empty_result = lambda status: TrendAnalysis(
        direction="unknown",
        status=status,
        pivots=(),
        trendline=None,
        trendline_slope=None,
        trendline_value=None,
        trendline_broken=False,
        channel_offset=None,
        channel_value=None,
        pivot_line_offset=None,
        pivot_line_value=None,
        pivot_line_broken=False,
        key_level=None,
        key_level_kind=None,
        key_level_index=None,
        key_level_broken=False,
        breakout=None,
        pullback_percent=None,
        pullback_pivot=None,
        signal=None,
        signal_index=None,
        signal_pattern=None,
        signal_price=None,
        atr_value=None,
        range_high=None,
        range_low=None,
        range_start_index=None,
        as_of_index=as_of,
    )
    if n < max(24, int(left) + int(right) + 10):
        return empty_result("数据不足")

    atr = _wilder_atr(high, low, close, max(2, int(atr_period)))
    raw_pivots = _confirmed_pivots(
        high,
        low,
        atr,
        left=max(1, int(left)),
        right=max(1, int(right)),
        min_swing_atr=float(min_swing_atr),
        min_swing_percent=float(min_swing_percent),
    )

    pivots = tuple(
        TrendPivot(
            int(global_positions[p.index]),
            float(p.price),
            p.kind,
            int(global_positions[min(p.confirmed_at, n - 1)]),
        )
        for p in raw_pivots
    )
    global_to_local = {int(g): i for i, g in enumerate(global_positions)}
    highs = [p for p in pivots if p.kind == "H"]
    lows = [p for p in pivots if p.kind == "L"]
    last_close = float(close[-1])
    atr_now = max(
        float(atr[-1]) if isfinite(float(atr[-1])) else 0.0,
        abs(last_close) * 1e-6,
        1e-12,
    )
    tolerance = max(atr_now * 0.12, abs(last_close) * 0.0001)

    direction = "unknown"
    if len(highs) >= 2 and len(lows) >= 2:
        higher_highs = highs[-1].price > highs[-2].price + tolerance
        higher_lows = lows[-1].price > lows[-2].price + tolerance
        lower_highs = highs[-1].price < highs[-2].price - tolerance
        lower_lows = lows[-1].price < lows[-2].price - tolerance
        if higher_highs and higher_lows:
            direction = "up"
        elif lower_highs and lower_lows:
            direction = "down"
        else:
            direction = "sideways"

    # Retain the latest confirmed trend while only one side of the structure
    # turns. Otherwise a mixed pivot erases the very lines needed to see their
    # break. A subsequently confirmed HH/HL or LH/LL replaces that prior state.
    mixed_structure = direction == "sideways"
    if mixed_structure:
        for stop in range(len(pivots) - 1, max(3, len(pivots) - 16), -1):
            old_highs = [p for p in pivots[:stop] if p.kind == "H"]
            old_lows = [p for p in pivots[:stop] if p.kind == "L"]
            if min(len(old_highs), len(old_lows)) < 2:
                continue
            dh = old_highs[-1].price - old_highs[-2].price
            dl = old_lows[-1].price - old_lows[-2].price
            if dh > tolerance and dl > tolerance:
                direction = "up"
                break
            if dh < -tolerance and dl < -tolerance:
                direction = "down"
                break

    trendline = None
    if direction in {"up", "down"}:
        trendline = _select_valid_trendline(
            direction,
            pivots,
            high,
            low,
            atr,
            global_to_local,
            global_positions,
            as_of,
            min_anchor_bars=max(4, int(left) + int(right)),
        )

    trendline_slope = None
    trendline_value = None
    trendline_broken = False
    channel_offset = None
    channel_value = None
    pivot_line_offset = None
    pivot_line_value = None
    pivot_line_broken = False
    external_line = None
    pivot_line_anchor = None
    key_level = None
    key_level_kind = None
    key_level_index = None
    key_level_broken = False
    breakout = None
    status = {
        "up": "上升趋势",
        "down": "下降趋势",
        "sideways": "横向整理",
        "unknown": "趋势未确认",
    }[direction]
    if mixed_structure and direction in {"up", "down"}:
        status += "（调整/转换观察）"

    if direction in {"up", "down"}:
        external_line, pivot_line_anchor = _select_external_channel(
            direction, pivots, high, low, atr, global_to_local
        )
        if external_line is not None and pivot_line_anchor is not None:
            ea, eb = external_line
            at_anchor, _ = _line_value(ea, eb, pivot_line_anchor.index)
            pivot_line_offset = float(pivot_line_anchor.price) - at_anchor
            exterior_now, _ = _line_value(ea, eb, as_of)
            pivot_line_value = exterior_now + pivot_line_offset
            pivot_line_broken = (last_close < pivot_line_value - tolerance if direction == "up"
                                 else last_close > pivot_line_value + tolerance)

    if trendline is not None:
        a, b = trendline
        trendline_value, trendline_slope = _line_value(a, b, as_of)

        if direction == "up":
            key_pivot = lows[-1] if lows else None
            if key_pivot is not None:
                key_level = float(key_pivot.price)
                key_level_kind = "关键低点"
                key_level_index = int(key_pivot.index)
                key_level_broken = last_close < key_level - tolerance
            trendline_broken = last_close < float(trendline_value) - tolerance
            if trendline_broken and pivot_line_broken:
                breakout = "uptrend_structure_broken"
                status = "上升趋势结构破坏"
            elif trendline_broken:
                breakout = "uptrend_line_broken"
                status = "上升趋势线破位预警"
            elif pivot_line_broken:
                breakout = "uptrend_pivot_line_broken"
                status = "上升趋势拐点线失守"
            elif key_level_broken:
                breakout = "uptrend_key_low_broken"
                status = "上升趋势关键低点失守"
        elif direction == "down":
            key_pivot = highs[-1] if highs else None
            if key_pivot is not None:
                key_level = float(key_pivot.price)
                key_level_kind = "关键高点"
                key_level_index = int(key_pivot.index)
                key_level_broken = last_close > key_level + tolerance
            trendline_broken = last_close > float(trendline_value) + tolerance
            if trendline_broken and pivot_line_broken:
                breakout = "downtrend_structure_broken"
                status = "下降趋势结构破坏"
            elif trendline_broken:
                breakout = "downtrend_line_broken"
                status = "下降趋势线突破预警"
            elif pivot_line_broken:
                breakout = "downtrend_pivot_line_broken"
                status = "下降趋势拐点线突破"
            elif key_level_broken:
                breakout = "downtrend_key_high_broken"
                status = "下降趋势关键高点突破"
    elif direction in {"up", "down"}:
        status += "（趋势线尚未确认）"

    # Measure the latest completed ABC correction as a descriptive ratio.
    # This is not used as a standalone buy/sell trigger.
    pullback_percent = None
    pullback_pivot = None
    if len(pivots) >= 3:
        a, b, c = pivots[-3:]
        if direction == "up" and (a.kind, b.kind, c.kind) == ("L", "H", "L"):
            impulse = float(b.price - a.price)
            if impulse > 0 and c.price > a.price:
                pullback_percent = (float(b.price) - float(c.price)) / impulse * 100.0
                pullback_pivot = c
        elif direction == "down" and (a.kind, b.kind, c.kind) == ("H", "L", "H"):
            impulse = float(a.price - b.price)
            if impulse > 0 and c.price < a.price:
                pullback_percent = (float(c.price) - float(b.price)) / impulse * 100.0
                pullback_pivot = c

    signal = None
    signal_pattern = None
    signal_price = None
    signal_index = as_of

    range_start_local = max(0, n - 40)
    range_high = float(np.max(high[range_start_local:]))
    range_low = float(np.min(low[range_start_local:]))
    range_start_index = int(global_positions[range_start_local])

    ratios = retracement_labels(pivots)
    candle_shapes = book_candle_patterns(data, global_positions)
    reversals = list(key_reversals(candle_shapes, pivots, global_positions, atr))
    # A completed candle at a previously known line is observable immediately;
    # confirmation of the new swing pivot still requires the right-hand bars.
    marked = {(item.index, item.text) for item in reversals}
    levels = [("趋势线附近", trendline_value), ("拐点线附近", pivot_line_value), ("关键结构位", key_level)]
    for shape in candle_shapes:
        if shape.index != as_of or (shape.index, shape.text) in marked:
            continue
        context = next((name for name, value in levels if value is not None and abs(shape.price - value) <= atr_now * 0.8), None)
        if context is not None:
            reversals.append(replace(shape, context=context + "·拐点待确认",
                                     direction=shape.direction or (1 if direction == "up" else -1)))
    latest_shape = next((shape for shape in reversals if shape.index == as_of), None)
    if latest_shape is not None:
        signal = "watch_buy" if latest_shape.direction > 0 else "watch_sell"
        signal_pattern, signal_price = latest_shape.text, latest_shape.price
    corrections = correction_patterns(data, pivots, global_positions, atr)

    return TrendAnalysis(
        direction=direction,
        status=status,
        pivots=pivots,
        trendline=trendline,
        trendline_slope=trendline_slope,
        trendline_value=trendline_value,
        trendline_broken=bool(trendline_broken),
        channel_offset=channel_offset,
        channel_value=channel_value,
        pivot_line_offset=pivot_line_offset,
        pivot_line_value=pivot_line_value,
        pivot_line_broken=bool(pivot_line_broken),
        key_level=key_level,
        key_level_kind=key_level_kind,
        key_level_index=key_level_index,
        key_level_broken=bool(key_level_broken),
        breakout=breakout,
        pullback_percent=pullback_percent,
        pullback_pivot=pullback_pivot,
        signal=signal,
        signal_index=signal_index if signal else None,
        signal_pattern=signal_pattern,
        signal_price=signal_price,
        atr_value=atr_now,
        range_high=range_high,
        range_low=range_low,
        range_start_index=range_start_index,
        as_of_index=as_of,
        external_line=external_line,
        pivot_line_anchor=pivot_line_anchor,
        retracements=ratios,
        reversals=tuple(reversals),
        corrections=corrections,
    )
