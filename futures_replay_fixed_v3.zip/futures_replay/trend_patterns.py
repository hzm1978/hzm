from __future__ import annotations

"""Inspectable chart annotations for 鹿希武《趋势交易法》, first edition.

Sources: printed pp. 133-174 (nine candle patterns), 191-215 (corrections
and ratios), 312-319 (continuation geometries). Geometric tolerances below
are implementation parameters, not additional rules attributed to the book.
Only the supplied closed-bar prefix and already confirmed pivots are used.
"""

from dataclasses import dataclass, replace
from typing import Sequence

import numpy as np
import pandas as pd


@dataclass(frozen=True)
class TrendLabel:
    index: int
    price: float
    text: str
    direction: int
    confirmed_at: int
    start_index: int
    context: str = ""
    percent: float | None = None


@dataclass(frozen=True)
class TrendCorrection:
    kind: str
    label: str
    start_index: int
    end_index: int
    lines: tuple[tuple[tuple[float, float], tuple[float, float]], ...]
    markers: tuple
    marker_labels: tuple[str, ...]
    label_index: int
    label_price: float
    direction: int
    confirmed_at: int
    state: str = "candidate"


def retracement_labels(pivots: Sequence) -> tuple[TrendLabel, ...]:
    """Measure corrections against their impulse; extensions against like legs.

    A new high / low is not mislabeled a >100% retracement of the small
    preceding counter-swing. Its extension is measured against the previous
    same-direction impulse (book pp. 193-198).
    """
    labels = []
    for i, (a, b, c) in enumerate(zip(pivots, pivots[1:], pivots[2:])):
        if a.kind != c.kind or a.kind == b.kind:
            continue
        impulse = abs(float(b.price) - float(a.price))
        if impulse <= max(abs(float(a.price)), 1.0) * 1e-12:
            continue
        percent = abs(float(c.price) - float(b.price)) / impulse * 100.0
        context = "retracement"
        text = f"回调 {percent:.1f}%"
        if percent > 100.0:
            if i == 0:
                continue
            previous = pivots[i - 1]
            same_direction_impulse = abs(float(a.price) - float(previous.price))
            if same_direction_impulse <= max(abs(float(a.price)), 1.0) * 1e-12:
                continue
            percent = abs(float(c.price) - float(b.price)) / same_direction_impulse * 100.0
            context, text = "extension", f"延伸 {percent:.1f}%"
        labels.append(TrendLabel(
            c.index, c.price, text, 1 if c.kind == "L" else -1,
            max(a.confirmed_at, b.confirmed_at, c.confirmed_at),
            b.index, context=context, percent=percent,
        ))
    return tuple(labels)


def book_candle_patterns(frame: pd.DataFrame, positions: np.ndarray) -> tuple[TrendLabel, ...]:
    """Recognize the book's nine candle shapes; location is filtered separately.

    Hammer / shooting-star body colour is unrestricted. Stars use the usual
    three closed candles and a >50% recovery; continuous-session futures do not
    require a gap. A doji by itself has no assigned bullish/bearish direction.
    """
    values = frame[["open", "high", "low", "close"]].to_numpy(dtype=float)
    labels = []
    for i, (o, h, l, c) in enumerate(values):
        body, span = abs(c - o), max(h - l, 1e-12)
        lower, upper = min(o, c) - l, h - max(o, c)
        patterns = []
        if body <= span * 0.10:
            patterns.append(("十字星", 0, i))
        elif lower >= body * 2 and upper <= max(body * 0.5, span * 0.10) and body <= span * 0.35:
            patterns.append(("锤子线", 1, i))
        elif upper >= body * 2 and lower <= max(body * 0.5, span * 0.10) and body <= span * 0.35:
            patterns.append(("流星线", -1, i))
        if i:
            po, ph, pl, pc = values[i - 1]
            prior_body = abs(pc - po)
            if c > o and pc < po and o <= pc and c >= po:
                patterns.append(("阳包阴", 1, i - 1))
            elif c < o and pc > po and o >= pc and c <= po:
                patterns.append(("阴包阳", -1, i - 1))
            mid = (po + pc) / 2
            if prior_body >= (ph - pl) * 0.45:
                if pc > po and c < o and o > pc and po < c < mid:
                    patterns.append(("乌云盖顶", -1, i - 1))
                elif pc < po and c > o and o < pc and mid < c < po:
                    patterns.append(("刺透形态", 1, i - 1))
        if i >= 2:
            fo, fh, fl, fc = values[i - 2]
            mo, _, _, mc = values[i - 1]
            first_body = abs(fc - fo)
            small_middle = first_body > 0 and abs(mc - mo) <= first_body * 0.5
            long_first = first_body >= (fh - fl) * 0.5
            if long_first and small_middle:
                if fc < fo and max(mo, mc) <= (fo + fc) / 2 and c > o and c > (fo + fc) / 2:
                    patterns.append(("启明星", 1, i - 2))
                elif fc > fo and min(mo, mc) >= (fo + fc) / 2 and c < o and c < (fo + fc) / 2:
                    patterns.append(("黄昏星", -1, i - 2))
        for text, direction, first in patterns:
            price = float(np.min(values[first:i + 1, 2]) if direction >= 0 else np.max(values[first:i + 1, 1]))
            labels.append(TrendLabel(int(positions[i]), price, text, direction,
                                     int(positions[i]), int(positions[first])))
    return tuple(labels)


def key_reversals(patterns: Sequence[TrendLabel], pivots: Sequence,
                  positions: np.ndarray, atr: np.ndarray) -> tuple[TrendLabel, ...]:
    """Retain shapes at confirmed structural extremes, at the actual candle.

    A historical marker records the later of shape completion and pivot
    confirmation. It is not moved from the reversal candle onto a nearby bar.
    """
    result = []
    as_of = int(positions[-1])

    for pattern in patterns:
        matches = []
        for point in pivots:
            if point.confirmed_at > as_of:
                continue
            if pattern.direction > 0 and point.kind != "L":
                continue
            if pattern.direction < 0 and point.kind != "H":
                continue
            if not pattern.start_index - 2 <= point.index <= pattern.index + 2:
                continue
            local = min(int(np.searchsorted(positions, point.index)), len(atr) - 1)
            tolerance = max(float(atr[local]) * 0.8, abs(float(point.price)) * 0.001, 1e-12)
            # Neutral doji direction/price follows its structural location.
            if pattern.direction and abs(pattern.price - point.price) > tolerance:
                continue
            matches.append((abs(pattern.index - point.index), point))
        if matches:
            point = min(matches, key=lambda item: item[0])[1]
            result.append(replace(
                pattern, direction=1 if point.kind == "L" else -1,
                price=float(point.price) if not pattern.direction else pattern.price,
                context="关键波谷" if point.kind == "L" else "关键波峰",
                confirmed_at=max(pattern.confirmed_at, point.confirmed_at),
            ))
    return tuple(result)


def _line(a, b):
    slope = (float(b.price) - float(a.price)) / max(1, b.index - a.index)
    return slope, float(a.price) - slope * a.index


def _segments(points):
    return tuple(((float(a.index), float(a.price)), (float(b.index), float(b.price)))
                 for a, b in zip(points, points[1:]))


def correction_patterns(frame: pd.DataFrame, pivots: Sequence, positions: np.ndarray,
                        atr: np.ndarray, max_patterns: int = 16) -> tuple[TrendCorrection, ...]:
    """Simple / ABC / flat corrections and the five continuation geometries.

    Five geometries from pp. 312-317: triangle, expanding triangle, diamond,
    flag and wedge. A preceding impulse is required. Shape fit remains a
    candidate; a subsequent CLOSED-bar boundary break is labelled separately,
    including breaks opposite to the original trend. No 3-3-5 subwave count is
    claimed from a single-scale pivot sequence.
    """
    close = frame["close"].to_numpy(dtype=float)
    output = []
    as_of = int(positions[-1])

    def is_impulse(origin, end):
        previous_extremes = [p for p in pivots if p.kind == end.kind and p.index < origin.index]
        if not previous_extremes:
            return True
        direction = 1 if end.price > origin.price else -1
        # A small counter-leg cannot establish the opposite trend until it
        # breaks the preceding high / low of that proposed impulse direction.
        return direction * (end.price - previous_extremes[-1].price) > 0

    def local(index):
        return min(int(np.searchsorted(positions, index)), len(close) - 1)

    def complete(kind, name, points, lines, direction, marker_names, upper=None, lower=None, trigger=None, invalidation=None):
        available = max(p.confirmed_at for p in points)
        begin = int(np.searchsorted(positions, available, side="left"))
        end_index, label_index = points[-1].index, points[-1].index
        label_price = float(points[-1].price)
        state = "candidate"
        for j in range(begin, len(close)):
            tolerance = max(float(atr[j]) * 0.12, abs(float(close[j])) * 0.0001)
            sign = 0
            if trigger is not None:
                if direction * (close[j] - trigger) > tolerance:
                    sign = direction
                elif invalidation is not None and direction * (close[j] - invalidation) < -tolerance:
                    sign = -direction
            else:
                if upper and close[j] > upper[0] * positions[j] + upper[1] + tolerance:
                    sign = 1
                elif lower and close[j] < lower[0] * positions[j] + lower[1] - tolerance:
                    sign = -1
            if sign:
                state = "breakout" if sign == direction else "opposite_break"
                end_index = label_index = int(positions[j])
                label_price = float(close[j])
                available = int(positions[j])
                break
        suffix = {"candidate": "候选", "breakout": "顺向突破", "opposite_break": "反向破位"}[state]
        return TrendCorrection(kind, name + "·" + suffix, points[0].index, end_index,
                               tuple(lines), tuple(points), tuple(marker_names), label_index,
                               label_price, direction, available, state)

    # One counter-leg, followed by resumption through the impulse endpoint.
    for i in range(len(pivots) - 2):
        a, b, c = pivots[i:i + 3]
        if not is_impulse(a, b):
            continue
        direction = 1 if b.price > a.price else -1
        impulse = direction * (b.price - a.price)
        correction = direction * (b.price - c.price)
        if impulse <= 0 or not 0 < correction < impulse:
            continue
        item = complete("simple", "简单调整", (a, b, c), _segments((a, b, c)), direction,
                        ("起", "推动", "回调"), trigger=float(b.price), invalidation=float(a.price))
        if item.state != "candidate" or i == len(pivots) - 3:
            output.append(item)

    # A prior impulse plus three alternating counter-swings A-B-C.
    for i in range(len(pivots) - 4):
        origin, start, a, b, c = pivots[i:i + 5]
        if not is_impulse(origin, start):
            continue
        direction = 1 if start.price > origin.price else -1
        origins = [p.price for p in pivots if p.kind == origin.kind and p.index <= origin.index]
        trend_origin = min(origins) if direction > 0 else max(origins)
        if direction * (c.price - trend_origin) <= 0:
            # The entire proposed impulse has been reversed. Do not keep an
            # ordinary continuation-correction label on the new trend.
            continue
        a_leg = direction * (start.price - a.price)
        b_leg = direction * (b.price - a.price)
        if a_leg <= 0 or b_leg <= 0 or direction * (b.price - c.price) <= 0:
            continue
        ratio = b_leg / a_leg
        tolerance = max(float(atr[local(c.index)]) * 0.3, a_leg * 0.05)
        if 0.9 <= ratio <= 1.25 and abs(c.price - a.price) <= a_leg * 0.6:
            kind, name = "flat", "平台型ABC调整"
        elif 0.15 <= ratio < 0.9 and direction * (a.price - c.price) >= -tolerance:
            kind, name = "abc", "ABC折返调整"
        else:
            continue
        points = (start, a, b, c)
        output.append(complete(kind, name, points, _segments(points), direction,
                               ("起", "A", "B", "C"), trigger=float(b.price), invalidation=float(trend_origin)))

    def preceding_impulse(points):
        previous = [p for p in pivots if p.index < points[0].index]
        if not previous:
            return 0
        if not is_impulse(previous[-1], points[0]):
            return 0
        delta = float(points[0].price) - float(previous[-1].price)
        span = max(p.price for p in points) - min(p.price for p in points)
        if abs(delta) < max(float(atr[local(points[0].index)]) * 1.5, span * 0.8):
            return 0
        return 1 if delta > 0 else -1

    # At least two contacts per boundary; triangle labels require five swings.
    for size in (6, 8):
        for stop in range(size, len(pivots) + 1):
            points = tuple(pivots[stop - size:stop])
            direction = preceding_impulse(points)
            if not direction:
                continue
            highs = [p for p in points if p.kind == "H"]
            lows = [p for p in points if p.kind == "L"]
            if min(len(highs), len(lows)) < 3:
                continue
            x0, x1 = points[0].index, points[-1].index
            span = max(1, x1 - x0)
            scale = max(float(atr[local(x1)]), 1e-12)
            upper = tuple(np.polyfit([p.index for p in highs], [p.price for p in highs], 1))
            lower = tuple(np.polyfit([p.index for p in lows], [p.price for p in lows], 1))
            residual = max(
                max(abs(p.price - (upper[0] * p.index + upper[1])) for p in highs),
                max(abs(p.price - (lower[0] * p.index + lower[1])) for p in lows),
            )
            if residual > scale * 0.65:
                continue
            width0 = (upper[0] - lower[0]) * x0 + upper[1] - lower[1]
            width1 = (upper[0] - lower[0]) * x1 + upper[1] - lower[1]
            if min(width0, width1) <= scale * 0.3:
                continue
            top_move, bottom_move = upper[0] * span, lower[0] * span
            flat = scale * 0.4
            ratio = width1 / width0
            kind = name = None
            if ratio < 0.8 and top_move <= flat and bottom_move >= -flat:
                kind, name = "triangle", "三角形调整"
            elif ratio > 1.3 and top_move > flat and bottom_move < -flat:
                kind, name = "expanding_triangle", "扩张三角调整"
            elif 0.75 <= ratio <= 1.25 and direction * (top_move + bottom_move) < -flat:
                kind, name = "flag", "旗形调整"
            elif ratio < 0.8 and top_move * bottom_move > 0:
                kind, name = "wedge", "上升楔形调整" if top_move > 0 else "下降楔形调整"
            if not kind:
                continue
            lines = tuple(((float(x0), float(line[0] * x0 + line[1])),
                           (float(x1), float(line[0] * x1 + line[1]))) for line in (upper, lower))
            # The initial boundary point starts the five ABCDE legs.
            names = ("起", "a", "b", "c", "d", "e") if size == 6 else ("",) * size
            output.append(complete(kind, name, points, lines, direction, names, upper, lower))

    # Diamond: widening on both sides, then narrowing on both sides.
    for stop in range(8, len(pivots) + 1):
        points = tuple(pivots[stop - 8:stop])
        direction = preceding_impulse(points)
        highs = [p for p in points if p.kind == "H"]
        lows = [p for p in points if p.kind == "L"]
        if not direction or len(highs) != 4 or len(lows) != 4:
            continue
        hi = max(range(4), key=lambda j: highs[j].price)
        lo = min(range(4), key=lambda j: lows[j].price)
        if hi not in (1, 2) or lo not in (1, 2):
            continue
        scale = max(float(atr[local(points[-1].index)]), 1e-12)
        mid_width = highs[hi].price - lows[lo].price
        if mid_width < 1.3 * max(highs[0].price - lows[0].price, highs[-1].price - lows[-1].price):
            continue
        if min(highs[hi].price - max(highs[0].price, highs[-1].price),
               min(lows[0].price, lows[-1].price) - lows[lo].price) < scale * 0.4:
            continue
        if not (all(highs[j + 1].price > highs[j].price for j in range(hi))
                and all(highs[j + 1].price < highs[j].price for j in range(hi, 3))
                and all(lows[j + 1].price < lows[j].price for j in range(lo))
                and all(lows[j + 1].price > lows[j].price for j in range(lo, 3))):
            continue
        lines = _segments((highs[0], highs[hi], highs[-1])) + _segments((lows[0], lows[lo], lows[-1]))
        output.append(complete("diamond", "钻石形调整", points, lines, direction,
                               ("",) * 8, _line(highs[hi], highs[-1]), _line(lows[lo], lows[-1])))

    # Prefer a recent representative, rather than many overlapping copies of
    # the same shape. Complex geometries take priority over an enclosed ABC.
    selected = []
    priority = {"diamond": 5, "triangle": 4, "expanding_triangle": 4, "flag": 3, "wedge": 3, "abc": 2, "flat": 2, "simple": 1}
    for item in sorted(output, key=lambda p: (p.end_index, priority[p.kind], p.start_index), reverse=True):
        if item.confirmed_at > as_of:
            continue
        duplicate = False
        for old in selected:
            inter = max(0, min(item.end_index, old.end_index) - max(item.start_index, old.start_index))
            union = max(item.end_index, old.end_index) - min(item.start_index, old.start_index)
            if item.kind == old.kind and inter / max(1, union) > 0.6:
                duplicate = True
                break
        if not duplicate:
            selected.append(item)
        if len(selected) >= max_patterns:
            break
    return tuple(sorted(selected, key=lambda p: (p.end_index, p.start_index)))
