# 期货复盘训练系统 v4

依据最新版《趋势交易法》第三版 `3.pdf` 重写趋势指标。包括区间跨度与级别、波浪线、趋势/拐点线、主A/导A、标准K与关键位置反转、四类调整浪、回调比例、延时突破及PSTD参考。

已有程序：退出并备份后，用整个 `futures_replay` 文件夹覆盖原同名文件夹。所有新增模块都要保留。原数据及交易记录保留。

独立启动：

```text
python -m pip install -r requirements.txt
python run.py
```

Windows也可双击“启动程序.bat”。这是Python源码包，需要已安装Python及依赖。

打开后勾选“趋势交易”，点击“指标明细”查看设置、当前判定和规则书页。旧“波浪”工具仍为独立工具。

- [指标规则、原书页码与程序参数](指标规则说明.md)
- [修复及使用说明](修复说明.md)
- [验证记录](验证记录.md)

63项回归测试在pandas 2和pandas 3下均通过，原自检及真实主窗口验证通过。复杂结构保留候选与确认时间，未收盘末K只作预览。

电子书来源：[book Release](https://github.com/hzm1978/hzm/releases/tag/book)。
