DML v53 — English submission convenience copies

These files have not been submitted to a journal. The cover letter is a draft.

The full package contains the Chinese reading copies, editable sources, revision notes, and source-review record. Consult SOURCE_AUDIT_v53.md before submission. In particular, external full-text/source correspondence and novelty verification are not complete. Confirm author information and all factual declarations before sending.

Main manuscript: main_en_PRA_v53.pdf / .tex
Supplement: supplementary_material_en_v53.pdf / .tex
Computational files and saved results: reproducibility_archive_v53.zip
