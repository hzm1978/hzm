# DML v53 — 实质修订工作稿

题目：**量子虚数性测量的维数依赖极小极大敏感度**  
English: **Dimension-dependent minimax sensitivity for measuring quantum imaginarity**

优先阅读 `submission/main_zh_v53.pdf` 或 `submission/main_en_PRA_v53.pdf`。
原始 v52 上传包未被覆盖。

## 本轮改动

- 将定义和保证系数提前，精确全维主定理移至第 III 节；相干性转换移作第 VI 节应用。
- 增加测量范数、量子数据隐藏与 POVM 稀疏化背景，说明本文使用已有范数框架，不把一般框架作为新概念主张。
- 新增标准复 Haar 测量在相同纯虚 Hermitian 子空间上的解析基准：其保证值为最优值的 `(d−1)/d`。
- 五结果构造改用向外区间包络，保证值严格介于 `0.620509845202` 与 `0.620509845203`。
- 修正补充材料中的 POVM 假设、秩模式及“第一个不等式取等”的表述，修正中文半长度用语。

完整说明见 `修改说明_v53.md`；核验边界见 `SOURCE_AUDIT_v53.md`。

## 文件

- `submission/`：中英文主稿、补充材料的 PDF 与可编辑 TeX，以及投稿附信草稿。
- `PRA_upload/`：英文主稿、英文补充材料和复现归档的便利副本；这不是已经提交的记录。
- `code/`：原有数值复现、Haar 基准检查及区间认证程序。
- `results/`：新计算记录、区间证书与运行版本。
- `provenance/`：原 v52 的审查和 AI 使用记录，作为历史材料保存；不能当作本次新核验。
- `revision_changes_v53.diff`：四份 TeX 相对 v52 的修改。
- `validation_v53.json`：最终文档与引用、排版检查。
- `source_inventory_v53.csv`：参考文献清单及逐项核查范围。

## 复算

使用 Python 3.10+、NumPy、SciPy 和 mpmath。区间脚本使用的实现是 **mpmath 1.3.0**；当前精确版本另见 `code/requirements-tested.txt`。

```bash
python code/reproduce_paper_examples_v53.py
python code/verify_baselines_v53.py
python code/certify_five_outcome_v53.py
```

普通 60 位计算用于显示数值；区间程序单独用 80 位向外运算，并验证最终 12 位小数端点。
解析等距性不依赖“残差很小”的推断。Monte Carlo 不证明最坏情形定理。

## 编译

需要含 REVTeX 4.2、ctex/xeCJK、amsmath、amsthm、hyperref、listings、microtype 的 TeX Live/MiKTeX，以及 latexmk。
中文优先使用 Noto Serif CJK SC，也提供 Fandol 回退。

```bash
python build_manuscripts.py
python build_manuscripts.py --language en
python build_manuscripts.py --language zh
```

若依赖在单独的本地 TeX 树中，可使用 `--texmf-home /path/to/texmf-dist`。PDF 可直接阅读，无需编译环境。

## 投稿边界

这是已执行本地检查的修订工作稿。外部论文全文、引用元数据与创新优先权尚需作者核查；具体条目见来源记录。
没有代为确认作者的 ORCID、独占投稿、既往投稿史、资助等事实，也没有代为投稿或取得期刊认可。
现有事实性声明需作者审定。中文单位按英文的 Wuyi University 与 Jiangmen 修正为“五邑大学”，亦应由作者确认。

