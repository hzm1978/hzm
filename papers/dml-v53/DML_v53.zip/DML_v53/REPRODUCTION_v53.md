# DML v53 computational supplement

This archive accompanies *Dimension-dependent minimax sensitivity for measuring quantum imaginarity*. It contains the executed code and saved results for the v53 revision.

Tested environment: Python 3.12.14, NumPy 2.3.5, SciPy 1.17.0, and mpmath 1.3.0. Install the exact tested versions in a suitable virtual environment:

```bash
python -m pip install -r code/requirements-tested.txt
python code/reproduce_paper_examples_v53.py
python code/verify_baselines_v53.py
python code/certify_five_outcome_v53.py
```

The first script prints the original finite-dimensional examples, the continuous-frame Monte Carlo checks, and the five-outcome construction in ordinary 60-digit arithmetic. Its executed output is saved as `code/reproduce_output_v53.txt`.

The second script checks the added complex Haar baseline, gamma-function identity, and direct density-matrix probability interpretation. It writes `results/baseline_checks_v53.json`.

The third script uses `mpmath.iv` with 80 decimal digits and verifies outward decimal endpoints. It writes `results/five_outcome_interval_certificate_v53.json`. The certified five-outcome guarantee lies strictly between `0.620509845202` and `0.620509845203`, and exceeds the four-outcome optimum by more than `0.0081374`. The unique minimizing facet pair is `(2,3)`.

Exact POVM normalization is established analytically from the isometry and unitary factors. Small numerical residuals serve as consistency checks. Monte Carlo agreement does not prove the minimax theorem. The interval calculation certifies this construction within the documented numerical implementation; it does not establish global five-outcome optimality, all analytic statements, or literature priority.

The complete manuscript package includes the bilingual TeX/PDF documents, revision diff, source inventory, and a local validation report. Source correspondence and bibliographic metadata still require primary-source review, as recorded in `SOURCE_AUDIT_v53.md`.
