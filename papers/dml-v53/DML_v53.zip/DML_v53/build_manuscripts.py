#!/usr/bin/env python3
"""Compile the four v53 documents with latexmk and preserved exit status."""
from pathlib import Path
import argparse
import os
import subprocess

ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--language', choices=['en','zh','both'], default='both')
    parser.add_argument('--texmf-home', type=Path, help='Optional local TeX dependency tree')
    args = parser.parse_args()
    env = os.environ.copy()
    if args.texmf_home:
        env['TEXMFHOME'] = str(args.texmf_home.resolve())
    for lang in (['en','zh'] if args.language=='both' else [args.language]):
        engine = '-pdf' if lang=='en' else '-xelatex'
        stems = ['main_en_PRA_v53','supplementary_material_en_v53'] if lang=='en' else ['main_zh_v53','supplementary_material_zh_v53']
        for stem in stems:
            subprocess.run(['latexmk',engine,'-interaction=nonstopmode','-halt-on-error',stem+'.tex'],
                           cwd=ROOT/'submission',env=env,check=True)


if __name__=='__main__':
    main()
