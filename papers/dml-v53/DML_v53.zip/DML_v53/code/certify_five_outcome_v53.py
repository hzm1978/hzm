#!/usr/bin/env python3
"""Outward interval certificate for the exact five-outcome construction.

All construction inputs are integers, rational operations, square roots, and
trigonometric functions at rational multiples of the interval enclosure of pi.
No binary floating-point input is used in the certified calculation. mpmath.iv
evaluates outward intervals at 80 decimal digits. Coarse decimal endpoints are
verified again by interval comparison before they are written to the report.

The analytic identities Q0^dagger Q0=I and unitarity of the Givens factors prove
normalization exactly. The interval normalization checks are consistency checks;
the strict improvement is certified by positive lower bounds for all ten facet
distances and their separation from sqrt(3/8).
"""
from itertools import combinations
from pathlib import Path
import json
import mpmath as mp

iv = mp.iv
iv.dps = 80
mp.mp.dps = 110  # only used to propose readable endpoints; comparisons below certify them


def real(value=0):
    return iv.mpf(value)


def c(value=0):
    return (real(value), real(0))


def add(a, b):
    return (a[0]+b[0], a[1]+b[1])


def mul(a, b):
    return (a[0]*b[0]-a[1]*b[1], a[0]*b[1]+a[1]*b[0])


def conj(a):
    return (a[0], -a[1])


def scale(a, s):
    return (a[0]*s, a[1]*s)


def matmul(A, B):
    return [[sum_complex(mul(A[i][k], B[k][j]) for k in range(len(B)))
             for j in range(len(B[0]))] for i in range(len(A))]


def sum_complex(values):
    result = c()
    for value in values:
        result = add(result, value)
    return result


def givens(i, j, numerator, denominator, phase_numerator, phase_denominator=1):
    theta = iv.pi * numerator / denominator
    phi = iv.pi * phase_numerator / phase_denominator
    U = [[c(int(a == b)) for b in range(5)] for a in range(5)]
    cosine, sine = iv.cos(theta), iv.sin(theta)
    U[i][i] = U[j][j] = (cosine, real())
    U[i][j] = (iv.cos(phi)*sine, iv.sin(phi)*sine)
    U[j][i] = (-iv.cos(phi)*sine, iv.sin(phi)*sine)
    return U


def levi(a, b, c_):
    if len({a, b, c_}) < 3:
        return 0
    return -1 if (int(a>b)+int(a>c_)+int(b>c_)) % 2 else 1


def dot(a, b):
    return sum((x*y for x, y in zip(a, b)), real())


def cross(a, b):
    return [a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0]]


def contains(x, value):
    # Comparisons on interval endpoints, converted exactly from mpmath binary tuples.
    return mp.mpf(x._mpi_[0]) <= value <= mp.mpf(x._mpi_[1])


def bounds(x, places=12):
    multiplier = mp.mpf(10)**places
    lo = int(mp.floor(mp.mpf(x._mpi_[0])*multiplier))
    hi = int(mp.ceil(mp.mpf(x._mpi_[1])*multiplier))
    def decimal(integer):
        sign = '-' if integer < 0 else ''
        integer = abs(integer)
        return f'{sign}{integer//(10**places)}.{integer%(10**places):0{places}d}'
    lower, upper = decimal(lo), decimal(hi)
    assert real(lower) < x, (lower, x)
    assert x < real(upper), (x, upper)
    return {'lower': lower, 'upper': upper}


def main():
    r2, r3 = iv.sqrt(real(2)), iv.sqrt(real(3))
    one_plus = (real(1), r3)
    one_minus = (real(1), -r3)
    negative_plus = (real(-1), r3)
    Q0 = [
        [(1/(2*r2),real()), scale(one_plus,-1/(4*r2)), scale(one_minus,-1/(4*r2))],
        [(1/(2*r2),real()), scale(one_plus,-1/(4*r2)), scale(one_minus,-1/(4*r2))],
        [c(1/real(2)), scale(one_plus,1/real(4)), scale(one_minus,1/real(4))],
        [c(1/real(2)), scale(one_plus,1/real(4)), scale(negative_plus,1/real(4))],
        [c(-1/real(2)), scale(one_plus,1/real(4)), scale(negative_plus,1/real(4))],
    ]
    U = matmul(matmul(matmul(givens(2,3,1,41,1,2), givens(3,0,1,66,1)),
                         givens(1,2,-1,44,0)), givens(1,4,-1,29,3,2))
    Q = matmul(U, Q0)
    for i in range(3):
        for j in range(3):
            value = sum_complex(mul(conj(Q[k][i]), Q[k][j]) for k in range(5))
            assert contains(value[0], int(i == j))
            assert contains(value[1], 0)
    generators = []
    for k in range(5):
        E = [[mul(conj(Q[k][i]), Q[k][j]) for j in range(3)] for i in range(3)]
        b = []
        for a in range(3):
            trace = sum_complex(mul(E[i][j], (real(), real(-levi(a,j,i))))
                                for i in range(3) for j in range(3))
            assert contains(trace[1], 0)
            b.append(trace[0])
        generators.append(b)
    for a in range(3):
        assert contains(sum((generators[k][a] for k in range(5)), real()), 0)

    reference = iv.sqrt(real(3)/8)
    values = {}
    records = []
    for i, j in combinations(range(5), 2):
        n = cross(generators[i], generators[j])
        norm2 = dot(n, n)
        assert norm2 > real(0), 'A facet cross product could be zero'
        length = iv.sqrt(norm2)
        n = [x/length for x in n]
        value = sum((abs(dot(b, n)) for b in generators), real())/2
        assert value > reference, 'Strict improvement is not certified'
        values[(i+1,j+1)] = value
        records.append({'pair':[i+1,j+1],**bounds(value)})
    minimum_pair = (2,3)
    minimum = values[minimum_pair]
    for pair, value in values.items():
        if pair != minimum_pair:
            assert minimum < value, 'Minimizing facet could not be separated'
    assert minimum > real('0.620509845202')
    assert minimum < real('0.620509845203')
    assert minimum-reference > real('0.0081374')
    report = {
        'status':'CERTIFIED_BY_OUTWARD_INTERVAL_ARITHMETIC',
        'library':'mpmath.iv', 'library_version':mp.__version__, 'decimal_precision':iv.dps,
        'all_ten_cross_products_nonzero':True, 'all_facets_above_four_outcome_optimum':True,
        'unique_minimizing_pair':list(minimum_pair), 'minimum_enclosure':bounds(minimum),
        'four_outcome_optimum_enclosure':bounds(reference), 'strict_margin_lower_bound':'0.0081374',
        'facets':records,
        'scope':'This certifies the specified construction and comparisons within the interval implementation; it does not certify global five-outcome optimality or all analytic theorems.'
    }
    out = Path(__file__).resolve().parents[1]/'results'
    out.mkdir(exist_ok=True)
    (out/'five_outcome_interval_certificate_v53.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))


if __name__ == '__main__':
    main()
