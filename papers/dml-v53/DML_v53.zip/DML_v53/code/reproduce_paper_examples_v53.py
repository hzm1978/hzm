#!/usr/bin/env python3
"""Reproduce numerical values for the finite-dimensional examples in the paper.

Dependencies: Python 3, NumPy, SciPy, and mpmath.
The Monte Carlo and polyhedral checks use double precision. The explicit
five-outcome qutrit construction and its facet values are evaluated with
60-digit arithmetic. The analytic theorems are proved in the main article.
"""
from itertools import product, combinations
from math import pi, sqrt
import numpy as np
from scipy.special import gammaln
import mpmath as mp

PHI=(1+sqrt(5))/2

def c_n(n):
    return float(np.exp(gammaln(n/2)-0.5*np.log(np.pi)-gammaln((n+1)/2)))

def facet_values(B):
    vals=[]
    for i,j in combinations(range(len(B)),2):
        n=np.cross(B[i],B[j]); nn=np.linalg.norm(n)
        if nn<1e-12: continue
        n/=nn
        vals.append((i+1,j+1,0.5*np.sum(np.abs(B@n))))
    return sorted(vals,key=lambda x:x[2])

def tetrahedron():
    N=np.array([[1,1,1],[1,-1,-1],[-1,1,-1],[-1,-1,1]],float)/sqrt(3)
    B=0.75*N
    f=facet_values(B)
    peak=max(np.linalg.norm(np.sum(np.array(s)[:,None]*B,axis=0))
             for s in product([-1,1],repeat=4))/2
    return f,peak

def icosahedron():
    raw=[]
    for a,b in product([-1,1],repeat=2):
        raw.extend([[0,a,b*PHI],[a,b*PHI,0],[a*PHI,0,b]])
    N=np.asarray(raw,float); N/=np.linalg.norm(N,axis=1)[:,None]
    B=0.25*N
    f=facet_values(B)
    peak=max(np.linalg.norm(np.sum(np.array(s)[:,None]*B,axis=0))
             for s in product([-1,1],repeat=12))/2
    return f,peak

def dodecahedron():
    raw=[]
    for a,b,c in product([-1,1],repeat=3): raw.append([a,b,c])
    for a,b in product([-1,1],repeat=2):
        raw.extend([[0,a/PHI,b*PHI],[a/PHI,b*PHI,0],[a*PHI,0,b/PHI]])
    N=np.asarray(raw,float)/sqrt(3); N/=np.linalg.norm(N,axis=1)[:,None]
    axes=[]
    for n in N:
        if not any(np.allclose(n,u,atol=1e-12) or np.allclose(n,-u,atol=1e-12) for u in axes):
            axes.append(n)
    # Each antipodal pair contributes twice the same absolute response.
    B=(3/10)*np.asarray(axes)
    f=facet_values(B)
    classes=[]
    for _,_,v in f:
        for g in classes:
            if abs(v-g[0])<1e-9:
                g[1]+=1; break
        else: classes.append([v,1])
    return f,classes

def levi_civita3(a,b,c):
    if len({a,b,c}) < 3:
        return 0
    inv = int(a>b) + int(a>c) + int(b>c)
    return -1 if inv % 2 else 1

def Gij_mp(i,j,theta,phi,n=5):
    U = mp.eye(n)
    U[i,i] = U[j,j] = mp.cos(theta)
    U[i,j] = mp.e**(1j*phi)*mp.sin(theta)
    U[j,i] = -mp.e**(-1j*phi)*mp.sin(theta)
    return U

def cross_mp(a,b):
    return [a[1]*b[2]-a[2]*b[1],
            a[2]*b[0]-a[0]*b[2],
            a[0]*b[1]-a[1]*b[0]]

def dot_mp(a,b):
    return sum(x*y for x,y in zip(a,b))

def norm_mp(a):
    return mp.sqrt(dot_mp(a,a))

def exact_five_outcome_mp(dps=60):
    """Evaluate the exact trigonometric construction using mp arithmetic."""
    mp.mp.dps = dps
    r2, r3 = mp.sqrt(2), mp.sqrt(3)
    Q0 = mp.matrix([
        [1/(2*r2), -(1+1j*r3)/(4*r2), -(1-1j*r3)/(4*r2)],
        [1/(2*r2), -(1+1j*r3)/(4*r2), -(1-1j*r3)/(4*r2)],
        [mp.mpf(1)/2, (1+1j*r3)/4, (1-1j*r3)/4],
        [mp.mpf(1)/2, (1+1j*r3)/4, (-1+1j*r3)/4],
        [-mp.mpf(1)/2, (1+1j*r3)/4, (-1+1j*r3)/4],
    ])
    U = (Gij_mp(2,3,mp.pi/41,mp.pi/2)
         *Gij_mp(3,0,mp.pi/66,mp.pi)
         *Gij_mp(1,2,-mp.pi/44,0)
         *Gij_mp(1,4,-mp.pi/29,3*mp.pi/2))
    Q = U*Q0

    J = []
    for a in range(3):
        Ja = mp.matrix(3,3)
        for m in range(3):
            for n in range(3):
                Ja[m,n] = -1j*levi_civita3(a,m,n)
        J.append(Ja)

    B = []
    for k in range(5):
        q = [Q[k,j] for j in range(3)]
        E = mp.matrix(3,3)
        for m in range(3):
            for n in range(3):
                E[m,n] = mp.conj(q[m])*q[n]
        B.append([mp.re(sum((E*J[a])[i,i] for i in range(3)))
                  for a in range(3)])

    facets = []
    for i,j in combinations(range(5),2):
        nvec = cross_mp(B[i],B[j])
        nn = norm_mp(nvec)
        if nn == 0:
            continue
        nvec = [x/nn for x in nvec]
        value = mp.mpf('0.5')*sum(abs(dot_mp(nvec,b)) for b in B)
        facets.append((i+1,j+1,value))
    facets.sort(key=lambda item:item[2])

    iso_res = Q.transpose_conj()*Q-mp.eye(3)
    iso_res_max = max(abs(iso_res[i,j]) for i in range(3) for j in range(3))
    closure = [sum(B[k][a] for k in range(5)) for a in range(3)]
    closure_max = max(abs(x) for x in closure)
    return Q, B, facets, iso_res_max, closure_max

def mc_frame_check(d,samples=200000,seed=20261031):
    rng=np.random.default_rng(seed+d); r=d//2
    A=np.zeros((d,d))
    for j in range(r):
        A[2*j,2*j+1]=-1; A[2*j+1,2*j]=1
    u=rng.normal(size=(samples,d)); u/=np.linalg.norm(u,axis=1)[:,None]
    v=rng.normal(size=(samples,d)); v-=np.sum(v*u,axis=1)[:,None]*u
    v/=np.linalg.norm(v,axis=1)[:,None]
    z=np.abs(np.einsum("bi,ij,bj->b",u,A,v))
    est=d*z.mean()/(2*r); se=d*z.std(ddof=1)/(2*r*np.sqrt(samples))
    exact=c_n(d-1) if d%2==0 else d*c_n(d)/(d-1)
    return est,se,exact

def main():
    print("Exact continuous minimax constants")
    for d in range(2,9):
        v=c_n(d-1) if d%2==0 else d*c_n(d)/(d-1)
        print(f"d={d}: {v:.12f}")
    print("\nContinuous-frame Monte Carlo check: 200000 samples per dimension")
    for d in range(2,9):
        est,se,exact=mc_frame_check(d)
        if se<1e-12:
            print(f"d={d}: {est:.8f} (deterministic), exact={exact:.8f}")
        else:
            print(f"d={d}: estimate={est:.8f}, SE={se:.2e}, exact={exact:.8f}, z={(est-exact)/se:.2f}")
    print("\nTetrahedron: min",tetrahedron()[0][0][2],"max",tetrahedron()[1])
    print("Expected tetrahedron: min",sqrt(3/8),"max",sqrt(3)/2)
    fi,mi=icosahedron()
    print("\nIcosahedron: min",fi[0][2],"max",mi)
    print("Expected icosahedron: min",sqrt((5+2*sqrt(5))/20),"max",PHI/2)
    fd,cd=dodecahedron()
    print("\nDodecahedron: min",fd[0][2],"facet classes",cd)
    print("Expected dodecahedron minimum",3*(5+3*sqrt(5))/(20*sqrt(6)))
    Q,B,f,iso_res,closure_res=exact_five_outcome_mp(dps=60)
    print("\nExact five-outcome construction (60-digit arithmetic)")
    print("maximum isometry residual",mp.nstr(iso_res,8))
    print("maximum closure residual",mp.nstr(closure_res,8))
    print("guaranteed sensitivity",mp.nstr(f[0][2],30))
    print("all ten facet values")
    for i,j,v in f: print(f"({i},{j}) {mp.nstr(v,30)}")
    print("\nMonte Carlo and polyhedral checks use double precision; the five-outcome construction is evaluated at 60-digit precision.")

if __name__=="__main__": main()
