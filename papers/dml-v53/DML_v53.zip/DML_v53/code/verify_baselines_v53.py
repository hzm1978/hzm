#!/usr/bin/env python3
"""Check the new Haar benchmark and the direct probability interpretation.

The Monte Carlo checks do not prove a worst-case theorem. The gamma identity
and finite-matrix calculations check independent formulations of the examples.
"""
from pathlib import Path
from itertools import combinations
import json
import numpy as np
from scipy.special import gammaln
from reproduce_paper_examples_v53 import c_n, exact_five_outcome_mp, levi_civita3


def main():
    rng = np.random.default_rng(20261103)
    maximum_identity_error = 0.0
    for d in range(2,65):
        r = d//2
        haar = float(np.exp(gammaln(r+.5)-.5*np.log(np.pi)-gammaln(r+1)))
        optimal = c_n(d-1) if d%2==0 else d*c_n(d)/(d-1)
        maximum_identity_error = max(maximum_identity_error,abs(haar-(d-1)*optimal/d))
    assert maximum_identity_error < 1e-12

    rows = []
    samples = 200000
    for d in [2,3,4,5,6,8,10]:
        r = d//2
        # Squared complex Haar coordinates have the Dirichlet(1,...,1) law.
        weights = rng.exponential(size=(samples,d))
        weights /= weights.sum(axis=1)[:,None]
        values = d*np.abs(weights[:,:r].sum(axis=1)-weights[:,r:2*r].sum(axis=1))/(2*r)
        expected = float(np.exp(gammaln(r+.5)-.5*np.log(np.pi)-gammaln(r+1)))
        estimate = float(values.mean())
        se = float(values.std(ddof=1)/np.sqrt(samples))
        assert abs(estimate-expected) < 6*se
        rows.append({'d':d,'samples':samples,'haar_expected':expected,'haar_MC':estimate,
                     'standard_error':se,'z_score':(estimate-expected)/se,'optimal_relative_gain':d/(d-1)})

    Qmp,_,_,_,_ = exact_five_outcome_mp(dps=60)
    Q = np.array([[complex(Qmp[i,j]) for j in range(3)] for i in range(5)])
    effects = np.array([np.outer(q.conj(),q) for q in Q])
    generators = np.zeros((3,3,3),dtype=complex)
    for a in range(3):
        for i in range(3):
            for j in range(3):
                generators[a,i,j] = -1j*levi_civita3(a,i,j)
    B = np.real(np.einsum('kij,aji->ka',effects,generators))
    errors = []
    measured_ratios = []
    for i,j in combinations(range(5),2):
        a = np.cross(B[i],B[j]); a /= np.linalg.norm(a)
        X = np.einsum('a,aij->ij',a,generators)
        rho = np.eye(3)/3+.1*X
        assert np.linalg.eigvalsh(rho).min() > 0
        p = np.einsum('kij,ji->k',effects,rho).real
        pc = np.einsum('kij,ji->k',effects,rho.conj()).real
        assert np.allclose(p.sum(),1) and np.allclose(pc.sum(),1)
        imag = np.linalg.norm(rho-rho.conj(),ord='nuc')/2
        ratio = .5*np.abs(p-pc).sum()/imag
        facet = .5*np.abs(B@a).sum()
        errors.append(abs(ratio-facet)); measured_ratios.append(float(ratio))
    assert max(errors) < 1e-12
    report = {'status':'PASS', 'maximum_gamma_identity_error_d2_to_d64':maximum_identity_error,
              'haar_monte_carlo':rows,'direct_five_outcome_probabilities':{
                  'facet_directions':10,'maximum_probability_vs_facet_error':float(max(errors)),
                  'minimum_ratio':min(measured_ratios),'completeness_error':float(np.max(abs(effects.sum(axis=0)-np.eye(3))))},
              'scope':'Numerical checks of stated formulas; not a literature audit or proof of every theorem.'}
    out = Path(__file__).resolve().parents[1]/'results'
    out.mkdir(exist_ok=True)
    (out/'baseline_checks_v53.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))


if __name__=='__main__':
    main()
