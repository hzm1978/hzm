# AI-use record for APS disclosure — DML v52

## Tool
- ChatGPT, model GPT-6 (OpenAI).

## Substantive assistance used
- Literature discovery and organization for the background and closest-work comparison.
- Exploratory mathematical reasoning and checking of intermediate derivations.
- Drafting and debugging the numerical reproduction script.
- Numerical consistency checks, including 60-digit evaluation of the five-outcome qutrit construction.
- Language editing and restructuring of the English and Chinese manuscripts.

## How the tool was directed
The author supplied the manuscript, specified the research question and target journal, and gave explicit requirements for checking assumptions, derivations, limiting cases, references, numerical results, and manuscript structure. The tool was instructed to distinguish exact analytic results from numerical evidence and not to claim global five-outcome optimality.

## Verification performed in this review
- The reproduction script was executed.
- The five-outcome isometry and closure residuals were computed with 60-digit arithmetic.
- The polyhedral qutrit checks and continuous-frame Monte Carlo checks were rerun.
- Bibliographic metadata were cross-checked against publisher records and accessible abstracts.
- The mathematical proofs were checked for internal consistency and key normalization factors.

## Author confirmation still required
Before submission, the author must independently rederive and verify the final mathematical arguments, confirm all source-paper interpretations and references, and ensure the disclosure accurately reflects the actual use of AI. The author remains responsible for all claims and the submitted manuscript.
