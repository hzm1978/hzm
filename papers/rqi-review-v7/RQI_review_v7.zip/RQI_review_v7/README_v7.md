# RQI 综述修订稿 v7

题目：**量子场的局域探测：因果测量与可靠的量子资源提取**  
English: **Local quantum-field probes: causal measurements and reliable resource harvesting**

优先阅读 `rqi_review_zh_v7.pdf` 或 `rqi_review_en_v7.pdf`。
这是实质修订工作稿，不是已完成全部原始文献审计的投稿终稿。

## 文件

- `rqi_review_en_v7.pdf` / `rqi_review_zh_v7.pdf`：英文主稿、中文对应阅读稿。
- `rqi_supplement_en_v7.pdf` / `rqi_supplement_zh_v7.pdf`：对应补充材料，S1–S11。
- 四个同名 `.tex`：可编辑源文件；共享 `rqi_refs.bib` 和 `rqi_unsrtnat.bst`。
- `修改说明_v7.md`：实质改动及补充材料编号映射。
- `SOURCE_AUDIT_v7.md` / `source_inventory_v7.csv`：本次验证边界和来源检查状态。
- `validation_v7.json`：最终 PDF、引用、交叉引用和排版检查。
- `results/`：原始例子数据及本次复算结果。
- `provenance/source_inventory_v6.csv`：保留的 v6 来源清单；不能视为 v7 新的外部文献核验。

原始上传 ZIP 保留在原位置，未被覆盖；v7 的文字删改可在 `revision_changes_v7.diff` 中检查。

## 复算

需要 Python 3.10+、NumPy、SciPy、pandas；原径向/绘图程序还使用 matplotlib。
当前验证所用版本记录于 `results/runtime_versions_v7.json`。

```bash
python verify_v7_core.py
python verify_s5_s6_benchmarks.py
python reproduce_s6_fourier.py
python schwarzschild_massive_scalar_asymptotic_check_v1.py
```

`verify_v7_core.py` 检查三／四比特双可分反例、三类簇态局域信道、显式一阶 W/Dicke 模型、电磁角积分、复模因子的占据数抵消及热模型精度最优点。

这些检查不验证全部文献、不提供高阶余项控制，也不等于完整 de Sitter 或径向散射独立复现。S7 的 ansatz 代入结果不是严格互信息上界。

## 编译

使用含 XeLaTeX、latexmk、BibTeX、ctex/xeCJK、natbib、xr-hyper 和 xurl 的 TeX Live/MiKTeX。
中文优先使用 Noto Serif CJK SC，否则使用 Fandol 字体。

```bash
python build_manuscripts.py
# 或单独编译一种语言
python build_manuscripts.py --language en
python build_manuscripts.py --language zh
```

脚本先编译主稿，再生成仅含标签的辅助文件，最后编译补充材料；主稿与补充材料的文献编号独立。
无需联网即可阅读 PDF。编译源文件时需在自己的 TeX 环境中安装上述依赖。

## 投稿前仍需作者处理

首先核对 `SOURCE_AUDIT_v7.md` 中的关键原文公式和来源对应关系；确认署名、单位与事实性声明。
本文定位为聚焦的批判性叙述综述，未声称系统检索覆盖，也未获得期刊邀约。
目标刊的文章类型、篇幅、当前 SCIE 状态和辅助工具披露要求需另行核实。

本次使用 ChatGPT 辅助结构重写、双语文字修改及验证代码编写。作者应按实际核验情况和目标刊政策如实处理披露及责任声明。

