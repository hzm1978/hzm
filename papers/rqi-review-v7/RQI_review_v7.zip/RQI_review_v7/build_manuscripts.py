#!/usr/bin/env python3
"""Compile main manuscripts first, then supplements with clean external labels."""
from pathlib import Path
import argparse
import subprocess

ROOT = Path(__file__).resolve().parent


def build(stem):
    subprocess.run(['latexmk', '-xelatex', '-interaction=nonstopmode',
                    '-halt-on-error', stem + '.tex'], cwd=ROOT, check=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--language', choices=['en', 'zh', 'both'], default='both')
    args = parser.parse_args()
    languages = ['en', 'zh'] if args.language == 'both' else [args.language]
    for lang in languages:
        stem = f'rqi_review_{lang}_v7'
        build(stem)
        lines = (ROOT / (stem + '.aux')).read_text().splitlines()
        # Import equation/section labels, not the main paper's bibliography.
        labels = [line for line in lines if line.startswith('\\newlabel')]
        (ROOT / (stem + '_labels.aux')).write_text('\n'.join(labels) + '\n')
        build(f'rqi_supplement_{lang}_v7')


if __name__ == '__main__':
    main()
