#!/usr/bin/env python3
"""Check the large-radius asymptotics used in Supplementary Sec. S12.

This is an asymptotic-potential diagnostic, not a radial scattering solver and
not a detector-harvesting calculation. It verifies the Coulomb 1/y tail and the
leading phase/log-derivative forms in dimensionless Schwarzschild variables.

Units: r_h = 2 M = 1, x = r/r_h, y = r_*/r_h = x + log(x-1),
mu = m r_h, eps = omega r_h.
"""
from __future__ import annotations
import csv
from pathlib import Path
import math

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "results"
OUT.mkdir(exist_ok=True)


def tortoise_y(x: float) -> float:
    if x <= 1.0:
        raise ValueError("x must be outside the horizon (x>1)")
    return x + math.log(x - 1.0)


def potential(x: float, mu: float, ell: int) -> float:
    f = 1.0 - 1.0 / x
    return f * (mu * mu + ell * (ell + 1) / (x * x) + 1.0 / (x**3))


def rows_for_tail(mu: float = 0.7, ell: int = 2):
    rows = []
    for x in (10.0, 30.0, 100.0, 300.0, 1.0e3, 3.0e3, 1.0e4, 3.0e4):
        y = tortoise_y(x)
        U = potential(x, mu, ell)
        tail_est = y * (mu * mu - U)
        remainder = (y * y / math.log(y)) * (U - (mu * mu - mu * mu / y))
        rows.append({
            "x": x, "y": y, "U": U,
            "y_times_mu2_minus_U": tail_est,
            "target_mu2": mu * mu,
            "scaled_remainder": remainder,
        })
    return rows


def phase_checks(mu: float = 0.7, ell: int = 2):
    # Above threshold: p(y) = sqrt(k^2 + mu^2/y + O(log(y)/y^2))
    eps_above = 1.15 * mu
    k = math.sqrt(eps_above**2 - mu**2)
    eta = mu**2 / (2.0 * k)
    # Below threshold: q(y) = sqrt(kappa^2 - mu^2/y + ...)
    eps_below = 0.75 * mu
    kap = math.sqrt(mu**2 - eps_below**2)
    lam = mu**2 / (2.0 * kap)
    # Threshold WKB momentum p ~ mu/sqrt(y).
    result = []
    for x in (100.0, 300.0, 1.0e3, 3.0e3, 1.0e4, 3.0e4):
        y = tortoise_y(x)
        U = potential(x, mu, ell)
        p_above = math.sqrt(max(eps_above**2 - U, 0.0))
        p_above_asym = k + eta / y
        q_below = math.sqrt(max(U - eps_below**2, 0.0))
        q_below_asym = kap - lam / y
        p_thr = math.sqrt(max(mu * mu - U, 0.0))
        p_thr_asym = mu / math.sqrt(y)
        result.append({
            "x": x, "y": y,
            "above_phase_derivative": p_above,
            "above_coulomb_asymptotic": p_above_asym,
            "above_scaled_error": (p_above-p_above_asym)*y*y/math.log(y),
            "below_decay_log_derivative_magnitude": q_below,
            "below_whittaker_asymptotic": q_below_asym,
            "below_scaled_error": (q_below-q_below_asym)*y*y/math.log(y),
            "threshold_wkb_momentum": p_thr,
            "threshold_wkb_asymptotic": p_thr_asym,
            "threshold_ratio": p_thr/p_thr_asym,
        })
    return result


def write_csv(path: Path, rows):
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main():
    tail = rows_for_tail()
    checks = phase_checks()
    write_csv(OUT / "schwarzschild_massive_scalar_tail_check_v1.csv", tail)
    write_csv(OUT / "schwarzschild_massive_scalar_phase_check_v1.csv", checks)

    print("Large-radius Coulomb-tail check")
    print("x       y*(mu^2-U)       mu^2")
    for row in tail:
        print(f"{row['x']:7.0f} {row['y_times_mu2_minus_U']:16.10f} {row['target_mu2']:10.6f}")
    print("\nLeading phase/WKB checks")
    print("x       above ratio-error      below scaled error    threshold ratio")
    for row in checks:
        print(f"{row['x']:7.0f} {row['above_scaled_error']:18.9f}"
              f" {row['below_scaled_error']:20.9f} {row['threshold_ratio']:17.10f}")
    print("\nScope: asymptotic expansion only; no normalized scattering modes or detector rates are computed.")


if __name__ == "__main__":
    main()
