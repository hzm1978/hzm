#!/usr/bin/env python3
"""Refined real-frequency local-response scan for a massive Schwarzschild scalar.

This is a stationary single-detector calculation only.  It does not compute a
complex quasi-bound pole, two-detector cross correlator, or harvesting negativity.
The massive sub-threshold up channel is normalized to unit incoming horizon
amplitude and matched to the full-potential leading-WKB decaying branch at large radius.
"""
from __future__ import annotations
import csv, math
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import brentq, minimize_scalar
from scipy.integrate import quad
from schwarzschild_massive_scalar_radial_modes_v1_1 import integrate_mode

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "results"; OUT.mkdir(exist_ok=True)
FIG = ROOT / "figures"; FIG.mkdir(exist_ok=True)
M = 1.0
mM = 0.1435
mu = 2.0*mM
x0 = 2.0
r0 = 4.0*M
y0 = x0 + math.log(x0-1.0)
f0 = 1.0 - 1.0/x0


def potential(x: float, ell: int = 0) -> float:
    f = 1.0 - 1.0/x
    return f*(mu*mu + ell*(ell+1.0)/(x*x) + 1.0/(x**3))


def rate(omegaM: float, mu_value: float, ell: int = 0,
         y_max: float = 1800.0, rtol: float = 2e-10,
         atol: float = 2e-12) -> float:
    eps = 2.0*omegaM
    mode = integrate_mode(eps, mu_value, ell, "up", y_max=y_max,
                          y_eval=y0, rtol=rtol, atol=atol)
    nH = 1.0/math.expm1(8.0*math.pi*omegaM)
    rho = abs(mode["u"])**2/(4.0*math.pi*omegaM*r0*r0)
    # M dot{F}(+Omega), with Omega M = omegaM/sqrt(f0).
    return (2*ell+1)*0.5*math.sqrt(f0)*rho*nH


def roots_for(omegaM: float):
    eps = 2.0*omegaM
    grid = np.geomspace(1.000001, 1.0e5, 40000)
    vals = np.array([potential(x)-eps*eps for x in grid])
    roots=[]
    for a,b,fa,fb in zip(grid[:-1],grid[1:],vals[:-1],vals[1:]):
        if fa*fb < 0:
            roots.append(brentq(lambda z: potential(z)-eps*eps,a,b,xtol=1e-13))
    return roots


def main():
    # Fine scan resolves the local maximum missed by the coarser v1 grid.
    scan = np.linspace(0.14150, 0.14182, 21)
    scan_rows=[]
    for om in scan:
        massive = rate(om, mu, ell=0, y_max=900.0)
        massless = rate(om, 0.0, ell=0, y_max=600.0)
        scan_rows.append({
            "omegaM_Killing": om,
            "OmegaM_proper": om/math.sqrt(f0),
            "mM": mM,
            "massive_M_rate_l0": massive,
            "massless_M_rate_l0": massless,
            "ratio_massive_to_massless_l0": massive/massless,
        })
    scan_path=OUT/"schwarzschild_massive_scalar_detector_resonance_scan_v2.csv"
    with scan_path.open("w",newline="",encoding="utf-8") as f:
        w=csv.DictWriter(f,fieldnames=list(scan_rows[0])); w.writeheader(); w.writerows(scan_rows)

    opt=minimize_scalar(lambda z:-rate(z,mu,0,900.0,1e-10,1e-12),
                        bounds=(0.14150,0.14182),method="bounded",
                        options={"xatol":1e-12})
    peak_om=float(opt.x); peak_rate=float(-opt.fun)
    massless_peak=rate(peak_om,0.0,0,600.0,1e-10,1e-12)

    # Numerical stability at the optimized peak.
    checks=[]
    for ymax in (600.0,900.0,1500.0,2500.0):
        v=rate(peak_om,mu,0,ymax,1e-11,1e-13)
        checks.append({"check":"outer_boundary", "setting":ymax,
                       "M_rate":v,"relative_to_reference":v/peak_rate-1.0})
    for tol in (1e-8,1e-10,1e-12):
        v=rate(peak_om,mu,0,900.0,tol,tol*1e-2)
        checks.append({"check":"ODE_tolerance", "setting":tol,
                       "M_rate":v,"relative_to_reference":v/peak_rate-1.0})
    for ell in range(0,5):
        v=rate(peak_om,mu,ell,900.0)
        checks.append({"check":f"angular_ell_{ell}", "setting":ell,
                       "M_rate":v,"relative_to_reference":v/peak_rate-1.0})
    check_path=OUT/"schwarzschild_massive_scalar_detector_resonance_convergence_v2.csv"
    with check_path.open("w",newline="",encoding="utf-8") as f:
        w=csv.DictWriter(f,fieldnames=list(checks[0])); w.writeheader(); w.writerows(checks)

    turning=roots_for(peak_om)
    action=None
    if len(turning)==3:
        eps=2.0*peak_om
        action=quad(lambda x:math.sqrt(max(eps*eps-potential(x),0.0))/(1.0-1.0/x),
                    turning[1],turning[2],epsabs=1e-11,epsrel=1e-11,limit=500)[0]

    fig,axs=plt.subplots(1,2,figsize=(12.5,4.8))
    xvals=np.geomspace(1.001,100.0,1800)
    axs[0].plot(xvals,[potential(x) for x in xvals],label=r"$U_0(x)$")
    axs[0].axhline((2*peak_om)**2,linestyle="--",label=r"$\epsilon^2$")
    axs[0].axvline(x0,linestyle=":",label=r"detector $x_0=2$")
    for i,rt in enumerate(turning):
        axs[0].axvline(rt,linestyle="-.",alpha=.75,label=f"turning point {i+1}")
    axs[0].set_xscale("log"); axs[0].set_xlabel(r"$x=r/(2M)$")
    axs[0].set_ylabel(r"$U_0(x)$"); axs[0].set_title("Massive s-wave effective potential")
    axs[0].legend(fontsize=8); axs[0].grid(True,alpha=.25)
    xs=np.array([r["OmegaM_proper"] for r in scan_rows])
    ym=np.array([r["massive_M_rate_l0"] for r in scan_rows])
    y0v=np.array([r["massless_M_rate_l0"] for r in scan_rows])
    axs[1].plot(xs,ym,label=rf"massive $mM={mM}$")
    axs[1].plot(xs,y0v,label="massless")
    axs[1].axvline(peak_om/math.sqrt(f0),linestyle=":",label="massive local maximum")
    axs[1].set_xlabel(r"proper detector gap $\Omega M$")
    axs[1].set_ylabel(r"$M\,\dot{\mathcal{F}}_{U}(+\Omega)$")
    axs[1].set_title("Static Unruh-state excitation (s wave)")
    axs[1].legend(fontsize=8); axs[1].grid(True,alpha=.25)
    fig.tight_layout()
    fig.savefig(FIG/"fig_s12_massive_scalar_local_resonance_v2.pdf",bbox_inches="tight")
    fig.savefig(FIG/"fig_s12_massive_scalar_local_resonance_v2.png",dpi=240,bbox_inches="tight")
    plt.close(fig)

    print(f"peak omegaM_Killing={peak_om:.12f}")
    print(f"peak OmegaM_proper={peak_om/math.sqrt(f0):.12f}")
    print(f"massive M rate (l=0)={peak_rate:.12e}")
    print(f"massless M rate (l=0, matched proper gap)={massless_peak:.12e}")
    print(f"massive/massless ratio={peak_rate/massless_peak:.8f}")
    print("turning points x=",turning)
    if action is not None: print(f"outer-well WKB action S/pi={action/math.pi:.9f} (diagnostic only)")
    print("scope: local real-frequency response peak only; no complex pole or harvesting negativity")
    print("wrote",scan_path,check_path)

if __name__=="__main__": main()
