#!/usr/bin/env python3
"""Numerical radial-mode benchmark for a massive scalar outside Schwarzschild.

This is a first local-response benchmark for Supplementary Sec. S12. It solves
only the stationary radial ODE and computes the Unruh-state single-detector
excitation rate at one static detector. It does NOT compute two-detector
harvesting or a massive-vs-massless negativity.

Conventions:
  r_h = 2 M, x = r/r_h, y = r_*/r_h = x + log(x-1)
  mu = m r_h, eps = omega r_h
  U_l(x) = (1-1/x) [mu^2 + l(l+1)/x^2 + 1/x^3]
  u''(y) + [eps^2-U_l(x(y))] u(y) = 0

The in mode is normalized to unit incoming Coulomb-wave amplitude at infinity;
the up mode is normalized to unit incoming amplitude at the horizon. The
frequency-normalized KG factors are sqrt(omega/k_inf) for in and 1 for up.
"""
from __future__ import annotations
import csv
import math
from pathlib import Path
import numpy as np
from scipy.integrate import solve_ivp

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "results"
OUT.mkdir(exist_ok=True)


def x_of_y(y: float) -> float:
    """Invert y=x+log(x-1) robustly without overflow."""
    a = y - 1.0
    if a < -30.0:
        z = math.exp(a)
        # W(e^a) = e^a - e^(2a) + O(e^(3a))
        z -= z * z
        return 1.0 + z
    if a <= 1.0:
        z = math.exp(a)
    else:
        z = a - math.log(a) + math.log(a) / a
    for _ in range(20):
        g = z + math.log(z) - a
        dz = g / (1.0 + 1.0 / z)
        z -= dz
        if abs(dz) < 2e-14 * max(1.0, z):
            break
    return 1.0 + z


def potential_y(y: float, mu: float, ell: int) -> float:
    x = x_of_y(y)
    f = 1.0 - 1.0 / x
    return f * (mu * mu + ell * (ell + 1.0) / (x * x) + 1.0 / (x**3))


def ode_rhs(y: float, z: np.ndarray, eps: float, mu: float, ell: int) -> np.ndarray:
    u, up = z
    return np.array([up, -(eps * eps - potential_y(y, mu, ell)) * u], dtype=complex)


def decompose_horizon(u: complex, up: complex, eps: float):
    # u = A exp(+i eps y) + B exp(-i eps y)
    s = up / (1j * eps)
    A = 0.5 * (u + s)
    B = 0.5 * (u - s)
    return A, B


def coulomb_boundary_data(k: float, eta: float, y: float):
    # Leading Coulomb WKB wave with unit asymptotic flux:
    # u ~ sqrt(k/p) exp(+- i theta), theta'=p=k+eta/y.
    p = k + eta / y
    amp = math.sqrt(k / p)
    dlogamp = eta / (2.0 * p * y * y)  # -p'/(2p)
    return p, amp, dlogamp


def decompose_infinity(u: complex, up: complex, k: float, eta: float, y: float):
    # u = A_in w_in + B_out w_out, with w_±=sqrt(k/p) exp(±i theta).
    p, amp, dlogamp = coulomb_boundary_data(k, eta, y)
    u_scaled = u / amp
    derivative_phase = (up - dlogamp * u) / (1j * p * amp)
    A_in = 0.5 * (u_scaled - derivative_phase)
    B_out = 0.5 * (u_scaled + derivative_phase)
    return A_in, B_out


def wkb_decaying_logderivative(y: float, mu: float, eps: float, ell: int) -> float:
    """Leading WKB logarithmic derivative using the full Schwarzschild potential.

    The large-y potential contains a Coulomb term -mu^2/y and a subleading
    coordinate-inversion correction -mu^2 log(y)/y^2, in addition to the
    angular term ell(ell+1)/y^2. A constant-index Whittaker function does not
    retain these terms consistently. We therefore impose the decaying WKB
    condition L=-q-q'/(2q), q=sqrt(U_ell-eps^2), using the full potential.
    """
    x = x_of_y(y)
    f = 1.0 - 1.0 / x
    L = ell * (ell + 1.0)
    U = f * (mu * mu + L / (x * x) + 1.0 / (x**3))
    dU_dx = (mu * mu + L / (x * x) + 1.0 / (x**3)) / (x * x)
    dU_dx += f * (-2.0 * L / (x**3) - 3.0 / (x**4))
    dU_dy = f * dU_dx
    q2 = U - eps * eps
    if q2 <= 0.0:
        raise ValueError("The outer boundary is not in the evanescent region.")
    q = math.sqrt(q2)
    return -q - dU_dy / (4.0 * q * q)


def integrate_mode(eps: float, mu: float, ell: int, kind: str,
                   y_min: float = -22.0, y_max: float = 600.0,
                   rtol: float = 2e-10, atol: float = 2e-12,
                   y_eval: float | None = None):
    """Return normalized radial mode at y_eval plus scattering diagnostics."""
    if kind not in ("in", "up"):
        raise ValueError("kind must be 'in' or 'up'")
    if kind == "in" and eps <= mu:
        raise ValueError("the in channel is closed for eps <= mu")
    k = math.sqrt(max(eps * eps - mu * mu, 0.0))
    eta = mu * mu / (2.0 * k) if k > 0 else math.inf

    if kind == "in":
        # Purely ingoing at the horizon; normalize the incoming component at infinity.
        z0 = np.array([np.exp(-1j * eps * y_min),
                       -1j * eps * np.exp(-1j * eps * y_min)], dtype=complex)
        sol = solve_ivp(ode_rhs, (y_min, y_max), z0, args=(eps, mu, ell),
                        method="DOP853", rtol=rtol, atol=atol,
                        dense_output=True, max_step=0.8)
        if not sol.success:
            raise RuntimeError(sol.message)
        u_inf, up_inf = sol.y[0, -1], sol.y[1, -1]
        A_in, B_out = decompose_infinity(u_inf, up_inf, k, eta, y_max)
        u_at = sol.sol(y_eval)[0] / A_in
        R = B_out / A_in
        T = 1.0 / A_in
        flux_residual = k * (1.0 - abs(R)**2) - eps * abs(T)**2
        return {
            "u": u_at, "R": R, "T": T,
            "flux_residual": float(flux_residual.real),
            "normalization_amplitude": A_in,
        }

    # up channel: outgoing at infinity above threshold; full-potential WKB decay at infinity below.
    if eps > mu:
        p_inf, amp_inf, dlogamp_inf = coulomb_boundary_data(k, eta, y_max)
        z0 = np.array([amp_inf + 0.0j,
                       (dlogamp_inf + 1j * p_inf) * amp_inf], dtype=complex)
    else:
        logder = wkb_decaying_logderivative(y_max, mu, eps, ell)
        z0 = np.array([1.0 + 0.0j, logder + 0.0j], dtype=complex)
    sol = solve_ivp(ode_rhs, (y_max, y_min), z0, args=(eps, mu, ell),
                    method="DOP853", rtol=rtol, atol=atol,
                    dense_output=True, max_step=0.8)
    if not sol.success:
        raise RuntimeError(sol.message)
    u_h, up_h = sol.y[0, -1], sol.y[1, -1]
    A_h, B_h = decompose_horizon(u_h, up_h, eps)
    u_at = sol.sol(y_eval)[0] / A_h
    R = B_h / A_h
    if eps > mu:
        T = 1.0 / A_h
        flux_residual = eps * (1.0 - abs(R)**2) - k * abs(T)**2
    else:
        T = complex(float("nan"), float("nan"))
        flux_residual = abs(R)**2 - 1.0
    return {
        "u": u_at, "R": R, "T": T,
        "flux_residual": float(np.real(flux_residual)),
        "normalization_amplitude": A_h,
    }


def run_benchmark():
    # Static detector at r0=4M, proper gap Omega*M=0.2.
    M = 1.0
    x0 = 2.0  # r0 = 4M = 2 r_h
    r0 = 2.0 * M * x0
    y0 = x0 + math.log(x0 - 1.0)
    f0 = 1.0 - 1.0 / x0
    OmegaM = 0.2
    Omega = OmegaM / M
    omega = Omega * math.sqrt(f0)
    eps = 2.0 * M * omega
    betaH = 8.0 * math.pi * M
    nH = 1.0 / math.expm1(betaH * omega)

    cases = [
        ("massless", 0.0),
        ("light_mass_above_threshold", 0.05),  # mM=0.05, eps > mu=0.10
        ("mass_above_threshold", 0.15),       # mM=0.15, eps < mu=0.30
    ]
    rows = []
    summaries = []
    l_sums = []
    for label, mM in cases:
        mu = 2.0 * M * (mM / M)
        unruh_sum = 0.0
        hh_exc_sum = 0.0
        hh_deexc_sum = 0.0
        for ell in range(0, 11):
            up = integrate_mode(eps, mu, ell, "up", y_eval=y0)
            rho_up = abs(up["u"])**2 / (4.0 * math.pi * omega * r0 * r0)
            rho_in = 0.0
            in_flux = ""
            in_abs_u = ""
            if eps > mu:
                inc = integrate_mode(eps, mu, ell, "in", y_eval=y0)
                k_phys = math.sqrt(eps * eps - mu * mu) / (2.0 * M)
                rho_in = abs(inc["u"])**2 / (4.0 * math.pi * k_phys * r0 * r0)
                in_flux = inc["flux_residual"]
                in_abs_u = abs(inc["u"])
            pref = 2.0 * math.pi * (2.0 * ell + 1.0) / (4.0 * math.pi) * math.sqrt(f0)
            unruh_part = pref * rho_up * nH
            hh_exc_part = pref * (rho_up + rho_in) * nH
            hh_deexc_part = pref * (rho_up + rho_in) * (1.0 + nH)
            unruh_sum += unruh_part
            hh_exc_sum += hh_exc_part
            hh_deexc_sum += hh_deexc_part
            rows.append({
                "case": label, "mM": mM, "ell": ell,
                "mu": mu, "eps": eps, "k_if_open": math.sqrt(eps*eps-mu*mu) if eps > mu else "",
                "up_abs_u_at_detector": abs(up["u"]),
                "up_reflection_abs": abs(up["R"]),
                "up_flux_or_unitarity_residual": up["flux_residual"],
                "rho_up": rho_up,
                "in_abs_u_at_detector": in_abs_u,
                "in_flux_residual": in_flux,
                "rho_in": rho_in if eps > mu else "",
                "Unruh_excitation_rate_partial": unruh_part,
                "HH_excitation_rate_partial": hh_exc_part,
                "HH_deexcitation_rate_partial": hh_deexc_part,
                "Hawking_occupation": nH,
            })
            l_sums.append({"case": label, "mM": mM, "ell": ell,
                           "Unruh_partial": unruh_part,
                           "HH_excitation_partial": hh_exc_part})
        ratio = hh_exc_sum / hh_deexc_sum
        expected = math.exp(-betaH * omega)
        summaries.append({
            "case": label, "mM": mM, "mu": mu, "eps": eps,
            "in_channel_open": eps > mu,
            "Unruh_excitation_rate_l0_to_10": unruh_sum,
            "HH_excitation_rate_l0_to_10": hh_exc_sum,
            "HH_deexcitation_rate_l0_to_10": hh_deexc_sum,
            "HH_detailed_balance_ratio": ratio,
            "expected_exp_minus_beta_omega": expected,
            "HH_detailed_balance_relative_error": abs(ratio/expected - 1.0),
            "Boulware_excitation_rate": 0.0,
        })

    path = OUT / "schwarzschild_massive_scalar_unruh_local_response_v1.csv"
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    summary_path = OUT / "schwarzschild_massive_scalar_state_response_summary_v1.csv"
    with summary_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(summaries[0]))
        writer.writeheader()
        writer.writerows(summaries)
    # Cumulative angular-momentum sums expose the l-tail directly.
    cum = {}
    lconv = []
    for row in l_sums:
        key = row["case"]
        cum.setdefault(key, {"Unruh": 0.0, "HH": 0.0})
        cum[key]["Unruh"] += row["Unruh_partial"]
        cum[key]["HH"] += row["HH_excitation_partial"]
        if row["ell"] in (0, 1, 2, 3, 4, 6, 10):
            lconv.append({"case": key, "mM": row["mM"], "ell_max": row["ell"],
                          "Unruh_cumulative": cum[key]["Unruh"],
                          "HH_excitation_cumulative": cum[key]["HH"]})
    lconv_path = OUT / "schwarzschild_massive_scalar_angular_convergence_v1.csv"
    with lconv_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(lconv[0]))
        writer.writeheader()
        writer.writerows(lconv)
    return path, rows, summaries, lconv_path, {"M": M, "r0": r0, "x0": x0, "f0": f0,
                        "OmegaM": OmegaM, "omega": omega, "eps": eps,
                        "nH": nH}

def convergence_check():
    M = 1.0
    x0 = 2.0
    y0 = x0 + math.log(x0 - 1.0)
    eps = 2.0 * 0.2 * math.sqrt(0.5)
    vals = []
    for case, mu, kind in [
        ("subthreshold_up_mM_0p15", 0.30, "up"),
        ("above_threshold_up_mM_0p05", 0.10, "up"),
        ("above_threshold_in_mM_0p05", 0.10, "in"),
    ]:
        for ymax in (250.0, 400.0, 600.0, 900.0, 1500.0):
            mode = integrate_mode(eps, mu, 0, kind, y_max=ymax, y_eval=y0)
            vals.append({"case": case, "y_max": ymax,
                         "abs_u_at_detector": abs(mode["u"]),
                         "reflection_abs": abs(mode["R"]),
                         "flux_or_unitarity_residual": mode["flux_residual"]})
    # Massless limit at fixed Killing frequency and detector radius.
    for mM in (0.0, 1.0e-4, 1.0e-3, 1.0e-2):
        mu = 2.0 * mM
        for kind in ("up", "in"):
            mode = integrate_mode(eps, mu, 0, kind, y_max=600.0, y_eval=y0)
            vals.append({"case": f"massless_limit_{kind}_mM_{mM:g}", "y_max": 600.0,
                         "abs_u_at_detector": abs(mode["u"]),
                         "reflection_abs": abs(mode["R"]),
                         "flux_or_unitarity_residual": mode["flux_residual"]})
    path = OUT / "schwarzschild_massive_scalar_radial_convergence_v1.csv"
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(vals[0]))
        writer.writeheader()
        writer.writerows(vals)
    return path, vals

def main():
    p, rows, summaries, lpath, params = run_benchmark()
    cp, conv = convergence_check()
    print("Static detector benchmark (M=1, r0=4M, Omega*M=0.2)")
    print(f"f0={params['f0']:.8f}, eps=2M*omega={params['eps']:.8f}, n_H={params['nH']:.8e}")
    for row in summaries:
        print(f"{row['case']:30s} mM={row['mM']:.3f} "
              f"Unruh={row['Unruh_excitation_rate_l0_to_10']:.10e} "
              f"HH DB err={row['HH_detailed_balance_relative_error']:.3e}")
    print("\nSelected radial convergence rows")
    for row in conv:
        if row["case"] in ("subthreshold_up_mM_0p15", "above_threshold_up_mM_0p05",
                           "above_threshold_in_mM_0p05") and row["y_max"] in (250.0, 600.0, 1500.0):
            print(row)
    print("\nFiles:")
    print(p)
    print(lpath)
    print(cp)
    print("Scope: stationary local response and radial-mode diagnostics only; no two-detector negativity is computed.")


if __name__ == "__main__":
    main()
