#!/usr/bin/env python3
"""Independent finite-matrix and quadrature checks for the v7 revision.

This verifies the stated examples and algebraic consistency, not the complete
literature, radial solver, de Sitter reconstruction, or higher perturbative orders.
Run: OPENBLAS_NUM_THREADS=2 python verify_v7_core.py
Dependencies: numpy, scipy. Outputs: results/v7_core_verification.json.
"""
from itertools import combinations
from pathlib import Path
import json
import math
import numpy as np
from scipy.integrate import quad
from scipy.optimize import brentq, minimize_scalar
from scipy.special import spherical_jn

ROOT = Path(__file__).resolve().parent


def partial_transpose(rho, subsystem, n):
    axes = list(range(2 * n))
    axes[subsystem], axes[n + subsystem] = axes[n + subsystem], axes[subsystem]
    return rho.reshape([2] * (2 * n)).transpose(axes).reshape(rho.shape)


def reduced(rho, keep, n):
    rest = [i for i in range(n) if i not in keep]
    order = list(keep) + rest + [n + i for i in keep] + [n + i for i in rest]
    dk, dr = 2 ** len(keep), 2 ** len(rest)
    a = rho.reshape([2] * (2 * n)).transpose(order).reshape(dk, dr, dk, dr)
    return np.trace(a, axis1=1, axis2=3)


def negativity(rho, subsystem, n):
    """Normalized N = ||rho^T||_1 - 1 = 2 times conventional negativity."""
    return float(np.abs(np.linalg.eigvalsh(partial_transpose(rho, subsystem, n))).sum() - 1)


def residuals(rho, n):
    one = [negativity(rho, i, n) for i in range(n)]
    pairs = {pair: negativity(reduced(rho, pair, n), 0, 2)
             for pair in combinations(range(n), 2)}
    residual = [one[i] ** 2 - sum(v ** 2 for pair, v in pairs.items() if i in pair)
                for i in range(n)]
    return {'one_vs_rest': one, 'pair_negativities': {str(k): v for k, v in pairs.items()},
            'residuals': residual}


def bell_pairs(pairing):
    v = np.zeros(16)
    for i in range(16):
        bits = [(i >> (3 - j)) & 1 for j in range(4)]
        if all(bits[a] == bits[b] for a, b in pairing):
            v[i] = 0.5
    return v


def check_counterexamples():
    vectors = [bell_pairs(p) for p in
               [[(0, 1), (2, 3)], [(0, 2), (1, 3)], [(0, 3), (1, 2)]]]
    # Each summand is explicitly product across a 2|2 cut.
    rho4 = sum(np.outer(v, v) for v in vectors) / 3
    four = residuals(rho4, 4)
    assert np.allclose(four['one_vs_rest'], 1, atol=1e-12)
    assert max(abs(x) for x in four['pair_negativities'].values()) < 1e-12
    assert np.allclose(four['residuals'], 1, atol=1e-12)
    v1, v2 = np.zeros(8), np.zeros(8)
    v1[[0, 6]] = 1 / math.sqrt(2)  # Bell AB tensor ground C.
    v2[[0, 5]] = 1 / math.sqrt(2)  # Bell AC tensor ground B.
    rho3 = (np.outer(v1, v1) + np.outer(v2, v2)) / 2
    three = residuals(rho3, 3)
    assert np.allclose(three['residuals'], [0.3090169944, 0.1545084972, 0.1545084972], atol=1e-9)
    return {'three_qubit': three, 'four_qubit': four}


def apply_on_last(rho, kraus, n=4):
    result = np.zeros_like(rho, dtype=complex)
    for k in kraus:
        big = np.kron(np.eye(2 ** (n - 1)), k)
        result += big @ rho @ big.conj().T
    return result


def check_cluster():
    v = np.zeros(16)
    v[[0, 3, 12, 15]] = [0.5, 0.5, 0.5, -0.5]
    rho = np.outer(v, v)
    reduced_abc = reduced(rho, [0, 1, 2], 4)
    errors = []
    for p in np.linspace(0, 1, 11):
        for name, ks in [
            ('amplitude_damping', [np.diag([1, np.sqrt(1-p)]), np.array([[0, np.sqrt(p)], [0, 0]])]),
            ('dephasing', [np.sqrt(1-p)*np.eye(2), np.sqrt(p)*np.diag([1, -1])]),
            ('replacement', [np.array([[np.sqrt(1-p), 0], [0, 0]]),
                             np.array([[0, np.sqrt(1-p)], [0, 0]]),
                             np.array([[0, 0], [np.sqrt(p), 0]]),
                             np.array([[0, 0], [0, np.sqrt(p)]])])]:
            assert np.allclose(sum(k.conj().T @ k for k in ks), np.eye(2))
            result = apply_on_last(rho, ks)
            error = max(abs(negativity(result, 0, 4)-1), abs(negativity(result, 1, 4)-1),
                        float(np.max(abs(reduced(result, [0, 1, 2], 4)-reduced_abc))))
            errors.append(error)
    assert max(errors) < 1e-12
    return {'channels': 3, 'parameter_values_per_channel': 11, 'max_error': max(errors)}


def diagnostic_state(v, q, coupling_squared):
    """Normalized first-order model; intentionally NOT asserted to be a CPTP evolution.

    T_q(rho) = rho + nu^2/(1-q) [sigma_- rho sigma_+ + q sigma_+ rho sigma_-].
    Its state-dependent normalization loses uniform perturbative control near q=1.
    """
    rho = np.outer(v, v)
    down = np.array([[0., 1.], [0., 0.]])
    up = down.T
    result = rho.copy()
    for op, rate in [(down, coupling_squared/(1-q)), (up, q*coupling_squared/(1-q))]:
        big = np.kron(np.eye(8), op)
        result += rate * big @ rho @ big.T
    delta = float(np.trace(result)-1)
    return result / np.trace(result), delta


def check_turning_points():
    rows = []
    for name, excitations, coupling_squared in [('W', 1, 0.04), ('Dicke', 2, 0.01)]:
        v = np.array([i.bit_count() == excitations for i in range(16)], dtype=float)
        v /= np.linalg.norm(v)
        def value(q):
            rho, _ = diagnostic_state(v, q, coupling_squared)
            return negativity(rho, 0, 4)
        optimum = minimize_scalar(value, bounds=(0.8, 0.99999), method='bounded', options={'xatol': 1e-12})
        _, delta = diagnostic_state(v, optimum.x, coupling_squared)
        formula = coupling_squared * ((1+3*optimum.x)/4 if name == 'W' else (1+optimum.x)/2) / (1-optimum.x)
        assert abs(delta-formula) < 1e-12
        reference_q = 0.982236 if name == 'W' else 0.992912
        assert abs(optimum.x-reference_q) < 5e-6
        assert delta > 1
        rows.append({'state': name, 'nu_squared': coupling_squared, 'turning_q': float(optimum.x),
                     'normalized_negativity': float(optimum.fun), 'normalization_correction': delta})
    return rows


def check_em_kernel():
    errors = []
    for z in [0., 0.2, 1., 2., 5., 10.]:
        # Separation along z. Azimuthal integration is exact; remaining polar integral is independent quadrature.
        perpendicular = math.pi * quad(lambda u: (1+u*u)*np.cos(z*u), -1, 1, epsabs=1e-12)[0]
        parallel = 2*math.pi * quad(lambda u: (1-u*u)*np.cos(z*u), -1, 1, epsabs=1e-12)[0]
        expressions = [(4*math.pi/3)*(2*spherical_jn(0,z)-spherical_jn(2,z)),
                       (8*math.pi/3)*(spherical_jn(0,z)+spherical_jn(2,z))]
        errors.append(float(np.max(abs(np.array([perpendicular, parallel])-expressions))))
    assert max(errors) < 1e-11
    return {'separations_tested': 6, 'max_quadrature_error': max(errors), 'local_limit': 8*math.pi/3}


def check_cross_correlator():
    rng = np.random.default_rng(20261102)
    errors, uncorrected_changes = [], []
    for _ in range(100):
        a, b = rng.normal(size=2) + 1j*rng.normal(size=2)
        c = a*b.conjugate()
        phase = float(rng.uniform(-math.pi, math.pi))
        n = float(rng.uniform(0.01, 5))
        def w(c, phase, n):
            return (1+n)*c*np.exp(-1j*phase)+n*c.conjugate()*np.exp(1j*phase)
        expected = c*np.exp(-1j*phase)-c.conjugate()*np.exp(1j*phase)
        actual = w(c, phase, n)-w(c.conjugate(), -phase, n)
        errors.append(abs(actual-expected))
        # This discrepancy catches the old common-complex-factor expression.
        old_ab = c*((1+n)*np.exp(-1j*phase)+n*np.exp(1j*phase))
        old_ba = c.conjugate()*((1+n)*np.exp(1j*phase)+n*np.exp(-1j*phase))
        uncorrected_changes.append(abs(old_ab-old_ba-expected))
    assert max(errors) < 1e-12
    assert max(uncorrected_changes) > 1
    return {'complex_mode_cases': 100, 'max_commutator_error': float(max(errors)),
            'max_old_expression_error': float(max(uncorrected_changes)),
            'scope': 'mode algebra only; not a radial scattering or harvesting calculation'}


def check_thermal_optima():
    relative_x = brentq(lambda x:x*np.tanh(x/2)-2, .1, 10)
    absolute_x = brentq(lambda x:x*np.tanh(x/2)-4, .1, 10)
    assert abs(1/relative_x - .416778) < 1e-6
    assert abs(1/absolute_x - .242091) < 1e-6
    return {'relative_T_over_gap': 1/relative_x, 'absolute_T_over_gap': 1/absolute_x}


def main():
    report = {'status':'PASS', 'negativity_convention':'N = 2 * conventional negativity',
              'counterexamples':check_counterexamples(), 'cluster_channels':check_cluster(),
              'first_order_diagnostics':check_turning_points(), 'electromagnetic_kernel':check_em_kernel(),
              'cross_correlator':check_cross_correlator(), 'thermal_optima':check_thermal_optima(),
              'limitations':['No full-text literature audit', 'No higher-order remainder control',
                             'No full de Sitter or radial scattering reproduction']}
    out = ROOT/'results'
    out.mkdir(exist_ok=True)
    (out/'v7_core_verification.json').write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
